import pygame
import os
import sys
import math
import random
import array

# =============================================================================
# WORD TYPIST - 16-BIT EDUCATIONAL TYPING ARCADE
# Inspired by ZType (Dominic Szablewski / PhobosLab)
# Designed for Malaysia KIR Science & Educational Research Competition
# =============================================================================

# Global Font Cache for zero-allocation rendering at 60 FPS
_WT_FONT_CACHE = {}

def get_wt_font(size, bold=True):
    key = (size, bold)
    if key not in _WT_FONT_CACHE:
        try:
            _WT_FONT_CACHE[key] = pygame.font.SysFont("consolas,couriernew,monospace", size, bold=bold)
        except Exception:
            _WT_FONT_CACHE[key] = pygame.font.Font(None, size)
    return _WT_FONT_CACHE[key]

# -----------------------------------------------------------------------------
# 1. CURATED EDUCATIONAL VOCABULARY DATABASE (SOCIAL STUDIES, GEOGRAPHY, HISTORY, ASTRONOMY)
# -----------------------------------------------------------------------------
EDUCATIONAL_VOCAB = {
    # TIER 1: Waves 1 - 5 (Physical Geography & Earth Systems)
    "tier1": [
        ("RIVER", "Geography", "A natural flowing watercourse heading toward an ocean or lake."),
        ("OCEAN", "Geography", "A vast body of salt water covering over 70% of Earth's surface."),
        ("VALLEY", "Geography", "A low area of land between hills or mountains, often with a river."),
        ("DESERT", "Geography", "A barren area of landscape where little precipitation occurs."),
        ("TUNDRA", "Geography", "A vast, flat, treeless Arctic region in which the subsoil is permanently frozen."),
        ("CANYON", "Geography", "A deep gorge, typically one with a river flowing through it."),
        ("PLATEAU", "Geography", "An area of relatively high, level ground raised above surrounding areas."),
        ("FOREST", "Geography", "A large area dominated by trees providing key biodiversity."),
        ("ISLAND", "Geography", "A piece of land surrounded by water on all sides."),
        ("SUMMIT", "Geography", "The highest point of a mountain peak or elevation."),
        ("GLACIER", "Geography", "A slowly moving mass of ice formed by snow compaction over millennia."),
        ("SAVANNA", "Geography", "A grassy plain in tropical and subtropical regions with scattered trees."),
        ("CORAL", "Geography", "Marine invertebrates building massive calcium carbonate underwater reefs."),
        ("OASIS", "Geography", "A fertile spot in a desert where water is found from natural springs."),
        ("CRATER", "Geography", "A large bowl-shaped cavity in the ground caused by explosion or impact."),
        ("DELTA", "Geography", "A landform formed at the mouth of a river where sediment is deposited."),
        ("LAGOON", "Geography", "A stretch of salt water separated from the sea by a low sandbank or coral reef."),
        ("PRAIRIE", "Geography", "A large open area of grassland, especially in North America."),
        ("MONSOON", "Geography", "A seasonal prevailing wind in South/Southeast Asia bringing heavy rain."),
        ("TECTONIC", "Geography", "Relating to the structure of the earth's crust and large-scale motions."),
    ],
    # TIER 2: Waves 6 - 10 (Ancient Heritage & Civilizations)
    "tier2": [
        ("DYNASTY", "History", "A succession of rulers of the same line or family across generations."),
        ("TEMPLE", "History", "A building devoted to the worship or presence of deities in antiquity."),
        ("POTTERY", "History", "One of humanity's oldest inventions, crafting clay vessels for trade."),
        ("CITIZEN", "History", "A legally recognized subject or national of a state with rights and duties."),
        ("PYRAMID", "History", "Monumental stone structures built as royal tombs in Ancient Egypt and Maya."),
        ("KINGDOM", "History", "A state or territory ruled by a monarch, king, or queen."),
        ("MONUMENT", "History", "A statue or building erected to commemorate a notable person or event."),
        ("BRONZE", "History", "An alloy of copper and tin that sparked the prehistoric Bronze Age."),
        ("SENATE", "History", "An assembly of citizens or elders exercising legislative and judicial power."),
        ("FORTRESS", "History", "A military stronghold designed for defensive warfare in feudal eras."),
        ("EMPIRE", "History", "An extensive group of states or countries under a single supreme authority."),
        ("SCROLL", "History", "A roll of parchment or papyrus containing written historical documents."),
        ("PHARAOH", "History", "The title of ancient Egyptian monarchs regarded as divine political rulers."),
        ("ORACLE", "History", "A priest or priestess acting as a medium for prophecy in classical antiquity."),
        ("MOSAIC", "History", "A picture or pattern produced by arranging small colored pieces of stone or glass."),
        ("MYTHOLOGY", "History", "A collection of myths belonging to a religious or cultural tradition."),
        ("CHRONICLE", "History", "A factual written account of important or historical events in chronological order."),
        ("RELIC", "History", "An object surviving from an earlier time, especially of historical or sacred interest."),
        ("FORGE", "History", "A blacksmith's workshop where metals are heated and hammered into tools."),
        ("TRIBUTE", "History", "Payment made periodically by one state or ruler to another as a sign of dependence."),
    ],
    # TIER 3: Waves 11 - 15 (Global Economics, Trade & Navigation)
    "tier3": [
        ("BARTER", "Economics", "Exchange of goods or services for other goods without using money."),
        ("MARKET", "Economics", "A regular gathering of people for the purchase and sale of provisions."),
        ("CURRENCY", "Economics", "A system of money in common use within a nation or economic zone."),
        ("VOYAGE", "Economics", "A long journey involving travel by sea across uncharted waters."),
        ("SPICES", "Economics", "Aromatic vegetable substances used for flavoring, driving ancient trade routes."),
        ("SILK", "Economics", "A fine lustrous fiber produced by silkworms, central to the Silk Road."),
        ("CARAVAN", "Economics", "A group of merchants or pilgrims traveling together across desert trade routes."),
        ("HARBOR", "Economics", "A place on the coast where vessels may find shelter from rough water."),
        ("MERCHANT", "Economics", "A person involved in wholesale trade with foreign countries."),
        ("TARIFF", "Economics", "A tax or duty to be paid on a particular class of imports or exports."),
        ("EXPORT", "Economics", "Send goods or services to another country for sale."),
        ("TREATY", "Economics", "A formally concluded and ratified agreement between sovereign states."),
        ("GALLEON", "Economics", "A large, multi-decked sailing ship used as armed cargo carriers."),
        ("BULLION", "Economics", "Gold or silver in bulk before coining, or valued by weight."),
        ("LEDGER", "Economics", "A book or collection of financial accounts in commercial bookkeeping."),
        ("COMMERCE", "Economics", "The activity of buying and selling, especially on a large scale."),
        ("SUPPLY", "Economics", "The total amount of a specific good or service available to consumers."),
        ("DEMAND", "Economics", "The quantity of a good that consumers are willing and able to purchase."),
        ("MARITIME", "Economics", "Connected with the sea, especially in relation to seafaring commercial trade."),
        ("PORT", "Economics", "A town or city with a harbor where ships load or unload cargo."),
    ],
    # TIER 4: Waves 16 - 20 (Governance, Diplomacy & Human Society)
    "tier4": [
        ("JUSTICE", "Society", "Fair and equitable treatment, honor, and legal righteousness for all citizens."),
        ("CHARTER", "Society", "A written grant by a sovereign power setting out rights and privileges."),
        ("SUFFRAGE", "Society", "The right to vote in public political elections."),
        ("BALLOT", "Society", "A system of voting secretly and in writing on an issue or candidate."),
        ("LIBERTY", "Society", "The state of being free within society from oppressive restrictions on life."),
        ("REPUBLIC", "Society", "A state in which supreme power is held by the people and their elected representatives."),
        ("COUNCIL", "Society", "An advisory, deliberative, or legislative body of people formally constituted."),
        ("EMBASSY", "Society", "The official residence or offices of an ambassador in a foreign nation."),
        ("SOVEREIGN", "Society", "Possessing supreme or ultimate power; an independent self-governing state."),
        ("RIGHTS", "Society", "Moral or legal entitlements to have or obtain something, or to act in a certain way."),
        ("DELEGATE", "Society", "A person sent or authorized to represent others, in particular at a conference."),
        ("UNION", "Society", "The action or fact of being joined, especially in a political context."),
        ("PACT", "Society", "A formal agreement between individuals or parties to cooperate."),
        ("CONSTITUTION", "Society", "A body of fundamental principles according to which a state is acknowledged to be governed."),
        ("REFORM", "Society", "Make changes in a social, political, or economic institution in order to improve it."),
        ("DECREE", "Society", "An official order issued by a legal authority carrying the force of law."),
        ("NATION", "Society", "A large body of people united by common descent, history, culture, or language."),
        ("ALLIANCE", "Society", "A union or association formed for mutual benefit, especially between countries."),
        ("EQUALITY", "Society", "The state of being equal, especially in status, rights, and opportunities."),
        ("ACCORD", "Society", "An official agreement or peace pact between international governments."),
    ],
    # TIER 5: Waves 21 - 25 (Astronomy & Cosmic Philosophy: "Two Worlds, One Destiny")
    "tier5": [
        ("ZENITH", "Astronomy", "The point in the sky or celestial sphere directly above an observer."),
        ("ORBIT", "Astronomy", "The curved trajectory of an object around a star, planet, or moon."),
        ("SOLAR", "Astronomy", "Relating to or determined by the sun and its radiant energy."),
        ("LUNAR", "Astronomy", "Relating to or resembling the moon and its gravitational tides."),
        ("NEBULA", "Astronomy", "An interstellar cloud of gas, dust, and plasma where new stars are born."),
        ("GALAXY", "Astronomy", "A system of millions or billions of stars bound together by gravitational attraction."),
        ("ECLIPSE", "Astronomy", "An obscuring of light from one celestial body by the passage of another."),
        ("GRAVITY", "Astronomy", "The universal force of attraction between all matter possessing mass."),
        ("SOLSTICE", "Astronomy", "Either of the two times in the year when the sun reaches its highest or lowest point."),
        ("PHOTON", "Astronomy", "A particle representing a quantum of light or other electromagnetic radiation."),
        ("AURORA", "Astronomy", "A natural electrical light display in high-latitude skies caused by solar wind."),
        ("COMET", "Astronomy", "A celestial object consisting of a nucleus of ice and dust with a vapor tail."),
        ("PLANET", "Astronomy", "A celestial body orbiting a star that is massive enough to be rounded by its gravity."),
        ("COSMOS", "Astronomy", "The universe seen as a well-ordered and harmonious whole."),
        ("PARALLAX", "Astronomy", "The effect whereby the position of an object appears different when viewed from different positions."),
        ("RADIANT", "Astronomy", "Shining or glowing brightly; emitting celestial electromagnetic waves."),
        ("PULSAR", "Astronomy", "A highly magnetized rotating neutron star emitting beams of electromagnetic radiation."),
        ("ORBITAL", "Astronomy", "Relating to an orbit or orbits of celestial planets or stellar bodies."),
        ("APOGEE", "Astronomy", "The point in the orbit of the moon or satellite at which it is furthest from earth."),
        ("HORIZON", "Astronomy", "The line at which the earth's surface and the sky appear to meet."),
    ]
}

# Natural Sciences Vocabulary (Biology, Chemistry, Physics) for Waves 15 - 25
SCIENCE_VOCAB = [
    # Biology
    ("PHOTOSYNTHESIS", "Biology", "The biological process by which green plants synthesize nutrients from CO2 and water using sunlight."),
    ("CHLOROPHYLL", "Biology", "A green photosynthetic pigment found in chloroplasts of algae and plants that absorbs sunlight."),
    ("MITOSIS", "Biology", "Cell division resulting in two daughter cells each having identical chromosomes as the parent nucleus."),
    ("RIBOSOME", "Biology", "A cellular organelle of RNA and protein that serves as the site for protein synthesis."),
    ("HOMEOSTASIS", "Biology", "The state of steady internal physical and chemical conditions maintained by living organisms."),
    ("ECOSYSTEM", "Biology", "A biological community of interacting living organisms and their physical environment."),
    ("METABOLISM", "Biology", "The chemical processes occurring within a living organism in order to maintain life and cellular energy."),
    ("SYMBIOSIS", "Biology", "Close physical interaction between two different biological organisms, often mutually advantageous."),
    ("ORGANISM", "Biology", "An individual animal, plant, or single-celled life form capable of metabolism and reproduction."),
    ("TAXONOMY", "Biology", "The scientific classification and naming of organisms into species, genus, and kingdoms."),

    # Chemistry
    ("CATALYST", "Chemistry", "A substance that accelerates the rate of a chemical reaction without undergoing permanent change."),
    ("COVALENT", "Chemistry", "Relating to chemical bonds formed by the mutual sharing of electron pairs between atoms."),
    ("POLYMER", "Chemistry", "A substance with a molecular structure formed by a large number of repeating monomer units."),
    ("ENDOTHERMIC", "Chemistry", "A chemical process accompanied by or requiring the absorption of thermal heat energy."),
    ("EXOTHERMIC", "Chemistry", "A chemical reaction accompanied by the release of thermal energy into the environment."),
    ("ELECTRONEGATIVITY", "Chemistry", "A chemical property measuring the tendency of an atom to attract shared electron pairs."),
    ("DISTILLATION", "Chemistry", "The purification of a liquid mixture through selective boiling and condensation."),
    ("TITRATION", "Chemistry", "A quantitative chemical analysis method to determine the concentration of an identified analyte."),
    ("MOLECULE", "Chemistry", "A group of atoms bonded together, representing the smallest unit of a chemical compound."),
    ("VALENCE", "Chemistry", "The combining power of an element determined by the number of outer-shell electrons."),

    # Physics
    ("THERMODYNAMICS", "Physics", "The branch of physical science dealing with heat, work, temperature, and energy transformations."),
    ("KINEMATICS", "Physics", "The branch of mechanics describing the trajectory and motion of bodies without reference to forces."),
    ("MOMENTUM", "Physics", "The quantity of motion possessed by a moving body, calculated as the product of mass and velocity."),
    ("REFRACTION", "Physics", "The bending of a wave when it enters a medium with a different propagation velocity."),
    ("INERTIA", "Physics", "The tendency of an object to resist changes in its velocity or state of rest unless acted upon by force."),
    ("CONDUCTIVITY", "Physics", "The measure of a material's capability to transfer heat or electrical current through free electrons."),
    ("ENTROPY", "Physics", "A thermodynamic measure of the disorder, randomness, or thermal energy unavailable for work."),
    ("SUPERCONDUCTOR", "Physics", "A material exhibiting zero electrical resistance and magnetic expulsion when cooled below critical temp."),
    ("VELOCITY", "Physics", "The rate of change of position of an object, specified by both magnitude (speed) and direction."),
    ("ELECTROMAGNETISM", "Physics", "The fundamental physical force of interaction between electrically charged particles.")
]

# Boss Word Dictionary (formidable academic terms for Bosses at waves 5, 10, 15, 20, 25)
BOSS_WORDS = {
    5: [
        ("ARCHIPELAGO", "Geography", "An extensive group or cluster of islands scattered across an ocean."),
        ("BIODIVERSITY", "Geography", "The variety of plant and animal life in the world or a particular habitat."),
        ("ATMOSPHERE", "Geography", "The envelope of gases surrounding the earth or another planet.")
    ],
    10: [
        ("CIVILIZATION", "History", "The stage of human social development and organization that is considered advanced."),
        ("MESOPOTAMIA", "History", "The historical region in Western Asia between the Tigris and Euphrates rivers, cradle of early civilization."),
        ("PHILOSOPHY", "History", "The study of the fundamental nature of knowledge, reality, and human existence.")
    ],
    15: [
        ("GLOBALIZATION", "Economics", "The process by which businesses or organizations develop international influence and cross-border trade."),
        ("MERCANTILISM", "Economics", "An economic policy designed to maximize the exports and minimize the imports for an economy."),
        ("EQUILIBRIUM", "Economics", "A state in which economic forces of supply and demand are perfectly balanced.")
    ],
    20: [
        ("SOVEREIGNTY", "Society", "Supreme power or authority; the authority of a state to govern itself independently."),
        ("JURISDICTION", "Society", "The official power to make legal decisions and judgments over an area."),
        ("CONSTITUTION", "Society", "The fundamental organic law and democratic governance system of a sovereign nation.")
    ],
    25: [
        ("CONSTELLATION", "Astronomy", "A group of stars forming a recognized pattern that is traditionally named after mythical figures."),
        ("INTERSTELLAR", "Astronomy", "Occurring or situated between the stars of a galaxy across vast cosmic reaches."),
        ("ASTROPHYSICS", "Astronomy", "The branch of astronomy concerned with the physical nature of stars and celestial bodies.")
    ]
}

# -----------------------------------------------------------------------------
# 2. RETRO SOUND SYNTHESIZER (ZERO EXTERNAL FILE DEPENDENCIES)
# -----------------------------------------------------------------------------
class WordTypistAudio:
    def __init__(self):
        self.sounds = {}
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
            self._generate_sfx()
        except Exception as e:
            print("WordTypist audio warning:", e)

    def _generate_tone(self, freqs, duration, wave_type='square', volume=0.35, slide=False):
        try:
            sample_rate = 44100
            n_samples = int(sample_rate * duration)
            buf = array.array('h')
            if not isinstance(freqs, list):
                freqs = [freqs]
            steps = len(freqs)
            s_per_step = max(1, n_samples // steps)

            for _, freq in enumerate(freqs):
                for i in range(s_per_step):
                    t = float(i) / sample_rate
                    cur_f = freq * (1.0 + (i / s_per_step) * 0.8) if slide else freq
                    if wave_type == 'square':
                        val = 30000 if (t * cur_f) % 1.0 < 0.5 else -30000
                    elif wave_type == 'triangle':
                        p = (t * cur_f) % 1.0
                        val = int((4 * abs(p - 0.5) - 1) * 30000)
                    else: # noise
                        val = random.randint(-30000, 30000)
                    env = max(0.0, 1.0 - (i / s_per_step))
                    v = int(val * volume * env)
                    buf.append(v)
                    buf.append(v)
            return pygame.mixer.Sound(buffer=buf)
        except Exception:
            return None

    def _generate_sfx(self):
        self.sounds['laser'] = self._generate_tone([880.0, 1320.0, 1760.0], 0.05, 'square', 0.28, slide=True)
        self.sounds['explode'] = self._generate_tone([300.0, 150.0, 60.0], 0.22, 'noise', 0.45)
        self.sounds['error'] = self._generate_tone([140.0, 110.0], 0.12, 'square', 0.25)
        self.sounds['boss'] = self._generate_tone([440.0, 880.0, 440.0, 880.0], 0.35, 'square', 0.4)
        self.sounds['wave_clear'] = self._generate_tone([523.25, 659.25, 783.99, 1046.5], 0.28, 'triangle', 0.4)
        self.sounds['emp'] = self._generate_tone([1200.0, 600.0, 200.0, 60.0], 0.5, 'noise', 0.55)
        self.sounds['lock'] = self._generate_tone([1200.0, 1600.0], 0.06, 'triangle', 0.3)

    def play(self, name):
        s = self.sounds.get(name)
        if s:
            try:
                s.play()
            except Exception:
                pass


# -----------------------------------------------------------------------------
# 3. PROJECTILES, PARTICLES & RETICLE
# -----------------------------------------------------------------------------
class StarProjectile:
    def __init__(self, start_pos, target_enemy, color=(255, 230, 90)):
        self.x, self.y = float(start_pos[0]), float(start_pos[1])
        self.target = target_enemy
        self.color = color
        self.speed = 1200.0
        self.finished = False
        self.tail = []

    def update(self, dt):
        if not self.target or self.target.dead:
            self.finished = True
            return

        tx, ty = self.target.x, self.target.y
        dx = tx - self.x
        dy = ty - self.y
        dist = math.hypot(dx, dy)

        self.tail.append((self.x, self.y))
        if len(self.tail) > 5:
            self.tail.pop(0)

        step = self.speed * dt
        if dist <= step or dist < 12:
            self.x, self.y = tx, ty
            self.finished = True
            self.target.on_hit()
        else:
            self.x += (dx / dist) * step
            self.y += (dy / dist) * step

    def draw(self, surface):
        for i, (tx, ty) in enumerate(self.tail):
            alpha_ratio = (i + 1) / (len(self.tail) + 1)
            rad = max(1, int(4 * alpha_ratio))
            pygame.draw.circle(surface, (255, 180, 50), (int(tx), int(ty)), rad)
        pygame.draw.circle(surface, (255, 255, 255), (int(self.x), int(self.y)), 4)
        pygame.draw.circle(surface, self.color, (int(self.x), int(self.y)), 6, 1)


class PixelParticle:
    def __init__(self, x, y, color):
        self.x = float(x)
        self.y = float(y)
        angle = random.uniform(0, 2 * math.pi)
        speed = random.uniform(50, 260)
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed
        self.life = random.uniform(0.3, 0.7)
        self.max_life = self.life
        self.color = color
        self.size = random.choice([2, 3, 4])

    def update(self, dt):
        self.life -= dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.vy += 120 * dt

    def draw(self, surface):
        if self.life > 0:
            alpha = max(0.0, self.life / self.max_life)
            c = (
                int(self.color[0] * alpha),
                int(self.color[1] * alpha),
                int(self.color[2] * alpha)
            )
            pygame.draw.rect(surface, c, (int(self.x), int(self.y), self.size, self.size))


# -----------------------------------------------------------------------------
# 4. TYPING ENEMY & BOSS CLASS
# -----------------------------------------------------------------------------
class TypingEnemy:
    def __init__(self, x, y, word, category, definition, speed, is_boss=False, boss_tier=1, anim_frames=None):
        self.x = float(x)
        self.y = float(y)
        self.word = word.upper()
        self.category = category
        self.definition = definition
        self.typed_index = 0
        self.speed = speed
        self.is_boss = is_boss
        self.boss_tier = boss_tier
        self.dead = False
        self.hit_flash = 0.0
        self.anim_frames = anim_frames or []
        self.frame_idx = 0
        self.anim_timer = 0.0
        self.size = 54 if is_boss else 32

    def on_hit(self):
        self.hit_flash = 0.12

    def update(self, dt, speed_mult=1.0):
        self.y += (self.speed * speed_mult) * dt
        if self.hit_flash > 0:
            self.hit_flash -= dt

        if self.anim_frames:
            self.anim_timer += dt
            if self.anim_timer >= 0.14:
                self.anim_timer = 0.0
                self.frame_idx = (self.frame_idx + 1) % len(self.anim_frames)

    def draw(self, surface, is_locked=False):
        draw_x = int(self.x)
        draw_y = int(self.y)

        # 1. Draw Enemy Sprite
        if self.anim_frames:
            spr = self.anim_frames[self.frame_idx]
            if self.is_boss:
                scale_w, scale_h = spr.get_width() * 2, spr.get_height() * 2
                spr = pygame.transform.scale(spr, (scale_w, scale_h))
            rect = spr.get_rect(center=(draw_x, draw_y))
            surface.blit(spr, rect)
        else:
            col = (220, 60, 60) if self.is_boss else (80, 160, 220)
            pygame.draw.rect(surface, (0, 0, 0), (draw_x - self.size//2 - 2, draw_y - self.size//2 - 2, self.size + 4, self.size + 4), border_radius=4)
            pygame.draw.rect(surface, col, (draw_x - self.size//2, draw_y - self.size//2, self.size, self.size), border_radius=4)

        # 2. Boss Crown & Health Indicator
        if self.is_boss:
            b_font = get_wt_font(12, bold=True)
            b_txt = b_font.render(f"[BOSS - TIER {self.boss_tier}]", True, (255, 215, 60))
            surface.blit(b_txt, b_txt.get_rect(center=(draw_x, draw_y - self.size//2 - 22)))

        # 3. Targeting Reticle if Locked
        if is_locked:
            reticle_color = (255, 70, 70) if (pygame.time.get_ticks() // 150) % 2 == 0 else (255, 220, 50)
            ret_r = self.size // 2 + 10
            for dx, dy in [(-1, -1), (1, -1), (-1, 1), (1, 1)]:
                cx, cy = draw_x + dx * ret_r, draw_y + dy * ret_r
                pygame.draw.line(surface, reticle_color, (cx, cy), (cx - dx * 8, cy), 2)
                pygame.draw.line(surface, reticle_color, (cx, cy), (cx, cy - dy * 8), 2)

        # 4. Floating Word Label
        font = get_wt_font(17 if self.is_boss else 15, bold=True)
        word_str = self.word
        typed_str = word_str[:self.typed_index]
        remaining_str = word_str[self.typed_index:]

        surf_typed = font.render(typed_str, True, (80, 255, 120))
        surf_remain = font.render(remaining_str, True, (255, 255, 255))

        total_w = surf_typed.get_width() + surf_remain.get_width()
        box_pad_x = 8
        box_w = total_w + box_pad_x * 2
        box_h = surf_remain.get_height() + 6
        box_y = draw_y + self.size // 2 + 8
        box_rect = pygame.Rect(draw_x - box_w // 2, box_y, box_w, box_h)

        bg_col = (40, 15, 20) if self.is_boss else ((25, 30, 45) if is_locked else (20, 16, 24))
        border_col = (255, 180, 50) if is_locked else ((200, 50, 50) if self.is_boss else (100, 90, 120))
        pygame.draw.rect(surface, bg_col, box_rect, border_radius=4)
        pygame.draw.rect(surface, border_col, box_rect, 2, border_radius=4)

        text_x = box_rect.x + box_pad_x
        text_y = box_rect.y + 3

        sh_full = font.render(word_str, True, (0, 0, 0))
        surface.blit(sh_full, (text_x + 1, text_y + 1))
        surface.blit(surf_typed, (text_x, text_y))
        surface.blit(surf_remain, (text_x + surf_typed.get_width(), text_y))


# -----------------------------------------------------------------------------
# 5. ON-SCREEN MOBILE VIRTUAL QWERTY KEYBOARD
# -----------------------------------------------------------------------------
class VirtualQWERTYKeyboard:
    def __init__(self, screen_w, screen_h):
        self.screen_w = screen_w
        self.screen_h = screen_h
        self.enabled = False
        self.pressed_key = None
        self.press_timer = 0.0

        self.rows = [
            ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
            ["A", "S", "D", "F", "G", "H", "J", "K", "L"],
            ["Z", "X", "C", "V", "B", "N", "M"]
        ]
        self.layout_keys = []
        self._build_layout()

    def _build_layout(self):
        self.layout_keys.clear()
        kb_h = 170
        kb_y = self.screen_h - kb_h - 10
        self.kb_rect = pygame.Rect(10, kb_y, self.screen_w - 20, kb_h)

        row_h = 42
        gap = 6

        for r_idx, row in enumerate(self.rows):
            n_keys = len(row)
            key_w = min(48, int((self.kb_rect.width - (n_keys + 1) * gap) / n_keys))
            total_row_w = n_keys * key_w + (n_keys - 1) * gap
            start_x = self.kb_rect.x + (self.kb_rect.width - total_row_w) // 2
            y = self.kb_rect.y + 12 + r_idx * (row_h + gap)

            for c_idx, ch in enumerate(row):
                x = start_x + c_idx * (key_w + gap)
                self.layout_keys.append({
                    "char": ch,
                    "rect": pygame.Rect(x, y, key_w, row_h),
                    "is_action": False
                })

        action_y = self.kb_rect.y + 12 + 2 * (row_h + gap)
        emp_rect = pygame.Rect(self.kb_rect.x + 12, action_y, 70, row_h)
        self.layout_keys.append({
            "char": "EMP",
            "rect": emp_rect,
            "is_action": True
        })

    def resize(self, width, height):
        self.width = width
        self.height = height
        kb_h = 168
        kb_w = min(width - 24, 780)
        self.kb_rect = pygame.Rect((width - kb_w) // 2, height - kb_h - 10, kb_w, kb_h)
        self._build_layout()

    def handle_touch(self, pos):
        if not self.enabled:
            return None
        for key in self.layout_keys:
            if key["rect"].collidepoint(pos):
                self.pressed_key = key["char"]
                self.press_timer = 0.14
                return key["char"]
        return None

    def update(self, dt):
        if self.press_timer > 0:
            self.press_timer -= dt
            if self.press_timer <= 0:
                self.pressed_key = None

    def draw(self, surface):
        if not self.enabled:
            return

        bg_surf = pygame.Surface((self.kb_rect.width, self.kb_rect.height), pygame.SRCALPHA)
        bg_surf.fill((20, 14, 25, 230))
        surface.blit(bg_surf, self.kb_rect)
        pygame.draw.rect(surface, (180, 130, 50), self.kb_rect, width=2, border_radius=8)

        font = get_wt_font(18, bold=True)
        small_font = get_wt_font(13, bold=True)

        for key in self.layout_keys:
            r = key["rect"]
            is_pressed = (self.pressed_key == key["char"])
            bg = (200, 140, 50) if is_pressed else ((90, 45, 20) if key["is_action"] else (45, 30, 55))
            border = (255, 220, 100) if is_pressed else (140, 95, 45)

            pygame.draw.rect(surface, (0, 0, 0), r.inflate(2, 2), border_radius=5)
            pygame.draw.rect(surface, bg, r, border_radius=5)
            pygame.draw.rect(surface, border, r, width=1, border_radius=5)

            f = small_font if key["is_action"] else font
            t_col = (20, 10, 5) if is_pressed else ((255, 220, 90) if key["is_action"] else (240, 240, 255))
            t_s = f.render(key["char"], True, t_col)
            surface.blit(t_s, t_s.get_rect(center=r.center))


# -----------------------------------------------------------------------------
# 5.5. WORD TYPIST AUTOMATED AI BOT
# -----------------------------------------------------------------------------
class WordTypistBot:
    """
    Automated Gameplay System for Word Typist.
    Automatically prioritizes incoming enemies (lowest y-coordinate / highest danger),
    types characters with smooth human-like cadence (~85 WPM), triggers EMP shockwave
    when defenses are breached, and displays on-screen status.
    """
    def __init__(self, game):
        self.game = game
        self.enabled = False
        self.type_timer = 0.0
        self.char_delay = 0.088 # ~85 WPM smooth typing cadence
        self.btn_bot_rect = pygame.Rect(game.width - 255, 8, 115, 26)

    def toggle(self):
        self.enabled = not self.enabled

    def update(self, dt):
        if not self.enabled:
            return

        # 1. Emergency EMP defense: if multiple enemies breach danger line
        danger_y = self.game.height - (220 if self.game.keyboard.enabled else 140)
        imminent = [e for e in self.game.enemies if not e.dead and e.y > danger_y]
        if len(imminent) >= 2 and self.game.emp_charges > 0:
            self.game.trigger_emp()
            return

        # 2. Select target enemy
        target = self.game.locked_enemy
        if target is None or target.dead:
            active_enemies = [e for e in self.game.enemies if not e.dead]
            if not active_enemies:
                return
            # Prioritize enemy nearest to bottom defense line
            active_enemies.sort(key=lambda e: e.y, reverse=True)
            target = active_enemies[0]

        # 3. Type characters smoothly
        self.type_timer += dt
        if self.type_timer >= self.char_delay:
            self.type_timer = 0.0
            if target and not target.dead and target.typed_index < len(target.word):
                next_char = target.word[target.typed_index]
                self.game.handle_character_input(next_char)

    def draw_hud(self, surface):
        is_hover = self.btn_bot_rect.collidepoint(pygame.mouse.get_pos())
        if self.enabled:
            bg_color = (25, 90, 80) if is_hover else (15, 65, 55)
            border_col = (100, 255, 220) if is_hover else (70, 210, 180)
            text_str = "[🤖 BOT: ON]"
            text_col = (200, 255, 240)
        else:
            bg_color = (80, 55, 30) if is_hover else (55, 35, 20)
            border_col = (200, 160, 70) if is_hover else (140, 100, 45)
            text_str = "[🤖 BOT: OFF]"
            text_col = (230, 210, 170)

        pygame.draw.rect(surface, (0, 0, 0), self.btn_bot_rect.move(2, 2), border_radius=4)
        pygame.draw.rect(surface, bg_color, self.btn_bot_rect, border_radius=4)
        pygame.draw.rect(surface, border_col, self.btn_bot_rect, width=1, border_radius=4)
        btn_font = get_wt_font(11, bold=True)
        txt = btn_font.render(text_str, True, text_col)
        surface.blit(txt, txt.get_rect(center=self.btn_bot_rect.center))

        if self.enabled:
            badge_font = get_wt_font(11, bold=True)
            stat_txt = badge_font.render("🤖 AUTO-TYPIST ACTIVE (~85 WPM)", True, (100, 255, 220))
            stat_rect = stat_txt.get_rect(center=(surface.get_width() // 2, 54))
            bg_r = stat_rect.inflate(16, 6)
            s_surf = pygame.Surface((bg_r.width, bg_r.height), pygame.SRCALPHA)
            s_surf.fill((10, 20, 30, 210))
            surface.blit(s_surf, bg_r)
            pygame.draw.rect(surface, (70, 210, 180), bg_r, width=1, border_radius=4)
            surface.blit(stat_txt, stat_rect)

# -------------------------------------------------------------
# 6. MAIN WORD TYPIST GAME MANAGER
# -------------------------------------------------------------
class WordTypistGame:
    def __init__(self, width, height, base_dir):
        self.width = width
        self.height = height
        self.base_dir = base_dir
        self.request_main_menu = False

        self.audio = WordTypistAudio()

        self.wave = 1
        self.max_waves = 25
        self.wave_state = "SPAWNING"
        self.wave_timer = 0.0
        self.wave_banner_timer = 2.4

        self.enemies_remaining_to_spawn = 4
        self.bosses_remaining_to_spawn = 0
        self.spawn_interval = 1.6
        self.spawn_timer = 0.5
        self.base_speed = 34.0

        self.lives = 3
        self.max_lives = 3
        self.score = 0
        self.combo = 0
        self.max_combo = 0
        self.total_keystrokes = 0
        self.correct_keystrokes = 0
        self.emp_charges = 1
        self.elapsed_time = 0.0
        self.words_cleared_count = 0
        self.bosses_slain_count = 0

        self.learned_words = []

        self.enemies = []
        self.projectiles = []
        self.particles = []
        self.locked_enemy = None
        self.floating_popups = []

        self.shake_timer = 0.0
        self.shake_magnitude = 0.0

        is_mobile_env = (
            sys.platform in ('emscripten', 'wasi', 'android') or
            os.environ.get('MOBILE_MODE') == '1' or
            'ANDROID_ARGUMENT' in os.environ or
            'KIVY_BUILD' in os.environ
        )
        self.is_mobile = is_mobile_env

        self.keyboard = VirtualQWERTYKeyboard(self.width, self.height)
        if self.is_mobile:
            self.keyboard.enabled = True

        self.bot = WordTypistBot(self)

        self._load_assets()
        self.audio.play('boss')

    @property
    def is_mobile_mode(self):
        return self.is_mobile or self.keyboard.enabled

    @property
    def enemy_speed_multiplier(self):
        # Mobile pace set to standard 1x pace
        return 1.0

    def resize(self, width, height):
        self.width = width
        self.height = height
        if self.bg_surf:
            self._load_assets()
        self.keyboard.resize(width, height)
        if hasattr(self, 'bot'):
            self.bot.btn_bot_rect = pygame.Rect(width - 255, 8, 115, 26)

    def _load_assets(self):
        self.bg_surf = None
        bg_paths = [
            os.path.join(self.base_dir, "Backgrounds", "background3.png"),
            os.path.join(self.base_dir, "Backgrounds", "plx-1.png"),
            os.path.join(self.base_dir, "Backgrounds", "BGBack.png")
        ]
        for bp in bg_paths:
            if os.path.exists(bp):
                try:
                    self.bg_surf = pygame.image.load(bp).convert()
                    self.bg_surf = pygame.transform.scale(self.bg_surf, (self.width, self.height))
                    break
                except Exception:
                    pass

        self.hero_frames = []
        hero_dir = os.path.join(self.base_dir, "10")
        if os.path.exists(hero_dir):
            for i in range(1, 9):
                hp = os.path.join(hero_dir, f"attack_{i}.png")
                if os.path.exists(hp):
                    try:
                        f_img = pygame.image.load(hp).convert_alpha()
                        self.hero_frames.append(pygame.transform.scale(f_img, (64, 64)))
                    except Exception:
                        pass
        self.hero_frame_idx = 0
        self.hero_cast_timer = 0.0

        self.bat_frames = []
        bat_dir = os.path.join(self.base_dir, "Enemy", "Bat")
        if os.path.exists(bat_dir):
            for i in range(1, 5):
                bp = os.path.join(bat_dir, f"Bat_Fly_{i}.png")
                if os.path.exists(bp):
                    try:
                        b_img = pygame.image.load(bp).convert_alpha()
                        self.bat_frames.append(pygame.transform.scale(b_img, (48, 48)))
                    except Exception:
                        pass

        self.boss_frames = []
        golem_p = os.path.join(self.base_dir, "Enemy_Galore_I", "Golem", "Armored", "Golem_Armor_Idle.png")
        if os.path.exists(golem_p):
            try:
                g_img = pygame.image.load(golem_p).convert_alpha()
                self.boss_frames.append(pygame.transform.scale(g_img, (72, 72)))
            except Exception:
                pass

    def _get_tier_for_wave(self, wave):
        if wave <= 5: return "tier1"
        if wave <= 10: return "tier2"
        if wave <= 15: return "tier3"
        if wave <= 20: return "tier4"
        return "tier5"

    def _get_wave_title(self, wave):
        if wave <= 5: return "ERA 1: PHYSICAL GEOGRAPHY & BIOMES"
        if wave <= 10: return "ERA 2: ANCIENT HERITAGE & CIVILIZATIONS"
        if wave <= 15: return "ERA 3: GLOBAL ECONOMICS & TRADE"
        if wave <= 20: return "ERA 4: GOVERNANCE, DIPLOMACY & SOCIETY"
        return "ERA 5: COSMIC HARMONY - TWO WORLDS, ONE DESTINY"

    def start_wave(self, wave_num):
        self.wave = wave_num
        self.wave_state = "ACTIVE"
        self.wave_banner_timer = 2.2

        self.enemies_remaining_to_spawn = 4 + (self.wave - 1)

        if self.wave % 5 == 0:
            self.bosses_remaining_to_spawn = self.wave // 5
            self.audio.play('boss')
        else:
            self.bosses_remaining_to_spawn = 0

        # Waves 15 - 25: Guarantee 2 to 3 Natural Science words (Biology, Chemistry, Physics) per wave
        if 15 <= self.wave <= 25:
            self.science_words_to_spawn = random.randint(2, 3)
        else:
            self.science_words_to_spawn = 0

        self.spawn_timer = 2.0
        self.base_speed = 34.0 + (self.wave * 1.5)

    def spawn_regular_enemy(self):
        existing_first_letters = {e.word[0] for e in self.enemies if not e.dead}

        # Check if we should spawn a science word (Biology, Chemistry, Physics)
        if getattr(self, 'science_words_to_spawn', 0) > 0 and (random.random() < 0.35 or self.enemies_remaining_to_spawn <= self.science_words_to_spawn):
            candidates = [v for v in SCIENCE_VOCAB if v[0][0] not in existing_first_letters]
            choice = random.choice(candidates if candidates else SCIENCE_VOCAB)
            self.science_words_to_spawn -= 1
        else:
            tier_key = self._get_tier_for_wave(self.wave)
            vocab_pool = EDUCATIONAL_VOCAB[tier_key]
            candidates = [v for v in vocab_pool if v[0][0] not in existing_first_letters]
            choice = random.choice(candidates if candidates else vocab_pool)

        word, cat, defn = choice
        x = random.randint(70, self.width - 70)
        y = 65
        speed = self.base_speed * random.uniform(0.9, 1.25)

        enemy = TypingEnemy(x, y, word, cat, defn, speed, is_boss=False, anim_frames=self.bat_frames)
        self.enemies.append(enemy)

    def spawn_boss_enemy(self):
        boss_pool = BOSS_WORDS.get(self.wave, BOSS_WORDS[5])
        choice = random.choice(boss_pool)
        word, cat, defn = choice

        tier = self.wave // 5
        x = random.randint(120, self.width - 120)
        y = 85
        speed = self.base_speed * 0.55

        boss = TypingEnemy(x, y, word, cat, defn, speed, is_boss=True, boss_tier=tier, anim_frames=self.boss_frames)
        self.enemies.append(boss)

    def trigger_emp(self):
        if self.emp_charges <= 0:
            return
        self.emp_charges -= 1
        self.audio.play('emp')
        self.shake_timer = 0.45
        self.shake_magnitude = 12.0

        for e in self.enemies[:]:
            if not e.dead:
                e.dead = True
                self.words_cleared_count += 1
                if e.is_boss:
                    self.bosses_slain_count += 1
                self.learned_words.append((e.word, e.category, e.definition))
                for _ in range(16):
                    self.particles.append(PixelParticle(e.x, e.y, (255, 230, 80)))

        self.locked_enemy = None
        self.floating_popups.append({"text": "EMP SHOCKWAVE!", "x": self.width // 2, "y": self.height // 2, "timer": 1.2, "col": (100, 220, 255)})

    def handle_character_input(self, char):
        char = char.upper()
        self.total_keystrokes += 1

        if self.locked_enemy and not self.locked_enemy.dead:
            target_char = self.locked_enemy.word[self.locked_enemy.typed_index]
            if char == target_char:
                self.correct_keystrokes += 1
                self.locked_enemy.typed_index += 1
                self.audio.play('laser')
                self.hero_cast_timer = 0.22

                hero_x = self.width // 2
                hero_y = self.height - (180 if self.keyboard.enabled else 65)
                self.projectiles.append(StarProjectile((hero_x, hero_y), self.locked_enemy))

                if self.locked_enemy.typed_index >= len(self.locked_enemy.word):
                    self._on_enemy_word_cleared(self.locked_enemy)
            else:
                self.audio.play('error')
                self.combo = 0
                self.shake_timer = 0.15
                self.shake_magnitude = 4.0
        else:
            matching_enemies = [
                e for e in self.enemies
                if not e.dead and e.word.startswith(char) and e.y >= 0
            ]
            if matching_enemies:
                chosen = max(matching_enemies, key=lambda e: e.y)
                self.locked_enemy = chosen
                self.correct_keystrokes += 1
                self.locked_enemy.typed_index = 1
                self.audio.play('lock')
                self.audio.play('laser')
                self.hero_cast_timer = 0.22

                hero_x = self.width // 2
                hero_y = self.height - (180 if self.keyboard.enabled else 65)
                self.projectiles.append(StarProjectile((hero_x, hero_y), self.locked_enemy))

                if self.locked_enemy.typed_index >= len(self.locked_enemy.word):
                    self._on_enemy_word_cleared(self.locked_enemy)
            else:
                self.audio.play('error')
                self.combo = 0

    def _on_enemy_word_cleared(self, enemy):
        enemy.dead = True
        self.audio.play('explode')
        self.words_cleared_count += 1
        if enemy.is_boss:
            self.bosses_slain_count += 1

        self.combo += 1
        self.max_combo = max(self.max_combo, self.combo)
        base_points = len(enemy.word) * 100 * (5 if enemy.is_boss else 1)
        combo_bonus = int(base_points * (1.0 + self.combo * 0.1))
        self.score += combo_bonus

        p_col = (255, 215, 60) if enemy.is_boss else (120, 220, 255)
        for _ in range(24 if enemy.is_boss else 12):
            self.particles.append(PixelParticle(enemy.x, enemy.y, p_col))

        self.floating_popups.append({
            "text": f"+{combo_bonus}" + (f" (x{self.combo})" if self.combo > 1 else ""),
            "x": int(enemy.x),
            "y": int(enemy.y),
            "timer": 0.9,
            "col": (255, 230, 90) if enemy.is_boss else (255, 255, 255)
        })

        if (enemy.word, enemy.category, enemy.definition) not in self.learned_words:
            self.learned_words.append((enemy.word, enemy.category, enemy.definition))

        self.locked_enemy = None

    def update(self, dt, events):
        self.elapsed_time += dt

        if self.shake_timer > 0:
            self.shake_timer -= dt

        for event in events:
            if event.type == pygame.QUIT:
                self.request_main_menu = True
                return
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_F4:
                    if hasattr(self, 'bot'):
                        self.bot.toggle()
                elif event.key == pygame.K_ESCAPE:
                    self.request_main_menu = True
                    return
                elif event.key == pygame.K_SPACE:
                    self.trigger_emp()
                elif event.unicode and event.unicode.isalpha():
                    self.handle_character_input(event.unicode)

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mx, my = event.pos
                if hasattr(self, 'bot') and self.bot.btn_bot_rect.collidepoint(mx, my):
                    self.bot.toggle()
                    return

                btn_kb_toggle = pygame.Rect(self.width - 130, 8, 120, 26)
                if btn_kb_toggle.collidepoint(mx, my):
                    self.keyboard.enabled = not self.keyboard.enabled
                    return

                if self.keyboard.enabled:
                    action = self.keyboard.handle_touch((mx, my))
                    if action == "EMP":
                        self.trigger_emp()
                    elif action and len(action) == 1 and action.isalpha():
                        self.handle_character_input(action)

            elif event.type == pygame.FINGERDOWN:
                self.is_mobile = True
                tx = int(event.x * self.width)
                ty = int(event.y * self.height)
                if hasattr(self, 'bot') and self.bot.btn_bot_rect.collidepoint(tx, ty):
                    self.bot.toggle()
                    return

                btn_kb_toggle = pygame.Rect(self.width - 130, 8, 120, 26)
                if btn_kb_toggle.collidepoint(tx, ty):
                    self.keyboard.enabled = not self.keyboard.enabled
                    return

                if not self.keyboard.enabled:
                    self.keyboard.enabled = True

                action = self.keyboard.handle_touch((tx, ty))
                if action == "EMP":
                    self.trigger_emp()
                elif action and len(action) == 1 and action.isalpha():
                    self.handle_character_input(action)

        self.keyboard.update(dt)

        if hasattr(self, 'bot'):
            self.bot.update(dt)

        if self.wave_state in ("GAME_OVER", "VICTORY"):
            return

        if self.wave_banner_timer > 0:
            self.wave_banner_timer -= dt

        # On mobile, enemies move 1.5x slower; scale spawn timer accordingly so enemies don't bunch up
        speed_mult = self.enemy_speed_multiplier
        self.spawn_timer -= (dt * speed_mult)
        if self.spawn_timer <= 0:
            if self.bosses_remaining_to_spawn > 0:
                self.spawn_boss_enemy()
                self.bosses_remaining_to_spawn -= 1
                self.spawn_timer = 2.2
            elif self.enemies_remaining_to_spawn > 0:
                self.spawn_regular_enemy()
                self.enemies_remaining_to_spawn -= 1
                self.spawn_timer = self.spawn_interval

        defense_y = self.height - (190 if self.keyboard.enabled else 85)

        for e in self.enemies[:]:
            e.update(dt, speed_mult=speed_mult)
            if e.y >= defense_y and not e.dead:
                e.dead = True
                self.lives -= 1
                self.combo = 0
                self.audio.play('error')
                self.shake_timer = 0.3
                self.shake_magnitude = 8.0

                if self.locked_enemy == e:
                    self.locked_enemy = None

                for _ in range(15):
                    self.particles.append(PixelParticle(e.x, defense_y, (255, 60, 60)))

                if self.lives <= 0:
                    self.wave_state = "GAME_OVER"
                    self.audio.play('boss')
                    return

        self.enemies = [e for e in self.enemies if not (e.dead and e.y >= defense_y)]

        for p in self.projectiles[:]:
            p.update(dt)
            if p.finished:
                self.projectiles.remove(p)

        for part in self.particles[:]:
            part.update(dt)
            if part.life <= 0:
                self.particles.remove(part)

        for pop in self.floating_popups[:]:
            pop["timer"] -= dt
            pop["y"] -= 28 * dt
            if pop["timer"] <= 0:
                self.floating_popups.remove(pop)

        living_enemies = [e for e in self.enemies if not e.dead]
        if self.enemies_remaining_to_spawn == 0 and self.bosses_remaining_to_spawn == 0 and len(living_enemies) == 0:
            if self.wave >= self.max_waves:
                self.wave_state = "VICTORY"
                self.audio.play('wave_clear')
            else:
                self.audio.play('wave_clear')
                self.start_wave(self.wave + 1)

    def draw(self, surface):
        if self.bg_surf:
            surface.blit(self.bg_surf, (0, 0))
        else:
            surface.fill((14, 10, 22))

        now = pygame.time.get_ticks()
        for i in range(40):
            sx = (i * 97 + (now // 80)) % self.width
            sy = (i * 131) % (self.height - 120)
            twinkle = (math.sin(now * 0.003 + i) + 1.0) * 0.5
            col = int(140 + 115 * twinkle)
            surface.set_at((sx, sy), (col, col, int(col * 0.8)))

        defense_y = self.height - (190 if self.keyboard.enabled else 85)
        pulse = (math.sin(now * 0.006) + 1.0) * 0.5
        line_col = (int(160 + 95 * pulse), 60, 60) if self.lives == 1 else (60, int(150 + 90 * pulse), 220)

        for lx in range(0, self.width, 16):
            pygame.draw.line(surface, line_col, (lx, defense_y), (lx + 8, defense_y), 2)

        hero_x = self.width // 2
        hero_y = self.height - (175 if self.keyboard.enabled else 60)

        if self.hero_frames:
            f_idx = 4 if self.hero_cast_timer > 0 else 0
            hero_spr = self.hero_frames[f_idx % len(self.hero_frames)]
            surface.blit(hero_spr, hero_spr.get_rect(center=(hero_x, hero_y)))
        else:
            pygame.draw.circle(surface, (255, 200, 80), (hero_x, hero_y), 18)

        for p in self.projectiles:
            p.draw(surface)

        for part in self.particles:
            part.draw(surface)

        for enemy in self.enemies:
            if not enemy.dead:
                enemy.draw(surface, is_locked=(enemy == self.locked_enemy))

        f_font = get_wt_font(14, bold=True)
        for pop in self.floating_popups:
            p_s = f_font.render(pop["text"], True, pop["col"])
            p_sh = f_font.render(pop["text"], True, (0, 0, 0))
            surface.blit(p_sh, (pop["x"] + 1, int(pop["y"]) + 1))
            surface.blit(p_s, (pop["x"], int(pop["y"])))

        self._draw_hud(surface)

        if self.keyboard.enabled:
            self.keyboard.draw(surface)

        if self.wave_banner_timer > 0 and self.wave_state == "ACTIVE":
            self._draw_wave_banner(surface)

        if self.wave_state in ("GAME_OVER", "VICTORY"):
            self._draw_results_screen(surface)

    def _draw_hud(self, surface):
        hud_bg = pygame.Surface((self.width, 42), pygame.SRCALPHA)
        hud_bg.fill((15, 10, 20, 220))
        surface.blit(hud_bg, (0, 0))
        pygame.draw.line(surface, (160, 110, 45), (0, 42), (self.width, 42), 1)

        font = get_wt_font(13, bold=True)
        title_font = get_wt_font(14, bold=True)

        w_txt = title_font.render(f"WAVE {self.wave}/{self.max_waves}", True, (255, 215, 75))
        surface.blit(w_txt, (14, 12))

        score_str = f"SCORE: {self.score:,}"
        if self.combo > 1:
            score_str += f" ({self.combo}x)"
        s_txt = font.render(score_str, True, (255, 255, 240))
        surface.blit(s_txt, (125, 13))

        mins = max(0.05, self.elapsed_time / 60.0)
        wpm = int((self.correct_keystrokes / 5.0) / mins)
        acc = (self.correct_keystrokes / max(1, self.total_keystrokes)) * 100.0
        stats_str = f"WPM: {wpm} | ACC: {acc:.0f}%"
        stat_txt = font.render(stats_str, True, (100, 230, 255))
        surface.blit(stat_txt, (285, 13))

        emp_charges_str = "*" * self.emp_charges if self.emp_charges > 0 else "0"
        emp_str = f"EMP: {emp_charges_str}"
        emp_txt = font.render(emp_str, True, (255, 140, 50) if self.emp_charges > 0 else (120, 120, 120))
        surface.blit(emp_txt, (435, 13))

        if self.is_mobile_mode:
            badge_rect = pygame.Rect(495, 10, 78, 22)
            pygame.draw.rect(surface, (18, 48, 28), badge_rect, border_radius=4)
            pygame.draw.rect(surface, (70, 200, 110), badge_rect, 1, border_radius=4)
            badge_txt = get_wt_font(10, bold=True).render("1x PACE", True, (130, 255, 170))
            surface.blit(badge_txt, badge_txt.get_rect(center=badge_rect.center))

        kb_btn = pygame.Rect(self.width - 130, 8, 120, 26)
        kb_hover = kb_btn.collidepoint(pygame.mouse.get_pos())
        kb_col = (130, 70, 30) if kb_hover else (90, 45, 18)
        pygame.draw.rect(surface, kb_col, kb_btn, border_radius=4)
        pygame.draw.rect(surface, (255, 200, 80), kb_btn, 1, border_radius=4)
        status_str = "KEYBOARD: ON" if self.keyboard.enabled else "KEYBOARD: OFF"
        kb_txt = get_wt_font(11, bold=True).render(status_str, True, (255, 255, 255))
        surface.blit(kb_txt, kb_txt.get_rect(center=kb_btn.center))

        if hasattr(self, 'bot'):
            self.bot.draw_hud(surface)

        shields_right = (self.bot.btn_bot_rect.left if hasattr(self, 'bot') else kb_btn.left) - 15
        shield_w, shield_h = 16, 14
        shield_gap = 6
        total_shields_w = self.max_lives * shield_w + (self.max_lives - 1) * shield_gap
        shields_start_x = shields_right - total_shields_w
        for i in range(self.max_lives):
            sx = shields_start_x + i * (shield_w + shield_gap)
            c = (60, 220, 90) if i < self.lives else (60, 40, 50)
            pygame.draw.rect(surface, c, (sx, 14, shield_w, shield_h), border_radius=3)
            pygame.draw.rect(surface, (255, 220, 100), (sx, 14, shield_w, shield_h), 1, border_radius=3)

    def _draw_wave_banner(self, surface):
        banner_w = 640
        banner_h = 68
        banner_rect = pygame.Rect((self.width - banner_w) // 2, 70, banner_w, banner_h)

        pygame.draw.rect(surface, (20, 12, 28), banner_rect, border_radius=8)
        pygame.draw.rect(surface, (255, 195, 60), banner_rect, 2, border_radius=8)

        title = get_wt_font(17, bold=True).render(f"--- WAVE {self.wave} OF {self.max_waves} ---", True, (255, 215, 75))
        surface.blit(title, title.get_rect(center=(self.width // 2, banner_rect.y + 22)))

        subtitle = get_wt_font(13, bold=True).render(self._get_wave_title(self.wave), True, (220, 220, 240))
        surface.blit(subtitle, subtitle.get_rect(center=(self.width // 2, banner_rect.y + 46)))

    def _draw_results_screen(self, surface):
        dim = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        dim.fill((0, 0, 0, 215))
        surface.blit(dim, (0, 0))

        is_win = (self.wave_state == "VICTORY")
        panel_w = 720
        panel_h = 500
        panel_rect = pygame.Rect((self.width - panel_w) // 2, 50, panel_w, panel_h)

        pygame.draw.rect(surface, (24, 16, 28), panel_rect, border_radius=10)
        border_col = (255, 215, 70) if is_win else (220, 60, 60)
        pygame.draw.rect(surface, border_col, panel_rect, 2, border_radius=10)

        title_str = "VICTORY - ALL 25 WAVES CONQUERED!" if is_win else "DEFENSE OVERRUN - ROUND SUMMARY"
        title_col = (255, 220, 80) if is_win else (240, 80, 80)
        title_txt = get_wt_font(20, bold=True).render(title_str, True, title_col)
        surface.blit(title_txt, title_txt.get_rect(center=(self.width // 2, panel_rect.y + 30)))

        sub_txt = get_wt_font(14, bold=True).render("ACADEMIC & TYPING PERFORMANCE REPORT", True, (200, 200, 220))
        surface.blit(sub_txt, sub_txt.get_rect(center=(self.width // 2, panel_rect.y + 55)))

        pygame.draw.line(surface, (160, 110, 45), (panel_rect.x + 30, panel_rect.y + 70), (panel_rect.right - 30, panel_rect.y + 70), 1)

        mins = max(0.05, self.elapsed_time / 60.0)
        wpm = int((self.correct_keystrokes / 5.0) / mins)
        acc = (self.correct_keystrokes / max(1, self.total_keystrokes)) * 100.0

        metrics = [
            ("FINAL SCORE", f"{self.score:,}"),
            ("WAVE REACHED", f"{self.wave} / {self.max_waves}"),
            ("TYPING SPEED", f"{wpm} WPM"),
            ("TYPING ACCURACY", f"{acc:.1f}%"),
            ("MAX STREAK", f"{self.max_combo} Words"),
            ("WORDS MASTERED", f"{len(self.learned_words)} Terms")
        ]

        f_hdr = get_wt_font(12, bold=True)
        f_val = get_wt_font(16, bold=True)

        for idx, (label, val) in enumerate(metrics):
            col_idx = idx % 3
            row_idx = idx // 3
            cx = panel_rect.x + 80 + col_idx * 210
            cy = panel_rect.y + 85 + row_idx * 45

            l_s = f_hdr.render(label, True, (255, 200, 100))
            v_s = f_val.render(val, True, (255, 255, 255))
            surface.blit(l_s, (cx, cy))
            surface.blit(v_s, (cx, cy + 16))

        pygame.draw.line(surface, (160, 110, 45), (panel_rect.x + 30, panel_rect.y + 185), (panel_rect.right - 30, panel_rect.y + 185), 1)

        glossary_title = get_wt_font(14, bold=True).render("LEARNED VOCABULARY & SOCIAL STUDIES DEFINITIONS:", True, (255, 215, 75))
        surface.blit(glossary_title, (panel_rect.x + 35, panel_rect.y + 195))

        f_word = get_wt_font(13, bold=True)
        f_def = get_wt_font(11, bold=False)

        display_words = self.learned_words[-5:] if self.learned_words else []
        for w_idx, (w, c, d) in enumerate(display_words):
            wy = panel_rect.y + 225 + w_idx * 44
            w_txt = f_word.render(f"* {w} [{c}]", True, (100, 230, 255))
            d_txt = f_def.render(f"  {d[:88]}...", True, (220, 220, 220))
            surface.blit(w_txt, (panel_rect.x + 35, wy))
            surface.blit(d_txt, (panel_rect.x + 35, wy + 16))

        btn_again = pygame.Rect(self.width // 2 - 210, panel_rect.bottom - 45, 190, 36)
        btn_menu = pygame.Rect(self.width // 2 + 20, panel_rect.bottom - 45, 190, 36)

        mx, my = pygame.mouse.get_pos()
        hover_again = btn_again.collidepoint(mx, my)
        hover_menu = btn_menu.collidepoint(mx, my)

        pygame.draw.rect(surface, (130, 70, 30) if hover_again else (90, 45, 18), btn_again, border_radius=6)
        pygame.draw.rect(surface, (255, 200, 80), btn_again, 2, border_radius=6)
        t_again = get_wt_font(14, bold=True).render("PLAY AGAIN", True, (255, 255, 255))
        surface.blit(t_again, t_again.get_rect(center=btn_again.center))

        pygame.draw.rect(surface, (130, 70, 30) if hover_menu else (90, 45, 18), btn_menu, border_radius=6)
        pygame.draw.rect(surface, (255, 200, 80), btn_menu, 2, border_radius=6)
        t_menu = get_wt_font(14, bold=True).render("MAIN MENU", True, (255, 255, 255))
        surface.blit(t_menu, t_menu.get_rect(center=btn_menu.center))

        if pygame.mouse.get_pressed()[0]:
            if hover_again:
                self.__init__(self.width, self.height, self.base_dir)
            elif hover_menu:
                self.request_main_menu = True
