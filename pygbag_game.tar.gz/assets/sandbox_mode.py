import pygame, os, sys, random, math, json

class SandboxBot:
    """
    Automated Construction System for Sandbox Mode.
    Systematically constructs a grand medieval keep & palace courtyard in real time,
    placing stone foundations (Layer 1), castle perimeter walls and archways (Layer 2),
    and royal decor, thrones, torches, and courtyard gardens (Layer 3).
    """
    def __init__(self, game):
        self.game = game
        self.enabled = False
        self.build_timer = 0.0
        self.build_delay = 0.045 # Smooth and satisfying tile placement cadence
        self.step_idx = 0
        self.blueprint = []
        self.btn_bot_rect = pygame.Rect(game.width - 200, 14, 185, 32)
        self.status_msg = "Ready to Build"
        self._tile_cache = {}

    def toggle(self):
        self.enabled = not self.enabled
        if self.enabled:
            self._generate_blueprint()
            self.step_idx = 0
            self.status_msg = "Constructing Royal Keep..."
        else:
            self.status_msg = "Halted"

    def _get_tile_by_name(self, target_substr, fallback_idx=0):
        if target_substr in self._tile_cache:
            return self._tile_cache[target_substr]
        for tlist in self.game.cat_tiles.values():
            for t in tlist:
                if target_substr.lower() in t.get("name", "").lower():
                    self._tile_cache[target_substr] = t
                    return t
        if self.game.cat_tiles.get(0):
            t = self.game.cat_tiles[0][min(fallback_idx, len(self.game.cat_tiles[0]) - 1)]
            self._tile_cache[target_substr] = t
            return t
        return None

    def _generate_blueprint(self):
        self.blueprint.clear()
        px = self.game.player.rect.centerx
        py = self.game.player.rect.centery
        origin_x = int(math.floor(px / 48.0) * 48) - 5 * 48
        origin_y = int(math.floor(py / 48.0) * 48) - 4 * 48

        floor_tile = self._get_tile_by_name("079", 79) or self._get_tile_by_name("078", 78)
        wall_top = self._get_tile_by_name("002", 2) or self._get_tile_by_name("030", 30)
        wall_side = self._get_tile_by_name("040", 40) or self._get_tile_by_name("041", 41)
        wall_bot = self._get_tile_by_name("074", 74) or self._get_tile_by_name("075", 75)
        door_left = self._get_tile_by_name("066", 66)
        door_right = self._get_tile_by_name("067", 67)
        chest = self._get_tile_by_name("083", 83) or self._get_tile_by_name("080", 80)
        torch = self._get_tile_by_name("090", 90) or self._get_tile_by_name("091", 91)
        throne = self._get_tile_by_name("099", 99) or self._get_tile_by_name("088", 88)

        # 1. Foundation: Layer 1 (10 columns x 8 rows of stone floor tiles)
        for r in range(8):
            for c in range(10):
                if floor_tile:
                    self.blueprint.append({
                        "gx": origin_x + c * 48,
                        "gy": origin_y + r * 48,
                        "layer": 1,
                        "tile": floor_tile
                    })

        # 2. Castle Perimeter Walls: Layer 2
        for c in range(10):
            if wall_top:
                self.blueprint.append({"gx": origin_x + c * 48, "gy": origin_y, "layer": 2, "tile": wall_top})
        for r in range(1, 7):
            if wall_side:
                self.blueprint.append({"gx": origin_x, "gy": origin_y + r * 48, "layer": 2, "tile": wall_side})
                self.blueprint.append({"gx": origin_x + 9 * 48, "gy": origin_y + r * 48, "layer": 2, "tile": wall_side})
        for c in range(10):
            if c in (4, 5):
                d_tile = door_left if c == 4 else door_right
                if d_tile:
                    self.blueprint.append({"gx": origin_x + c * 48, "gy": origin_y + 7 * 48, "layer": 2, "tile": d_tile})
            else:
                if wall_bot:
                    self.blueprint.append({"gx": origin_x + c * 48, "gy": origin_y + 7 * 48, "layer": 2, "tile": wall_bot})

        # 3. Interior Decor & Furnishings: Layer 3
        if throne:
            self.blueprint.append({"gx": origin_x + 4 * 48, "gy": origin_y + 2 * 48, "layer": 3, "tile": throne})
            self.blueprint.append({"gx": origin_x + 5 * 48, "gy": origin_y + 2 * 48, "layer": 3, "tile": throne})
        if torch:
            for r in [1, 3, 5]:
                self.blueprint.append({"gx": origin_x + 1 * 48, "gy": origin_y + r * 48, "layer": 3, "tile": torch})
                self.blueprint.append({"gx": origin_x + 8 * 48, "gy": origin_y + r * 48, "layer": 3, "tile": torch})
        if chest:
            self.blueprint.append({"gx": origin_x + 1 * 48, "gy": origin_y + 6 * 48, "layer": 3, "tile": chest})
            self.blueprint.append({"gx": origin_x + 8 * 48, "gy": origin_y + 6 * 48, "layer": 3, "tile": chest})

    def update(self, dt):
        if not self.enabled:
            return

        if self.step_idx < len(self.blueprint):
            self.build_timer += dt
            if self.build_timer >= self.build_delay:
                self.build_timer = 0.0
                bp = self.blueprint[self.step_idx]
                t_info = bp["tile"]
                gx, gy, lyr = bp["gx"], bp["gy"], bp["layer"]

                self.game.placed_tiles = [
                    t for t in self.game.placed_tiles
                    if not (t["x"] == gx and t["y"] == gy and t.get("layer", 1) == lyr)
                ]

                self.game.placed_tiles.append({
                    "surf": t_info["surf"],
                    "name": t_info.get("name", ""),
                    "x": gx,
                    "y": gy,
                    "layer": lyr,
                    "rect": pygame.Rect(gx, gy, 48, 48)
                })

                self.step_idx += 1
                pct = int((self.step_idx / max(1, len(self.blueprint))) * 100)
                self.status_msg = f"Constructing Royal Palace ({pct}%)..."
        else:
            self.status_msg = "Royal Palace Completed!"

    def draw_hud(self, surface):
        is_hover = self.btn_bot_rect.collidepoint(pygame.mouse.get_pos())
        if self.enabled:
            bg_color = (25, 90, 80) if is_hover else (15, 65, 55)
            border_col = (100, 255, 220) if is_hover else (70, 210, 180)
            text_str = "[🤖 AUTO-BUILD: ON]"
            text_col = (200, 255, 240)
        else:
            bg_color = (80, 55, 30) if is_hover else (55, 35, 20)
            border_col = (200, 160, 70) if is_hover else (140, 100, 45)
            text_str = "[🤖 AUTO-BUILD: OFF]"
            text_col = (230, 210, 170)

        pygame.draw.rect(surface, (0, 0, 0), self.btn_bot_rect.move(2, 2), border_radius=4)
        pygame.draw.rect(surface, bg_color, self.btn_bot_rect, border_radius=4)
        pygame.draw.rect(surface, border_col, self.btn_bot_rect, width=2, border_radius=4)
        font = pygame.font.SysFont("couriernew", 12, bold=True)
        txt = font.render(text_str, True, text_col)
        surface.blit(txt, txt.get_rect(center=self.btn_bot_rect.center))

        if self.enabled:
            badge_font = pygame.font.SysFont("couriernew", 12, bold=True)
            stat_txt = badge_font.render(f"🤖 {self.status_msg}", True, (100, 255, 220))
            stat_rect = stat_txt.get_rect(center=(surface.get_width() // 2, 54))
            bg_r = stat_rect.inflate(18, 8)
            s_surf = pygame.Surface((bg_r.width, bg_r.height), pygame.SRCALPHA)
            s_surf.fill((10, 20, 30, 220))
            surface.blit(s_surf, bg_r)
            pygame.draw.rect(surface, (70, 210, 180), bg_r, width=2, border_radius=5)
            surface.blit(stat_txt, stat_rect)

class SandboxGame:
    def __init__(self, width, height, base_dir):
        self.width = width
        self.height = height
        self.base_dir = base_dir
        
        # Random seed generated EVERY time Sandbox is opened!
        self.world_seed = random.randint(1, 9999999)
        
        # Infinite World Map Setup (No trees or houses, pure walkable grass terrain)
        from rpg_mode import RPGPlayer, RPGCamera, RPGMap
        self.player = RPGPlayer(width // 2, height // 2, base_dir)
        self.camera = RPGCamera(width, height)
        self.map = RPGMap(base_dir)
        self.map.objects = []
        self.map.world_w = 9999999
        self.map.world_h = 9999999
        
        # Day / Night Phase
        self.time_of_day = "DAY"
        self.phase_duration = 600.0
        self.phase_timer = 0.0
        
        # "Work In Progress" prompt
        self.wip_timer = 0.0
        self.wip_message = ""
        
        # Placed Custom Tiles Array in Sandbox World
        self.placed_tiles = []
        
        # Palette UI Geometry
        self.palette_open = False
        self.active_cat_idx = 0
        self.scroll_y = 0
        self.selected_tile = None
        self.selected_tile_idx = -1
        self.selected_tile_name = ""
        self.delete_mode = False
        
        # Multi-Layer System Setup (Layer 1: Floor/Base, Layer 2: Structures/Walls, Layer 3: Details/Overlays, Layer 4: Collision)
        self.active_layer = 1
        self.layers_dropdown_open = False
        self.layers_anim_progress = 0.0
        
        self.saves_dir = os.path.join(base_dir, 'TAS_saves')
        os.makedirs(self.saves_dir, exist_ok=True)
        self.save_input_active = False
        self.save_input_text = ""
        self.loading_action = None
        self.loading_progress = 0.0
        self.loading_target_file = ""
        self.saves_list = []
        self.viewing_saves = False

        # Helper to resolve asset paths in dev & frozen bundle
        def get_cat_path(*subpath):
            p = os.path.join(base_dir, *subpath)
            if os.path.exists(p): return p
            if getattr(sys, 'frozen', False):
                p_meipass = os.path.join(getattr(sys, '_MEIPASS', base_dir), *subpath)
                if os.path.exists(p_meipass): return p_meipass
            return p

        # Tile Categories (Dungeon, Terrain/Grass, Nature, Heroes, Decor, Walls, Props, Food, Save, Load)
        self.categories = [
            {"name": "Dungeon", "folder": get_cat_path('3D_Assets', '2D Pixel Dungeon Asset Pack', 'character and tileset', 'Dungeon_Tileset_Split')},
            {"name": "Terrain", "folder": get_cat_path('Tilesets', 'Jungle_Split')},
            {"name": "Nature", "folder": get_cat_path('Tilesets', 'Example_Split')},
            {"name": "Heroes", "folder": get_cat_path('3D_Assets', '2D Pixel Dungeon Asset Pack', 'character and tileset', 'Dungeon_Character_Split')},
            {"name": "Decor", "folder": get_cat_path('furnitures', 'nws', 'sierrassets furniture pack', 'furniture', 'individual sprites')},
            {"name": "Walls", "folder": get_cat_path('furnitures', 'nws', 'sierrassets furniture pack', 'floors and walls', 'individual sprites')},
            {"name": "Props", "folder": get_cat_path('Props', 'props1')},
            {"name": "Food", "folder": get_cat_path('Props', 'Food')},
            {"name": "[SAVE]", "folder": ""},
            {"name": "[LOAD]", "folder": ""}
        ]

        self.update_dimensions(width, height)
        self.cat_tiles = {}
        self.load_category_tiles()
        self.bot = SandboxBot(self)

    def update_dimensions(self, width, height):
        self.width = width
        self.height = height
        if hasattr(self, 'camera'):
            self.camera.width = width
            self.camera.height = height
            
        self.panel_w = max(340, min(500, int(width * 0.28)))
        self.nav_w = 64
        self.panel_rect = pygame.Rect(width - self.panel_w, 0, self.panel_w, height)
        self.nav_rect = pygame.Rect(width - self.nav_w, 0, self.nav_w, height)
        self.grid_rect = pygame.Rect(width - self.panel_w, 0, self.panel_w - self.nav_w, height)
        if hasattr(self, 'bot'):
            self.bot.btn_bot_rect = pygame.Rect(width - 200, 14, 185, 32)

    def load_category_tiles(self):
        import re
        def natural_sort_key(s):
            return [int(c) if c.isdigit() else c.lower() for c in re.split('([0-9]+)', s)]

        for idx, cat in enumerate(self.categories):
            folder = cat["folder"]
            tile_list = []
            if folder and os.path.exists(folder):
                files = sorted([f for f in os.listdir(folder) if f.endswith('.png')], key=natural_sort_key)
                for f in files[:250]: # Smooth grid rendering
                    p = os.path.join(folder, f)
                    try:
                        img = pygame.image.load(p).convert_alpha()
                        scaled = pygame.transform.scale(img, (48, 48))
                        tile_list.append({"surf": scaled, "path": p, "name": f})
                    except Exception:
                        pass
            self.cat_tiles[idx] = tile_list

    def refresh_saves_list(self):
        if os.path.exists(self.saves_dir):
            self.saves_list = [f for f in os.listdir(self.saves_dir) if f.endswith('.json')]
        else:
            self.saves_list = []

    def execute_save(self, filename):
        data = []
        for t in self.placed_tiles:
            data.append({
                "x": t["x"],
                "y": t["y"],
                "name": t.get("name", ""),
                "layer": t.get("layer", 1)
            })
        path = os.path.join(self.saves_dir, f"{filename}.json")
        try:
            with open(path, "w") as f:
                json.dump(data, f)
        except Exception:
            pass

    def execute_load(self, filename):
        path = os.path.join(self.saves_dir, filename)
        if not os.path.exists(path):
            return
        try:
            with open(path, "r") as f:
                data = json.load(f)
            self.placed_tiles = []
            
            # Map name to surface from preloaded categories
            name_map = {}
            for tlist in self.cat_tiles.values():
                for t in tlist:
                    if t["name"] not in name_map:
                        name_map[t["name"]] = t["surf"]
                        
            for item in data:
                surf = name_map.get(item["name"])
                if surf:
                    self.placed_tiles.append({
                        "surf": surf,
                        "name": item["name"],
                        "x": item["x"],
                        "y": item["y"],
                        "layer": item.get("layer", 1),
                        "rect": pygame.Rect(item["x"], item["y"], 48, 48)
                    })
        except Exception:
            pass

    def update(self, dt, events):
        # Update Dimensions based on current display surface
        surf = pygame.display.get_surface()
        if surf:
            cur_w, cur_h = surf.get_size()
            if cur_w != self.width or cur_h != self.height:
                self.update_dimensions(cur_w, cur_h)

        if self.loading_action:
            self.loading_progress += dt * 2.0
            if self.loading_progress >= 1.0:
                if self.loading_action == "saving":
                    self.execute_save(self.loading_target_file)
                elif self.loading_action == "loading":
                    self.execute_load(self.loading_target_file)
                self.loading_action = None
            return

        keys = pygame.key.get_pressed()
        mx, my = pygame.mouse.get_pos()
        
        # Smooth lerp animation for Layers dropdown
        target_anim = 1.0 if self.layers_dropdown_open else 0.0
        self.layers_anim_progress += (target_anim - self.layers_anim_progress) * min(1.0, dt * 18.0)
        
        # Disable player attack slash animation when palette is open or holding tile
        self.player.disable_attack = self.palette_open or (self.selected_tile is not None)

        if not hasattr(self, 'is_map_dragging'):
            self.is_map_dragging = False

        # Input Events
        if events:
            for event in events:
                if self.save_input_active:
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_RETURN and self.save_input_text:
                            self.loading_action = "saving"
                            self.loading_progress = 0.0
                            self.loading_target_file = self.save_input_text
                            self.save_input_active = False
                        elif event.key == pygame.K_BACKSPACE:
                            self.save_input_text = self.save_input_text[:-1]
                        elif event.key == pygame.K_ESCAPE:
                            self.save_input_active = False
                        else:
                            if event.unicode.isalnum() or event.unicode in [' ', '_', '-']:
                                self.save_input_text += event.unicode
                    continue
                
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_F4:
                        if hasattr(self, 'bot'):
                            self.bot.toggle()
                    elif event.key == pygame.K_0:
                        self.palette_open = not self.palette_open
                    elif event.key == pygame.K_x:
                        self.delete_mode = not self.delete_mode
                    elif event.key == pygame.K_ESCAPE:
                        if self.palette_open:
                            self.palette_open = False
                            self.selected_tile = None
                            self.selected_tile_idx = -1
                        elif self.selected_tile is not None:
                            self.selected_tile = None
                            self.selected_tile_idx = -1
                        else:
                            self.request_main_menu = True

                # Mouse Wheel Scroll in Palette Grid
                if self.palette_open and self.grid_rect.collidepoint(mx, my):
                    if event.type == pygame.MOUSEWHEEL:
                        self.scroll_y = max(0, self.scroll_y - event.y * 36)

                if event.type == pygame.MOUSEBUTTONUP:
                    if event.button == 1:
                        self.is_map_dragging = False

                # Mouse Click Events
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if hasattr(self, 'bot') and self.bot.btn_bot_rect.collidepoint(mx, my):
                        self.bot.toggle()
                        continue

                # Mouse Click Events inside Palette
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if self.palette_open and self.panel_rect.collidepoint(mx, my):
                        self.is_map_dragging = False
                        
                        # 1. Click Category Navigation Sidebar (on right edge of palette)
                        if self.nav_rect.collidepoint(mx, my) and event.button == 1:
                            btn_h = max(36, min(48, self.height // (len(self.categories) + 6)))
                            cat_clicked = my // btn_h
                            if 0 <= cat_clicked < len(self.categories):
                                cat_name = self.categories[cat_clicked]["name"]
                                if cat_name == "[SAVE]":
                                    self.save_input_active = True
                                    self.save_input_text = ""
                                elif cat_name == "[LOAD]":
                                    self.viewing_saves = True
                                    self.refresh_saves_list()
                                    self.active_cat_idx = cat_clicked
                                    self.scroll_y = 0
                                    self.selected_tile_idx = -1
                                    self.layers_dropdown_open = False
                                else:
                                    self.viewing_saves = False
                                    self.active_cat_idx = cat_clicked
                                    self.scroll_y = 0
                                    self.selected_tile_idx = -1
                                    self.layers_dropdown_open = False
                            
                            # Layers Dropdown Header
                            elif cat_clicked == len(self.categories):
                                self.layers_dropdown_open = not self.layers_dropdown_open
                            
                            # Layers Dropdown Items
                            elif self.layers_dropdown_open and cat_clicked > len(self.categories):
                                layer_item = cat_clicked - len(self.categories)
                                if 1 <= layer_item <= 4:
                                    self.active_layer = layer_item
                                    self.layers_dropdown_open = False
                        
                        # 2. Click Tile in Palette Grid -> Select Tile
                        elif self.grid_rect.collidepoint(mx, my) and event.button == 1:
                            if self.viewing_saves:
                                cell_h = 40
                                grid_top = self.grid_rect.top + 10 - self.scroll_y
                                for idx, sname in enumerate(self.saves_list):
                                    save_box = pygame.Rect(self.grid_rect.left + 10, grid_top + idx * cell_h, self.grid_rect.width - 20, 35)
                                    if save_box.collidepoint(mx, my):
                                        if getattr(self, 'delete_mode', False):
                                            os.remove(os.path.join(self.saves_dir, sname))
                                            self.refresh_saves_list()
                                        else:
                                            self.loading_action = "loading"
                                            self.loading_progress = 0.0
                                            self.loading_target_file = sname
                                            self.palette_open = False
                                        break
                                continue
                            
                            tiles = self.cat_tiles.get(self.active_cat_idx, [])
                            cell_w = 54
                            cols = max(1, (self.grid_rect.width - 16) // cell_w)
                            grid_left = self.grid_rect.left + 10
                            grid_top = self.grid_rect.top + 10 - self.scroll_y
                            
                            for idx, t in enumerate(tiles):
                                c = idx % cols
                                r = idx // cols
                                tile_box = pygame.Rect(grid_left + c * cell_w, grid_top + r * cell_w, 48, 48)
                                if tile_box.collidepoint(mx, my):
                                    self.selected_tile = t["surf"]
                                    self.selected_tile_idx = idx
                                    self.selected_tile_name = t.get("name", "")
                                    self.delete_mode = False
                                    break

                    elif self.palette_open:
                        # Click on World Map
                        if event.button == 1:
                            self.is_map_dragging = True
                            world_mx = mx - self.camera.float_x
                            world_my = my - self.camera.float_y
                            gx = int(math.floor(world_mx / 48.0) * 48)
                            gy = int(math.floor(world_my / 48.0) * 48)
                            
                            if self.delete_mode:
                                matching = [t for t in self.placed_tiles if (t["x"] == gx and t["y"] == gy)]
                                if matching:
                                    target_del = next((t for t in matching if t.get("layer", 1) == self.active_layer), max(matching, key=lambda t: t.get("layer", 1)))
                                    self.placed_tiles.remove(target_del)
                            elif self.selected_tile is not None:
                                self.placed_tiles = [t for t in self.placed_tiles if not (t["x"] == gx and t["y"] == gy and t.get("layer", 1) == self.active_layer)]
                                self.placed_tiles.append({
                                    "surf": self.selected_tile,
                                    "name": getattr(self, 'selected_tile_name', ""),
                                    "x": gx,
                                    "y": gy,
                                    "layer": self.active_layer,
                                    "rect": pygame.Rect(gx, gy, 48, 48)
                                })

        # Handle Continuous Drag Placement / Deletion on World Map
        mouse_pressed = pygame.mouse.get_pressed()
        if self.palette_open and not self.panel_rect.collidepoint(mx, my):
            world_mx = mx - self.camera.float_x
            world_my = my - self.camera.float_y
            gx = int(math.floor(world_mx / 48.0) * 48)
            gy = int(math.floor(world_my / 48.0) * 48)
            
            if mouse_pressed[0] and getattr(self, 'is_map_dragging', False):
                if self.delete_mode:
                    matching = [t for t in self.placed_tiles if (t["x"] == gx and t["y"] == gy)]
                    if matching:
                        target_del = next((t for t in matching if t.get("layer", 1) == self.active_layer), max(matching, key=lambda t: t.get("layer", 1)))
                        self.placed_tiles.remove(target_del)
                elif self.selected_tile is not None:
                    if not any(t["x"] == gx and t["y"] == gy and t.get("layer", 1) == self.active_layer for t in self.placed_tiles):
                        self.placed_tiles.append({
                            "surf": self.selected_tile,
                            "name": getattr(self, 'selected_tile_name', ""),
                            "x": gx,
                            "y": gy,
                            "layer": self.active_layer,
                            "rect": pygame.Rect(gx, gy, 48, 48)
                        })
            
            # RMB Secondary Delete
            elif mouse_pressed[2]:
                matching = [t for t in self.placed_tiles if t["rect"].collidepoint(world_mx, world_my)]
                if matching:
                    target_del = next((t for t in matching if t.get("layer", 1) == self.active_layer), max(matching, key=lambda t: t.get("layer", 1)))
                    self.placed_tiles.remove(target_del)

        if self.wip_timer > 0:
            self.wip_timer -= dt

        # Update Player & Camera
        self.player.update(dt, keys, self.map)
        self.camera.update(self.player.rect, dt)

        if hasattr(self, 'bot'):
            self.bot.update(dt)

    def draw_infinite_procedural_grass(self, surface):
        surface.fill((108, 175, 55))
        
        cam_x = -self.camera.float_x
        cam_y = -self.camera.float_y
        chunk_size = 64
        
        start_c = math.floor(cam_x / chunk_size) - 1
        end_c = math.ceil((cam_x + surface.get_width()) / chunk_size) + 1
        start_r = math.floor(cam_y / chunk_size) - 1
        end_r = math.ceil((cam_y + surface.get_height()) / chunk_size) + 1
        
        has_small = hasattr(self.map, 'grass_small_img')
        has_tall = hasattr(self.map, 'grass_tall_img')
        
        for r in range(start_r, end_r):
            for c in range(start_c, end_c):
                h = hash((c, r, self.world_seed))
                if h % 100 < 40:
                    offset_x = (h % 37)
                    offset_y = ((h >> 3) % 37)
                    screen_x = c * chunk_size + offset_x + self.camera.float_x
                    screen_y = r * chunk_size + offset_y + self.camera.float_y
                    
                    if (h % 2 == 0) and has_small:
                        surface.blit(self.map.grass_small_img, (screen_x, screen_y))
                    elif has_tall:
                        surface.blit(self.map.grass_tall_img, (screen_x, screen_y))

    def draw(self, surface):
        # Update Dimensions dynamically to match screen/window
        self.update_dimensions(surface.get_width(), surface.get_height())
        surface.fill((0, 0, 0))
        
        # 1. Draw Infinite Procedural Grass Map
        self.draw_infinite_procedural_grass(surface)
        
        # 2. Draw Player (top-down character)
        self.player.draw(surface, self.camera)
        
        # 3. Draw Placed Custom Sandbox Tiles (Sorted by Layer)
        sorted_placed = sorted(self.placed_tiles, key=lambda t: t.get("layer", 1))
        for t in sorted_placed:
            if t.get("layer", 1) == 4 and not self.palette_open and not self.delete_mode:
                continue
            screen_pos = self.camera.apply_rect(t["rect"])
            surface.blit(t["surf"], screen_pos)
            
        # 4. Draw Hover Reticle
        mx, my = pygame.mouse.get_pos()
        if self.palette_open and not self.panel_rect.collidepoint(mx, my):
            world_mx = mx - self.camera.float_x
            world_my = my - self.camera.float_y
            grid_x = math.floor(world_mx / 48.0) * 48
            grid_y = math.floor(world_my / 48.0) * 48
            
            hover_rect = self.camera.apply_rect(pygame.Rect(grid_x, grid_y, 48, 48))
            
            if self.delete_mode:
                red_surf = pygame.Surface((48, 48), pygame.SRCALPHA)
                red_surf.fill((255, 50, 50, 90))
                surface.blit(red_surf, hover_rect)
                pygame.draw.rect(surface, (255, 60, 60), hover_rect, 2)
                pygame.draw.line(surface, (255, 60, 60), (hover_rect.left + 12, hover_rect.top + 12), (hover_rect.right - 12, hover_rect.bottom - 12), 2)
                pygame.draw.line(surface, (255, 60, 60), (hover_rect.left + 12, hover_rect.bottom - 12), (hover_rect.right - 12, hover_rect.top + 12), 2)
            elif self.selected_tile is not None:
                ghost = self.selected_tile.copy()
                ghost.set_alpha(160)
                surface.blit(ghost, hover_rect)
                pygame.draw.rect(surface, (255, 255, 255), hover_rect, 2)

        # 5. Draw Sandbox HUD
        font_hud = pygame.font.SysFont("couriernew", 14, bold=True)
        if self.delete_mode:
            hud_txt = font_hud.render(f"DELETE MODE ACTIVE [X] | Layer: {self.active_layer} | [ESC] Exit", False, (255, 90, 90))
        else:
            hud_txt = font_hud.render(f"SANDBOX MODE (Press '0' for Palette | Layer: {self.active_layer} | [ESC] Menu)", False, (100, 255, 180))
        surface.blit(hud_txt, (20, 20))

        # 6. DRAW PALETTE PANEL ON RIGHT SIDE
        if self.palette_open:
            # Panel Background
            pygame.draw.rect(surface, (12, 10, 16), self.panel_rect)
            pygame.draw.rect(surface, (255, 255, 255), self.panel_rect, 1)

            # A. Navigation Sidebar (Right side of panel)
            pygame.draw.rect(surface, (20, 16, 26), self.nav_rect)
            pygame.draw.rect(surface, (255, 255, 255), self.nav_rect, 1)

            cat_font = pygame.font.SysFont("couriernew", 11, bold=True)
            btn_h = max(36, min(48, self.height // (len(self.categories) + 6)))

            # Render Category Buttons
            for idx, cat in enumerate(self.categories):
                c_rect = pygame.Rect(self.nav_rect.left, idx * btn_h, self.nav_w, btn_h)
                is_active = (idx == self.active_cat_idx)
                
                bg = (50, 40, 65) if is_active else (20, 16, 26)
                pygame.draw.rect(surface, bg, c_rect)
                pygame.draw.rect(surface, (255, 215, 100) if is_active else (80, 70, 90), c_rect, 1)
                
                txt = cat_font.render(cat["name"][:6], False, (255, 230, 120) if is_active else (180, 180, 190))
                surface.blit(txt, (c_rect.centerx - txt.get_width() // 2, c_rect.centery - txt.get_height() // 2))

            # Layers Dropdown Button
            layers_btn_y = len(self.categories) * btn_h
            layers_header_rect = pygame.Rect(self.nav_rect.left, layers_btn_y, self.nav_w, btn_h)
            
            pygame.draw.rect(surface, (45, 30, 60) if self.layers_dropdown_open else (20, 16, 26), layers_header_rect)
            pygame.draw.rect(surface, (255, 255, 255), layers_header_rect, 1)
            
            layers_lbl = cat_font.render("Layers", False, (255, 220, 100) if self.layers_dropdown_open else (220, 220, 220))
            surface.blit(layers_lbl, (layers_header_rect.centerx - layers_lbl.get_width() // 2, layers_header_rect.centery - 6))
            
            arrow_str = "▲" if self.layers_dropdown_open else "▼"
            arrow_lbl = cat_font.render(arrow_str, False, (255, 220, 100) if self.layers_dropdown_open else (180, 180, 180))
            surface.blit(arrow_lbl, (layers_header_rect.centerx - arrow_lbl.get_width() // 2, layers_header_rect.centery + 8))

            # Animated Layers Dropdown Menu
            if self.layers_anim_progress > 0.01:
                dropdown_max_h = 4 * btn_h
                current_h = int(dropdown_max_h * self.layers_anim_progress)
                dropdown_container = pygame.Rect(self.nav_rect.left, layers_btn_y + btn_h, self.nav_w, current_h)
                
                old_clip = surface.get_clip()
                surface.set_clip(dropdown_container)
                
                pygame.draw.rect(surface, (10, 10, 15), dropdown_container)
                pygame.draw.rect(surface, (255, 255, 255), dropdown_container, 1)
                
                for l_num in range(1, 5):
                    l_rect = pygame.Rect(self.nav_rect.left, layers_btn_y + l_num * btn_h, self.nav_w, btn_h)
                    is_layer_active = (l_num == self.active_layer)
                    
                    l_bg = (60, 45, 80) if is_layer_active else (25, 20, 35)
                    pygame.draw.rect(surface, l_bg, l_rect)
                    pygame.draw.rect(surface, (255, 215, 100) if is_layer_active else (60, 50, 70), l_rect, 1)
                    
                    l_txt = cat_font.render(f"Lyr {l_num}", False, (255, 230, 90) if is_layer_active else (200, 200, 210))
                    surface.blit(l_txt, (l_rect.centerx - l_txt.get_width() // 2, l_rect.centery - l_txt.get_height() // 2))

                surface.set_clip(old_clip)

            # B. Tile Grid Panel (Left side of Palette)
            old_clip = surface.get_clip()
            surface.set_clip(self.grid_rect)
            
            if getattr(self, "viewing_saves", False):
                cell_h = 40
                grid_top = self.grid_rect.top + 10 - self.scroll_y
                for idx, sname in enumerate(self.saves_list):
                    save_box = pygame.Rect(self.grid_rect.left + 10, grid_top + idx * cell_h, self.grid_rect.width - 20, 35)
                    is_del = getattr(self, 'delete_mode', False)
                    pygame.draw.rect(surface, (70, 20, 20) if is_del else (40, 40, 50), save_box)
                    pygame.draw.rect(surface, (255, 50, 50) if is_del else (255, 255, 255), save_box, 1)
                    prefix = "[DELETE] " if is_del else ""
                    txt = pygame.font.SysFont("couriernew", 12, bold=True).render(prefix + sname, False, (255, 100, 100) if is_del else (255, 255, 255))
                    surface.blit(txt, (save_box.x + 10, save_box.y + 8))
            else:
                tiles = self.cat_tiles.get(self.active_cat_idx, [])
                cell_w = 54
                cols = max(1, (self.grid_rect.width - 16) // cell_w)
                grid_left = self.grid_rect.left + 8
                grid_top = self.grid_rect.top + 8 - self.scroll_y

                for idx, t in enumerate(tiles):
                    c = idx % cols
                    r = idx // cols
                    tile_box = pygame.Rect(grid_left + c * cell_w, grid_top + r * cell_w, 48, 48)
                    
                    if tile_box.bottom > 0 and tile_box.top < self.height:
                        pygame.draw.rect(surface, (24, 20, 32), tile_box, border_radius=4)
                        surface.blit(t["surf"], tile_box.topleft)
                        
                        if idx == self.selected_tile_idx:
                            pygame.draw.rect(surface, (255, 220, 100), tile_box, 2, border_radius=4)
                        else:
                            pygame.draw.rect(surface, (60, 50, 75), tile_box, 1, border_radius=4)

            surface.set_clip(old_clip)

        if getattr(self, "save_input_active", False):
            overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 180))
            surface.blit(overlay, (0, 0))
            box = pygame.Rect(self.width // 2 - 300, self.height // 2 - 50, 600, 100)
            pygame.draw.rect(surface, (30, 25, 40), box, border_radius=8)
            pygame.draw.rect(surface, (255, 215, 100), box, 2, border_radius=8)
            font = pygame.font.SysFont("couriernew", 18, bold=True)
            lbl = font.render("Enter Save Name (ENTER to Save, ESC to Cancel):", False, (255, 255, 255))
            surface.blit(lbl, (box.x + 20, box.y + 16))
            txt = font.render(self.save_input_text + "_", False, (100, 255, 100))
            surface.blit(txt, (box.x + 20, box.y + 54))
            
        if getattr(self, "loading_action", None):
            overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 220))
            surface.blit(overlay, (0, 0))
            font = pygame.font.SysFont("couriernew", 26, bold=True)
            action_str = "SAVING..." if self.loading_action == "saving" else "LOADING..."
            txt = font.render(action_str, False, (255, 220, 100))
            surface.blit(txt, txt.get_rect(center=(self.width // 2, self.height // 2)))

        if hasattr(self, 'bot'):
            self.bot.draw_hud(surface)
