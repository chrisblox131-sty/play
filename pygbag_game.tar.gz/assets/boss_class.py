class BossEnemy:
    def __init__(self, x, y):
        self.x = float(x)
        self.y = float(y)
        self.facing_right = True
        self.speed = 2.0
        
        self.anim_timer = 0
        self.frame_index = 0
        self.current_anim = "idle"
        
        self.animations = self.load_anims()
        
        self.image = self.animations["idle"][0]
        # Frame size is 126x39. Scaled by 3 = 378 x 117
        self.rect = pygame.Rect(self.x, self.y, 100, 80)
        
        self.y_velocity = 0.0
        self.is_grounded = False
        self.attack_cooldown = 0.0
        self.has_dealt_damage = False
        
        self.hp = 500
        self.max_hp = 500
        self.display_hp = 500.0
        self.stun_timer = 0.0
        
    def load_anims(self):
        base_dir = os.path.join(BASE_DIR, "Boss", "Ball and Chain Bot")
        anim_names = ["attack", "charge", "death", "hit", "idle", "run"]
        scale_w, scale_h = 126 * 3, 39 * 3
        anims = {}
        for name in anim_names:
            frames = []
            dir_path = os.path.join(base_dir, name)
            if os.path.exists(dir_path):
                count = len([f for f in os.listdir(dir_path) if f.endswith('.png')])
                for i in range(count):
                    img = pygame.image.load(os.path.join(dir_path, f"{i}.png")).convert_alpha()
                    img = pygame.transform.scale(img, (scale_w, scale_h))
                    frames.append(img)
            if not frames:
                s = pygame.Surface((scale_w, scale_h), pygame.SRCALPHA)
                s.fill((255, 0, 0, 100))
                frames.append(s)
            anims[name] = frames
        return anims

    def take_damage(self, amount, knockback_x=0):
        if self.hp <= 0: return
        self.hp -= amount
        self.x_velocity = knockback_x * 0.5
        if self.hp <= 0:
            self.hp = 0
            self.set_anim("death")
        elif self.current_anim not in ["death", "attack", "charge"]:
            self.set_anim("hit")

    def set_anim(self, anim_name):
        if self.current_anim == anim_name: return
        self.current_anim = anim_name
        self.frame_index = 0
        self.anim_timer = 0

    def update(self, dt, platforms):
        self.y_velocity += GRAVITY
        
        if self.attack_cooldown > 0:
            self.attack_cooldown -= dt
            
        if self.display_hp > self.hp:
            self.display_hp -= (self.display_hp - self.hp) * 5.0 * dt
            if self.display_hp < self.hp: self.display_hp = self.hp
            
        if self.hp > 0 and self.stun_timer <= 0 and self.current_anim not in ["hit", "death", "attack"]:
            if self.current_anim != "run":
                self.set_anim("run")
                
            dx = self.speed if self.facing_right else -self.speed
            self.x += dx
            self.rect.x = int(self.x)
            
            for plat_dict in platforms:
                if self.rect.colliderect(plat_dict["rect"]):
                    if dx > 0:
                        self.rect.right = plat_dict["rect"].left
                    elif dx < 0:
                        self.rect.left = plat_dict["rect"].right
                    self.x = float(self.rect.x)
                    break
                    
        elif self.current_anim == "run" and (self.stun_timer > 0 or self.current_anim in ["attack"]):
            self.set_anim("idle")
            
        if self.stun_timer > 0:
            self.stun_timer -= dt

        self.y += self.y_velocity
        self.rect.y = int(self.y)
        self.is_grounded = False
        
        for plat_dict in platforms:
            if self.rect.colliderect(plat_dict["rect"]):
                if self.y_velocity > 0:
                    self.rect.bottom = plat_dict["rect"].top
                    self.y = float(self.rect.y)
                    self.y_velocity = 0
                    self.is_grounded = True
                elif self.y_velocity < 0:
                    self.rect.top = plat_dict["rect"].bottom
                    self.y = float(self.rect.y)
                    self.y_velocity = 0

        self.rect.midbottom = (self.rect.centerx, self.rect.bottom)

        self.anim_timer += dt
        anim_speed = 0.1
        frames = self.animations.get(self.current_anim, self.animations["idle"])
        
        if self.anim_timer >= anim_speed:
            self.anim_timer = 0
            self.frame_index += 1
            if self.frame_index >= len(frames):
                if self.current_anim == "death":
                    self.frame_index = len(frames) - 1
                elif self.current_anim in ["hit", "attack"]:
                    self.set_anim("idle" if self.stun_timer > 0 else "run")
                    frames = self.animations.get(self.current_anim, self.animations["idle"])
                    if self.current_anim == "attack":
                        self.attack_cooldown = 2.0
                else:
                    self.frame_index = 0
                    
        self.image = frames[self.frame_index]
        if not self.facing_right:
            self.image = pygame.transform.flip(self.image, True, False)

    def draw(self, surface, camera):
        draw_rect = self.image.get_rect(midbottom=self.rect.midbottom)
        offset_rect = camera.apply_rect(draw_rect)
        surface.blit(self.image, offset_rect)
        
        if self.stun_timer > 0:
            ice_rect = camera.apply_rect(self.rect).inflate(20, 20)
            pygame.draw.rect(surface, (173, 216, 230), ice_rect, 4)

