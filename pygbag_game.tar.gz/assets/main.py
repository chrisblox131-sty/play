import os
import sys
import asyncio

# Ensure DLL path for Python 3.14 on Windows
if hasattr(os, 'add_dll_directory'):
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        os.add_dll_directory(base_dir)
        internal_dir = os.path.join(base_dir, '_internal')
        if os.path.exists(internal_dir):
            os.add_dll_directory(internal_dir)
    except Exception:
        pass

import pygame
import random
import math
import glob
from touch_controls import VirtualTouchController
from translations import (
    SUPPORTED_LANGUAGES, LANGUAGE_LABELS, LANGUAGE_NAMES,
    LANGUAGE_FLAGS, t, load_settings, save_settings
)

# --- INITIALIZATION ---
pygame.init()
pygame.font.init()
try:
    pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)
except Exception:
    pass

if getattr(sys, 'frozen', False):
    BASE_DIR = getattr(sys, '_MEIPASS', os.path.dirname(sys.executable))
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# --- CONSTANTS ---
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
SCALE = 4
FPS = 60

# Physics
GRAVITY = 0.75
MOVE_SPEED = 5.5
JUMP_STRENGTH = -16.5

# --- WINDOW SETUP ---
real_screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("The Awaiting Stars: Two Worlds, One Destiny")
render_canvas = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
screen = render_canvas

def get_mouse_pos():
    raw_x, raw_y = pygame.mouse.get_pos()
    win_w, win_h = real_screen.get_size()
    scale = min(win_w / WINDOW_WIDTH, win_h / WINDOW_HEIGHT)
    scaled_w, scaled_h = int(WINDOW_WIDTH * scale), int(WINDOW_HEIGHT * scale)
    offset_x = (win_w - scaled_w) // 2
    offset_y = (win_h - scaled_h) // 2
    if scale <= 0: return (0, 0)
    canvas_x = int((raw_x - offset_x) / scale)
    canvas_y = int((raw_y - offset_y) / scale)
    return (canvas_x, canvas_y)

def flip_display():
    win_w, win_h = real_screen.get_size()
    if win_w != WINDOW_WIDTH or win_h != WINDOW_HEIGHT:
        scale = min(win_w / WINDOW_WIDTH, win_h / WINDOW_HEIGHT)
        scaled_w, scaled_h = int(WINDOW_WIDTH * scale), int(WINDOW_HEIGHT * scale)
        offset_x = (win_w - scaled_w) // 2
        offset_y = (win_h - scaled_h) // 2
        real_screen.fill((0, 0, 0))
        scaled_surf = pygame.transform.scale(render_canvas, (scaled_w, scaled_h))
        real_screen.blit(scaled_surf, (offset_x, offset_y))
    else:
        real_screen.blit(render_canvas, (0, 0))
    pygame.display.flip()

# --- ASSET HELPERS ---
def get_asset_path(*parts):
    # Check direct relative path
    p = os.path.join(BASE_DIR, *parts)
    if os.path.exists(p): return p
    # Check _internal if frozen
    if getattr(sys, 'frozen', False):
        p_int = os.path.join(getattr(sys, '_MEIPASS', BASE_DIR), *parts)
        if os.path.exists(p_int): return p_int
    return p

def load_animation(folder_name, anim_name, scale=SCALE):
    frames = []
    # Search in folder
    pattern = os.path.join(BASE_DIR, folder_name, f"{anim_name}_*.png")
    files = glob.glob(pattern)
    if not files and getattr(sys, 'frozen', False):
        pattern = os.path.join(getattr(sys, '_MEIPASS', BASE_DIR), folder_name, f"{anim_name}_*.png")
        files = glob.glob(pattern)
    
    # Sort files numerically
    def get_frame_num(path):
        base = os.path.splitext(os.path.basename(path))[0]
        parts = base.split('_')
        for p in reversed(parts):
            if p.isdigit(): return int(p)
        return 0

    files = sorted(files, key=get_frame_num)
    for f in files:
        try:
            img = pygame.image.load(f).convert_alpha()
            w, h = img.get_size()
            scaled = pygame.transform.scale(img, (int(w * scale), int(h * scale)))
            frames.append(scaled)
        except Exception:
            pass

    if not frames:
        # Fallback colored surface
        s = pygame.Surface((32 * scale, 32 * scale), pygame.SRCALPHA)
        s.fill((100, 150, 240, 200))
        frames.append(s)
    return frames

# --- LOAD SOUND EFFECTS ---
def find_sfx(filename):
    search_dirs = [
        os.path.join(BASE_DIR, "Voices_Soundeffect"),
        os.path.join(BASE_DIR, "Voices_Soundeffect", "Free Fantasy SFX Pack By TomMusic", "WAV Files", "SFX"),
        BASE_DIR
    ]
    if getattr(sys, 'frozen', False):
        meipass = getattr(sys, '_MEIPASS', BASE_DIR)
        search_dirs.insert(0, os.path.join(meipass, "Voices_Soundeffect"))
        search_dirs.insert(1, meipass)

    for sdir in search_dirs:
        if os.path.exists(sdir):
            for root, dirs, files in os.walk(sdir):
                for f in files:
                    if f.lower() == filename.lower():
                        try:
                            return pygame.mixer.Sound(os.path.join(root, f))
                        except Exception:
                            pass
    return None

sfx_walk = [s for s in [find_sfx(f"Dirt Walk {i}.wav") for i in range(1, 6)] if s]
sfx_run = [s for s in [find_sfx(f"Dirt Run {i}.wav") for i in range(1, 6)] if s]
sfx_jump = find_sfx("Dirt Jump.wav")
sfx_land = find_sfx("Dirt Land.wav")
sfx_attack = [s for s in [find_sfx(f"Sword Attack {i}.wav") for i in (1, 2, 3)] if s]
sfx_hit = [s for s in [find_sfx(f"Sword Impact Hit {i}.wav") for i in (1, 2, 3)] if s]
sfx_block = [s for s in [find_sfx(f"Sword Blocked {i}.wav") for i in (1, 2, 3)] if s]
sfx_door_open = [s for s in [find_sfx(f"Door Open {i}.wav") for i in (1, 2)] if s]
footstep_channel = pygame.mixer.Channel(1)

# --- LOAD ICONS & UI ---
def load_icon(filename, size=(64, 64)):
    possible_paths = [
        os.path.join(BASE_DIR, "miscpic", filename),
        os.path.join(BASE_DIR, filename),
        os.path.join(BASE_DIR, "UI", filename),
    ]
    if getattr(sys, 'frozen', False):
        meipass = getattr(sys, '_MEIPASS', BASE_DIR)
        possible_paths.insert(0, os.path.join(meipass, "miscpic", filename))
        possible_paths.insert(1, os.path.join(meipass, filename))
        possible_paths.insert(2, os.path.join(meipass, "UI", filename))

    for p in possible_paths:
        if os.path.exists(p):
            try:
                img = pygame.image.load(p).convert_alpha()
                return pygame.transform.scale(img, size)
            except Exception:
                pass
    s = pygame.Surface(size, pygame.SRCALPHA)
    s.fill((80, 80, 80, 220))
    pygame.draw.rect(s, (200, 200, 200), (0, 0, size[0], size[1]), 2)
    return s

m1_icon_img = load_icon("m1_skill_icon.jpg", (64, 64))
showdown_icon_img = load_icon("showdown_icon.jpg", (48, 48))
shield_icon_img = load_icon("shield_icon.jpg", (64, 64))
broken_shield_icon_img = load_icon("broken_shield_icon.jpg", (64, 64))
skill_icon_img = load_icon("glacial_strike_icon.png", (64, 64))

# --- INVENTORY SYSTEM ---
show_inventory = False

def load_ui_inventory_frame(grid_size=300, pad=12):
    frame_w = grid_size + pad * 2 # 324
    frame_h = grid_size + pad * 2 # 324
    inv_dirs = [
        os.path.join(BASE_DIR, "UI", "UI INVENTORY"),
        os.path.join(BASE_DIR, "game_ui", "UI INVENTORY")
    ]
    if getattr(sys, 'frozen', False):
        meipass = getattr(sys, '_MEIPASS', BASE_DIR)
        inv_dirs.insert(0, os.path.join(meipass, "UI", "UI INVENTORY"))
        inv_dirs.insert(1, os.path.join(meipass, "game_ui", "UI INVENTORY"))

    for inv_dir in inv_dirs:
        cen_p = os.path.join(inv_dir, "1.png")
        if os.path.exists(cen_p):
            try:
                center = pygame.image.load(cen_p).convert_alpha()
                frame = pygame.Surface((frame_w, frame_h), pygame.SRCALPHA)
                # Dark drop shadow & outer bevel border
                pygame.draw.rect(frame, (18, 12, 8), (0, 0, frame_w, frame_h), border_radius=8)
                pygame.draw.rect(frame, (140, 90, 45), (0, 0, frame_w, frame_h), width=4, border_radius=8)
                pygame.draw.rect(frame, (190, 135, 75), (2, 2, frame_w - 4, frame_h - 4), width=2, border_radius=7)
                pygame.draw.rect(frame, (80, 48, 24), (5, 5, frame_w - 10, frame_h - 10), width=3, border_radius=5)
                pygame.draw.rect(frame, (45, 26, 14), (pad - 2, pad - 2, grid_size + 4, grid_size + 4), border_radius=3)
                
                # Blit scaled 1.png (4x4 inventory grid) snugly in center - NO ugly side slot strips!
                frame.blit(pygame.transform.scale(center, (grid_size, grid_size)), (pad, pad))
                return frame
            except Exception:
                pass

    return None

inv_bg_img = load_ui_inventory_frame(300, 12)

def load_inventory_item(filename, qty, name, desc, heal=0):
    paths = [
        os.path.join(BASE_DIR, "game_ui", "Humble Gift - Paper UI System v1.1", "Sprites", "Content", "1 Items", filename),
        os.path.join(BASE_DIR, "UI", "Humble Gift - Paper UI System v1.1", "Sprites", "Content", "1 Items", filename),
    ]
    if getattr(sys, 'frozen', False):
        meipass = getattr(sys, '_MEIPASS', BASE_DIR)
        paths.insert(0, os.path.join(meipass, "game_ui", "Humble Gift - Paper UI System v1.1", "Sprites", "Content", "1 Items", filename))
        paths.insert(1, os.path.join(meipass, "UI", "Humble Gift - Paper UI System v1.1", "Sprites", "Content", "1 Items", filename))

    for p in paths:
        if os.path.exists(p):
            try:
                img = pygame.image.load(p).convert_alpha()
                return {
                    "img": img,
                    "qty": qty,
                    "name": name,
                    "desc": desc,
                    "heal": heal,
                    "hover": False
                }
            except Exception:
                pass
    s = pygame.Surface((48, 48), pygame.SRCALPHA)
    pygame.draw.rect(s, (180, 140, 80), (4, 4, 40, 40), border_radius=4)
    return {"img": s, "qty": qty, "name": name, "desc": desc, "heal": heal, "hover": False}

inventory_items = [
    load_inventory_item("1.png", 1, "Book", "An ancient bound book filled with regional history and lore.", heal=0),
    load_inventory_item("19.png", 3, "Fresh River Trout", "Freshly caught river fish. Restores 25 HP when consumed.", heal=25),
    load_inventory_item("22.png", 12, "Steak", "Hearty cooked steak on the bone. Restores 40 HP when consumed.", heal=40),
    load_inventory_item("25.png", 1, "Health Leaf", "Medicinal green leaf. Heals 50 HP when consumed.", heal=50),
    load_inventory_item("14.png", 42, "Ancient Gold Coins", "Kingdom currency accepted across all realms.", heal=0)
]

try:
    from rpg_mode import WorldSocialStudiesCodexUI, GLOBAL_SOCIAL_STUDIES_DATA
    codex_ui = WorldSocialStudiesCodexUI(WINDOW_WIDTH, WINDOW_HEIGHT, BASE_DIR)
except Exception:
    codex_ui = None
    GLOBAL_SOCIAL_STUDIES_DATA = {}

show_codex = False
main_discoveries = set(GLOBAL_SOCIAL_STUDIES_DATA.keys())

def draw_inventory(surface, mouse_pos):
    global show_inventory, inventory_items, inv_bg_img
    if not show_inventory:
        return

    # Dark backdrop overlay
    dim = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
    dim.fill((0, 0, 0, 160))
    surface.blit(dim, (0, 0))

    pad = 12
    frame_w = 324
    frame_h = 324
    frame_x = (WINDOW_WIDTH - frame_w) // 2
    frame_y = 100

    # Draw centered frame
    if inv_bg_img is None:
        inv_bg_img = load_ui_inventory_frame(300, pad)

    if inv_bg_img:
        surface.blit(inv_bg_img, (frame_x, frame_y))
    else:
        panel_rect = pygame.Rect(frame_x, frame_y, frame_w, frame_h)
        pygame.draw.rect(surface, (235, 220, 190), panel_rect, border_radius=12)
        pygame.draw.rect(surface, (120, 80, 40), panel_rect, width=4, border_radius=12)

    # 1. Header Banner above the frame
    header_w = frame_w + 48
    header_rect = pygame.Rect((WINDOW_WIDTH - header_w) // 2, 28, header_w, 58)
    pygame.draw.rect(surface, (28, 20, 16), header_rect, border_radius=8)
    pygame.draw.rect(surface, (190, 140, 50), header_rect, width=3, border_radius=8)
    pygame.draw.rect(surface, (90, 60, 25), header_rect.inflate(-6, -6), width=1, border_radius=6)

    t_font = pygame.font.SysFont("consolas,couriernew,monospace", 17, bold=True)
    d_font = pygame.font.SysFont("consolas,couriernew,monospace", 11, bold=True)
    q_font = pygame.font.SysFont("consolas,couriernew,monospace", 12, bold=True)

    t_surf = t_font.render("ADVENTURER'S INVENTORY", True, (255, 220, 90))
    t_shadow = t_font.render("ADVENTURER'S INVENTORY", True, (15, 10, 5))
    surface.blit(t_shadow, t_shadow.get_rect(center=(WINDOW_WIDTH // 2 + 1, 49)))
    surface.blit(t_surf, t_surf.get_rect(center=(WINDOW_WIDTH // 2, 48)))

    s_surf = d_font.render("[E] / [ESC] Close   *   [J] World Codex   *   Hover items to inspect", True, (220, 200, 160))
    surface.blit(s_surf, s_surf.get_rect(center=(WINDOW_WIDTH // 2, 70)))

    # 2. Render Slots & Items
    hovered_item = None

    for idx, item in enumerate(inventory_items):
        row = idx // 4
        col = idx % 4
        slot_x = frame_x + pad + 3 * 4 + col * 17 * 4
        slot_y = frame_y + pad + 3 * 4 + row * 17 * 4
        slot_w = 64
        slot_rect = pygame.Rect(slot_x, slot_y, slot_w, slot_w)

        is_hover = slot_rect.collidepoint(mouse_pos)
        item["hover"] = is_hover
        if is_hover:
            hovered_item = item
            # Hover highlight around wooden slot
            glow_surf = pygame.Surface((slot_w, slot_w), pygame.SRCALPHA)
            glow_surf.fill((255, 220, 100, 45))
            pygame.draw.rect(glow_surf, (255, 215, 60, 230), (0, 0, slot_w, slot_w), width=2, border_radius=4)
            surface.blit(glow_surf, slot_rect)

        # Item Icon (centered in slot)
        icon_size = 48 if is_hover else 42
        icon_img = pygame.transform.scale(item["img"], (icon_size, icon_size))
        surface.blit(icon_img, icon_img.get_rect(center=slot_rect.center))

        # Quantity Badge
        q_str = str(item["qty"])
        q_txt = q_font.render(q_str, True, (255, 255, 240))
        q_shd = q_font.render(q_str, True, (0, 0, 0))
        bw = max(16, q_txt.get_width() + 6)
        bh = q_txt.get_height() + 2
        br = pygame.Rect(slot_rect.right - bw - 2, slot_rect.bottom - bh - 2, bw, bh)
        
        badge_surf = pygame.Surface((bw, bh), pygame.SRCALPHA)
        badge_surf.fill((15, 10, 8, 220))
        pygame.draw.rect(badge_surf, (180, 140, 60, 255), (0, 0, bw, bh), width=1, border_radius=3)
        badge_surf.blit(q_shd, (4, 1))
        badge_surf.blit(q_txt, (3, 0))
        surface.blit(badge_surf, br)

    # 3. Tooltip / Inspection Details Box below the frame
    detail_w = header_w
    tip_rect = pygame.Rect((WINDOW_WIDTH - detail_w) // 2, frame_y + frame_h + 10, detail_w, 74)
    pygame.draw.rect(surface, (24, 18, 14), tip_rect, border_radius=8)
    pygame.draw.rect(surface, (180, 130, 50), tip_rect, width=2, border_radius=8)

    if hovered_item:
        tip_icon = pygame.transform.scale(hovered_item["img"], (42, 42))
        surface.blit(tip_icon, (tip_rect.x + 12, tip_rect.y + 14))
        n_surf = pygame.font.SysFont("consolas,couriernew,monospace", 13, bold=True).render(f"{hovered_item['name']}  (x{hovered_item['qty']})", True, (255, 215, 80))
        surface.blit(n_surf, (tip_rect.x + 62, tip_rect.y + 8))

        # Word-wrap description cleanly so text never exceeds the tooltip tab!
        max_desc_w = tip_rect.width - 74
        words = hovered_item["desc"].split(" ")
        lines = []
        cur = ""
        for w in words:
            test = f"{cur} {w}".strip()
            if d_font.size(test)[0] <= max_desc_w:
                cur = test
            else:
                if cur:
                    lines.append(cur)
                cur = w
        if cur:
            lines.append(cur)

        for d_idx, d_line in enumerate(lines[:2]):
            d_surf = d_font.render(d_line, True, (230, 220, 200))
            surface.blit(d_surf, (tip_rect.x + 62, tip_rect.y + 32 + d_idx * 16))
    else:
        tip_placeholder = d_font.render("Hover over any item to inspect its stats and lore.", True, (190, 170, 140))
        surface.blit(tip_placeholder, tip_placeholder.get_rect(center=tip_rect.center))

# Load Background Layers
bg_layers = []
bg_dir = get_asset_path("Backgrounds")
if os.path.exists(bg_dir):
    bg_files = sorted(glob.glob(os.path.join(bg_dir, "*.png")))
    for f in bg_files:
        try:
            img = pygame.image.load(f).convert_alpha()
            bg_layers.append(pygame.transform.scale(img, (WINDOW_WIDTH, WINDOW_HEIGHT)))
        except Exception:
            pass

if not bg_layers:
    # Gradient night sky fallback
    grad = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
    for y in range(WINDOW_HEIGHT):
        ratio = y / WINDOW_HEIGHT
        r = int(10 + ratio * 20)
        g = int(15 + ratio * 25)
        b = int(35 + ratio * 45)
        pygame.draw.line(grad, (r, g, b), (0, y), (WINDOW_WIDTH, y))
    bg_layers.append(grad)

# --- 8-BIT COOLDOWN NUMBERS ---
PIXEL_NUMBERS = {
    1: [" 1 ", "11 ", " 1 ", " 1 ", "111"],
    2: ["111", "  1", "111", "1  ", "111"],
    3: ["111", "  1", "111", "  1", "111"],
    4: ["1 1", "1 1", "111", "  1", "  1"],
    5: ["111", "1  ", "111", "  1", "111"],
}

def draw_pixel_number(surface, num, center_x, center_y, pixel_size=6):
    layout = PIXEL_NUMBERS.get(num, PIXEL_NUMBERS[1])
    width = len(layout[0]) * pixel_size
    height = len(layout) * pixel_size
    start_x = center_x - width // 2
    start_y = center_y - height // 2
    for row_idx, row in enumerate(layout):
        for col_idx, char in enumerate(row):
            if char == "1":
                rect = pygame.Rect(start_x + col_idx * pixel_size, start_y + row_idx * pixel_size, pixel_size, pixel_size)
                pygame.draw.rect(surface, (255, 255, 255), rect)

# --- CAMERA ---
class Camera:
    def __init__(self, width, height):
        self.camera = pygame.Rect(0, 0, width, height)
        self.width = width
        self.height = height

    def apply(self, entity):
        return entity.rect.move(self.camera.topleft)

    def apply_rect(self, rect):
        return rect.move(self.camera.topleft)

    def update(self, target):
        x = -target.rect.centerx + int(WINDOW_WIDTH / 2)
        y = -target.rect.centery + int(WINDOW_HEIGHT / 2)
        x = min(0, x)  # left boundary
        y = min(0, max(-(self.height - WINDOW_HEIGHT), y))
        self.camera = pygame.Rect(x, y, self.width, self.height)

# --- PARTICLES & FLOATING TEXT ---
class FloatingText:
    def __init__(self, x, y, text, color=(255, 255, 255)):
        self.x = x
        self.y = y
        self.text = text
        self.color = color
        self.lifetime = 1.0
        self.timer = 0.0
        self.font = pygame.font.SysFont("couriernew", 18, bold=True)

    def update(self, dt):
        self.timer += dt
        self.y -= 35 * dt

    def draw(self, surface, camera):
        alpha = max(0, int(255 * (1.0 - (self.timer / self.lifetime))))
        txt_surf = self.font.render(self.text, True, self.color)
        txt_surf.set_alpha(alpha)
        rect = txt_surf.get_rect(center=(self.x, self.y))
        surface.blit(txt_surf, camera.apply_rect(rect))

# --- PROJECTILE ---
class Projectile:
    def __init__(self, x, y, direction):
        self.rect = pygame.Rect(x, y, 40, 20)
        self.speed = 12 * direction
        self.vx = self.speed
        self.direction = direction
        self.lifetime = 2.0
        self.timer = 0.0
        self.active = True

    def update(self, dt, platforms):
        self.timer += dt
        if self.timer >= self.lifetime:
            self.active = False
            return
        self.rect.x += int(self.speed)
        for plat in platforms:
            if self.rect.colliderect(plat):
                self.active = False
                break

    def draw(self, surface, camera):
        # Draw icy blue missile with glowing core
        r = camera.apply_rect(self.rect)
        pygame.draw.ellipse(surface, (120, 220, 255), r)
        pygame.draw.ellipse(surface, (230, 250, 255), r.inflate(-8, -4))

# --- ENTITIES ---
class Player:
    def __init__(self, x, y):
        # Folder 5: "idle" is idle breathing, "walk" is walking cycle
        self.animations = {
            "idle": load_animation("5", "idle", SCALE),
            "walk": load_animation("5", "walk", SCALE),
            "run": load_animation("5", "run", SCALE),
            "attack": load_animation("5", "attack", SCALE),
            "special": load_animation("5", "special", SCALE),
            "defend": load_animation("5", "defend", SCALE),
            "hurt": load_animation("5", "hurt", SCALE),
            "death": load_animation("5", "death", SCALE)
        }
        self.current_anim = "idle"
        self.frame_index = 0
        self.anim_timer = 0.0
        self.anim_speed = 0.08
        self.image = self.animations[self.current_anim][0]
        
        # Hitbox (centered at character feet)
        self.rect = pygame.Rect(x, y, 32 * SCALE // 2, 40 * SCALE)
        self.y_velocity = 0.0
        self.is_grounded = False
        self.facing_right = True

        # Combat Stats
        self.max_hp = 100
        self.hp = 100
        self.is_attacking = False
        self.is_special = False
        self.is_defending = False
        self.is_dead = False
        self.skill_cooldown = 0.0
        self.m1_cooldown = 0.0
        self.showdown_cooldown = 0.0
        self.shield_capacity = 100.0
        self.max_shield = 100.0
        self.has_dealt_sword_hit = False

        # Step sound timer
        self.step_timer = 0.0

    def set_animation(self, name):
        if self.current_anim != name and name in self.animations:
            self.current_anim = name
            self.frame_index = 0
            self.anim_timer = 0.0
            if name == "attack":
                self.has_dealt_sword_hit = False

    def attack(self):
        if self.m1_cooldown <= 0 and not self.is_attacking and not self.is_dead:
            self.is_attacking = True
            self.is_defending = False
            self.m1_cooldown = 0.38
            self.has_dealt_sword_hit = False
            self.set_animation("attack")
            if sfx_attack:
                random.choice(sfx_attack).play()

    def cast_special(self, projectiles):
        if self.skill_cooldown <= 0 and not self.is_attacking and not self.is_dead:
            self.is_special = True
            self.is_defending = False
            self.skill_cooldown = 4.0
            self.set_animation("special")
            direction = 1 if self.facing_right else -1
            spawn_x = self.rect.right if self.facing_right else self.rect.left - 40
            projectiles.append(Projectile(spawn_x, self.rect.centery - 10, direction))
            if sfx_attack:
                random.choice(sfx_attack).play()

    def update(self, dt, platforms, projectiles, enemies=None, floating_texts=None, touch_ctrl=None):
        if self.hp <= 0 and not self.is_dead:
            self.is_dead = True
            self.set_animation("death")
            self.frame_index = 0

        if self.is_dead:
            self.anim_timer += dt
            if self.anim_timer >= 0.09:
                self.anim_timer = 0.0
                self.frame_index = min(len(self.animations["death"]) - 1, self.frame_index + 1)
            self.image = self.animations["death"][self.frame_index]
            if not self.facing_right:
                self.image = pygame.transform.flip(self.image, True, False)
            # Fall to ground
            self.y_velocity += GRAVITY
            self.rect.y += int(self.y_velocity)
            for plat in platforms:
                if self.rect.colliderect(plat) and self.y_velocity > 0:
                    self.rect.bottom = plat.top
                    self.y_velocity = 0
            return

        # Update cooldowns
        if self.m1_cooldown > 0:
            self.m1_cooldown = max(0.0, self.m1_cooldown - dt)
        if self.skill_cooldown > 0:
            self.skill_cooldown = max(0.0, self.skill_cooldown - dt)
        if self.showdown_cooldown > 0:
            self.showdown_cooldown = max(0.0, self.showdown_cooldown - dt)

        keys = pygame.key.get_pressed()
        touch_shield = bool(touch_ctrl and touch_ctrl.is_button_pressed("shield"))
        touch_jump = bool(touch_ctrl and touch_ctrl.is_button_pressed("jump"))
        joy_x, joy_y = touch_ctrl.get_movement_vector() if touch_ctrl else (0.0, 0.0)

        is_shift = (keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]) or touch_shield
        
        # Only defend if NOT currently attacking or casting special
        if not (self.is_attacking or self.is_special):
            self.is_defending = is_shift and self.shield_capacity > 0
        else:
            self.is_defending = False

        # Defend regeneration or consumption
        if self.is_defending:
            self.shield_capacity = max(0.0, self.shield_capacity - dt * 25.0)
            if self.shield_capacity <= 0:
                self.is_defending = False
        else:
            self.shield_capacity = min(self.max_shield, self.shield_capacity + dt * 15.0)

        action_playing = self.is_attacking or self.is_special

        # Movement Input
        dx = 0
        is_down = (keys[pygame.K_s] or keys[pygame.K_DOWN]) or (joy_y > 0.45)
        is_jump = (keys[pygame.K_w] or keys[pygame.K_SPACE] or keys[pygame.K_UP]) or touch_jump

        if not self.is_defending and not action_playing:
            if keys[pygame.K_a] or keys[pygame.K_LEFT] or (joy_x < -0.2):
                dx -= MOVE_SPEED
                self.facing_right = False
            if keys[pygame.K_d] or keys[pygame.K_RIGHT] or (joy_x > 0.2):
                dx += MOVE_SPEED
                self.facing_right = True

            # Drop Down through elevated one-way platform:
            if is_down and is_jump and self.is_grounded and self.rect.bottom < WINDOW_HEIGHT - 60:
                self.rect.y += 12
                self.is_grounded = False
                self.y_velocity = 2.0
            # Standard Jump:
            elif is_jump and self.is_grounded:
                self.y_velocity = JUMP_STRENGTH
                self.is_grounded = False
                if sfx_jump:
                    sfx_jump.play()

            # Set animation & speed
            if dx != 0:
                self.set_animation("walk")
                self.anim_speed = 0.075
                self.step_timer += dt
                if self.step_timer >= 0.32:
                    self.step_timer = 0.0
                    if sfx_walk:
                        footstep_channel.play(random.choice(sfx_walk))
            else:
                self.set_animation("idle")
                self.anim_speed = 0.11
        elif self.is_defending:
            self.set_animation("defend")
            self.anim_speed = 0.1

        # Horizontal movement (clamp within screen bounds)
        self.rect.x += dx
        self.rect.x = max(0, min(2400 - self.rect.width, self.rect.x))

        # Vertical physics & gravity
        prev_bottom = self.rect.bottom
        self.y_velocity += GRAVITY
        self.rect.y += int(self.y_velocity)
        self.is_grounded = False

        # Platform Collisions (Solid Ground vs One-Way Jump-Through Platforms)
        for idx, plat in enumerate(platforms):
            if idx == 0:
                # Main solid ground floor
                if self.rect.colliderect(plat):
                    if self.y_velocity > 0:
                        self.rect.bottom = plat.top
                        self.y_velocity = 0
                        self.is_grounded = True
                    elif self.y_velocity < 0:
                        self.rect.top = plat.bottom
                        self.y_velocity = 0
            else:
                # Elevated Jump-Through Platforms (smooth landing on top, pass through from below)
                if self.rect.colliderect(plat):
                    if self.y_velocity >= 0 and prev_bottom <= plat.top + 14:
                        self.rect.bottom = plat.top
                        self.y_velocity = 0
                        self.is_grounded = True

        # Synchronized sword attack hit frame detection
        if self.is_attacking and enemies is not None and floating_texts is not None:
            if 2 <= self.frame_index <= 5 and not self.has_dealt_sword_hit:
                hit_rect = self.rect.inflate(50, 0)
                if self.facing_right:
                    hit_rect.x += 30
                else:
                    hit_rect.x -= 30
                for en in enemies:
                    if hit_rect.colliderect(en.rect) and en.hp > 0:
                        self.has_dealt_sword_hit = True
                        dmg = random.randint(5, 16) if getattr(en, 'is_armored', False) else random.randint(2, 12)
                        kb_dir = 1.0 if self.facing_right else -1.0
                        en.take_damage(dmg, floating_texts, kb_dir)
                        if sfx_hit:
                            random.choice(sfx_hit).play()

        # Animation tick
        self.anim_timer += dt
        current_speed = 0.055 if self.current_anim == "attack" else (0.06 if self.current_anim == "special" else self.anim_speed)
        if self.anim_timer >= current_speed:
            self.anim_timer = 0.0
            self.frame_index += 1
            if self.frame_index >= len(self.animations[self.current_anim]):
                if self.current_anim in ["attack", "special"]:
                    self.is_attacking = False
                    self.is_special = False
                    self.has_dealt_sword_hit = False
                    self.set_animation("idle")
                else:
                    self.frame_index = 0

        self.image = self.animations[self.current_anim][min(self.frame_index, len(self.animations[self.current_anim]) - 1)]
        if not self.facing_right:
            self.image = pygame.transform.flip(self.image, True, False)

    def draw(self, surface, camera):
        img_rect = self.image.get_rect(midbottom=self.rect.midbottom)
        surface.blit(self.image, camera.apply_rect(img_rect))

def load_golem_anim(prefix, scale=2.0):
    possible_folders = [
        os.path.join(BASE_DIR, "Enemy", "Golem"),
        os.path.join(BASE_DIR, "Enemy_Galore_I", "Golem", "No Armor"),
        os.path.join(BASE_DIR, "Enemy_Galore_I", "Golem", "Armored"),
    ]
    if getattr(sys, 'frozen', False):
        meipass = getattr(sys, '_MEIPASS', BASE_DIR)
        possible_folders.insert(0, os.path.join(meipass, "Enemy", "Golem"))
        possible_folders.insert(1, os.path.join(meipass, "Enemy_Galore_I", "Golem", "No Armor"))
        possible_folders.insert(2, os.path.join(meipass, "Enemy_Galore_I", "Golem", "Armored"))

    frames = []
    for folder in possible_folders:
        if os.path.exists(folder):
            files = [f for f in os.listdir(folder) if f.startswith(prefix + "_") and f.endswith(".png")]
            if files:
                def sort_key(name):
                    try:
                        num = int(name.replace(prefix + "_", "").replace(".png", ""))
                        return (0, num)
                    except ValueError:
                        return (1, name)
                files.sort(key=sort_key)
                for f in files:
                    p = os.path.join(folder, f)
                    try:
                        img = pygame.image.load(p).convert_alpha()
                        w, h = img.get_size()
                        frames.append(pygame.transform.scale(img, (int(w * scale), int(h * scale))))
                    except Exception:
                        pass
                if frames:
                    break
    if not frames:
        frames = load_animation("8", "idle", scale)
    return frames

class GolemEnemy:
    def __init__(self, x, y, stage=0):
        self.stage = stage
        self.is_armored = False
        self.is_upgrading = False
        self.has_hit_this_attack = False
        
        # Load unarmored and armored animations from Enemy/Golem with scale 2.0
        self.anims_unarmored = {
            "idle": load_golem_anim("Golem_IdleA", 2.0),
            "walk": load_golem_anim("Golem_Run", 2.0),
            "attack": load_golem_anim("Golem_AttackA", 2.0),
            "hurt": load_golem_anim("Golem_HitA", 2.0),
            "death": load_golem_anim("Golem_DeathA", 2.0),
            "upgrade": load_golem_anim("Golem_Upgrade", 2.0)
        }
        self.anims_armored = {
            "idle": load_golem_anim("Golem_Armor_Idle", 2.0),
            "walk": load_golem_anim("Golem_Armor_Run", 2.0),
            "attack": load_golem_anim("Golem_Armor_AttackA", 2.0),
            "hurt": load_golem_anim("Golem_Armor_Hit", 2.0),
            "death": load_golem_anim("Golem_Armor_ArmorBreak", 2.0),
            "upgrade": load_golem_anim("Golem_Upgrade", 2.0)
        }
        self.animations = self.anims_unarmored
        self.current_anim = "idle"
        self.frame_index = 0
        self.anim_timer = 0.0
        self.anim_speed = 0.07
        self.image = self.animations[self.current_anim][0]

        # Grounded rectangle matching player scale (WINDOW_HEIGHT - 60)
        self.rect = pygame.Rect(x, 0, 68, 88)
        self.rect.bottom = WINDOW_HEIGHT - 60
        self.max_hp = 60
        self.hp = 60
        self.is_dead = False
        self.facing_right = False
        self.stun_timer = 0.0
        self.attack_cooldown = 0.5 + random.uniform(0.0, 0.4)
        self.knockback_x = 0.0

    def trigger_upgrade(self, floating_texts):
        if not self.is_armored and not self.is_upgrading and not self.is_dead:
            self.is_upgrading = True
            self.set_animation("upgrade")
            floating_texts.append(FloatingText(self.rect.centerx, self.rect.top - 25, "* GOLEM UPGRADE! *", (255, 215, 0)))

    def set_animation(self, name):
        if self.current_anim != name and name in self.animations:
            self.current_anim = name
            self.frame_index = 0
            self.anim_timer = 0.0
            if name == "attack":
                self.has_hit_this_attack = False

    def take_damage(self, amount, floating_texts, kb_dir=0.0):
        if self.is_dead: return
        self.hp -= amount
        color = (200, 200, 255) if self.is_armored else (255, 80, 80)
        floating_texts.append(FloatingText(self.rect.centerx, self.rect.top - 15, f"-{amount}", color))
        
        # Apply physical knockback velocity
        if kb_dir != 0.0:
            self.knockback_x = kb_dir * (260.0 if not self.is_armored else 160.0)

        if sfx_hit:
            random.choice(sfx_hit).play()
        if self.hp <= 0:
            self.hp = 0
            self.is_dead = True
            self.set_animation("death")
        elif not self.is_upgrading:
            self.set_animation("hurt")

    def freeze(self, duration, floating_texts):
        self.stun_timer = duration
        self.knockback_x = 0.0
        floating_texts.append(FloatingText(self.rect.centerx, self.rect.top - 30, "* FROZEN! *", (100, 200, 255)))

    def update(self, dt, player, floating_texts):
        self.rect.bottom = WINDOW_HEIGHT - 60 # Snap feet firmly to floor

        # Apply Knockback Deceleration
        if abs(self.knockback_x) > 5.0:
            self.rect.x += int(self.knockback_x * dt)
            self.knockback_x *= (1.0 - min(1.0, dt * 12.0))
        else:
            self.knockback_x = 0.0

        if self.is_dead:
            if self.current_anim == "death" and self.frame_index >= len(self.animations["death"]) - 1:
                return
        elif self.is_upgrading:
            pass
        elif self.stun_timer > 0:
            self.stun_timer -= dt
            self.set_animation("idle")
        else:
            # AI: Move toward player
            dist = player.rect.centerx - self.rect.centerx
            self.facing_right = dist > 0
            abs_dist = abs(dist)
            abs_y_dist = abs(player.rect.bottom - self.rect.bottom)

            # Only attack if player is in melee reach and on the same vertical level
            if abs_dist < 110 and abs_y_dist < 50:
                self.attack_cooldown -= dt
                if self.attack_cooldown <= 0 and self.current_anim != "attack":
                    self.set_animation("attack")
            elif abs_dist < 550 and self.current_anim != "attack":
                self.set_animation("walk")
                step = 2.8 if self.facing_right else -2.8
                self.rect.x += int(step)
            elif self.current_anim != "attack":
                self.set_animation("idle")

            # Deliver hit damage during active punch frames (frames 4 to 11)
            # Only connects if player is within horizontal and vertical range
            if self.current_anim == "attack" and 4 <= self.frame_index <= 11:
                if abs_dist < 120 and abs_y_dist < 50 and not self.has_hit_this_attack:
                    self.has_hit_this_attack = True
                    dmg = 10 if self.is_armored else random.randint(2, 6)
                    
                    keys = pygame.key.get_pressed()
                    is_shift = keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]
                    is_blocking = player.is_defending or (is_shift and player.shield_capacity > 0)

                    if not is_blocking:
                        player.hp = max(0, player.hp - dmg)
                        floating_texts.append(FloatingText(player.rect.centerx, player.rect.top - 10, f"-{dmg}", (255, 60, 60)))
                    else:
                        player.shield_capacity = max(0.0, player.shield_capacity - dmg * 1.5)
                        floating_texts.append(FloatingText(player.rect.centerx, player.rect.top - 10, "BLOCKED!", (100, 180, 255)))

        # Animation frame update
        self.anim_timer += dt
        if self.anim_timer >= self.anim_speed:
            self.anim_timer = 0.0
            self.frame_index += 1
            if self.frame_index >= len(self.animations[self.current_anim]):
                if self.is_upgrading:
                    self.is_upgrading = False
                    self.is_armored = True
                    self.animations = self.anims_armored
                    self.max_hp = 90
                    self.hp = 90
                    self.set_animation("idle")
                elif self.current_anim in ["attack", "hurt"]:
                    self.attack_cooldown = 0.8 + random.uniform(0.0, 0.4)
                    self.set_animation("idle")
                elif self.current_anim == "death":
                    self.frame_index = len(self.animations["death"]) - 1
                else:
                    self.frame_index = 0

        self.image = self.animations[self.current_anim][min(self.frame_index, len(self.animations[self.current_anim]) - 1)]
        if not self.facing_right:
            self.image = pygame.transform.flip(self.image, True, False)

    def draw(self, surface, camera):
        img_rect = self.image.get_rect(midbottom=self.rect.midbottom)
        surface.blit(self.image, camera.apply_rect(img_rect))

        # Health bar
        if self.hp > 0:
            bar_w = 60
            bar_h = 6
            bar_x = self.rect.centerx - bar_w // 2
            bar_y = self.rect.top - 18
            bar_rect = camera.apply_rect(pygame.Rect(bar_x, bar_y, bar_w, bar_h))
            pygame.draw.rect(surface, (40, 20, 20), bar_rect)
            fill_w = max(0, int(bar_w * (self.hp / self.max_hp)))
            fill_rect = pygame.Rect(bar_rect.x, bar_rect.y, fill_w, bar_h)
            bar_color = (120, 180, 255) if self.is_armored else (240, 60, 60)
            pygame.draw.rect(surface, bar_color, fill_rect)
            pygame.draw.rect(surface, (0, 0, 0), bar_rect, 1)

            if self.stun_timer > 0:
                # Ice crystal effect
                crystal_rect = bar_rect.inflate(12, 10)
                pygame.draw.rect(surface, (100, 220, 255), crystal_rect, 2)

# --- ORC ENEMY (Nimble axe-wielding vanguard) ---
def load_orc_anim(action_name, scale=1.75):
    sheet_map = {
        "idle": "Orc_Idle.png",
        "walk": "Orc_Walk.png",
        "attack": "Orc_Attack01.png",
        "attack2": "Orc_Attack02.png",
        "hurt": "Orc_Hurt.png",
        "death": "Orc_Death.png"
    }
    
    # 1. Try loading clean sprites from Orc/Orc/ without top-down shadows
    sheet_folder = os.path.join(BASE_DIR, "3D_Assets", "RPG DUNGEON", "Characters(100x100 split)", "Orc", "Orc")
    if getattr(sys, 'frozen', False):
        meipass = getattr(sys, '_MEIPASS', BASE_DIR)
        sheet_folder_meipass = os.path.join(meipass, "3D_Assets", "RPG DUNGEON", "Characters(100x100 split)", "Orc", "Orc")
        if os.path.exists(sheet_folder_meipass):
            sheet_folder = sheet_folder_meipass

    sheet_fname = sheet_map.get(action_name, f"Orc_{action_name.capitalize()}.png")
    sheet_path = os.path.join(sheet_folder, sheet_fname)
    
    frames = []
    if os.path.exists(sheet_path):
        try:
            sheet_img = pygame.image.load(sheet_path).convert_alpha()
            sw, sh = sheet_img.get_size()
            num_frames = max(1, sw // 100)
            for i in range(num_frames):
                raw_frame = sheet_img.subsurface((i * 100, 0, 100, 100))
                # Crop around character body with feet right at the bottom edge (y=24 to 58, width 48)
                crop_box = pygame.Rect(26, 24, 48, 34)
                cropped = raw_frame.subsurface(crop_box)
                scaled_w = int(crop_box.width * scale)
                scaled_h = int(crop_box.height * scale)
                frames.append(pygame.transform.scale(cropped, (scaled_w, scaled_h)))
        except Exception:
            pass

    # 2. Fallback to split folder if sheet not found
    if not frames:
        split_map = {
            "idle": "idle",
            "walk": "walk",
            "attack": "slash_1",
            "attack2": "slash_2",
            "hurt": "damage",
            "death": "death"
        }
        sub_folder = split_map.get(action_name, action_name)
        folder = os.path.join(BASE_DIR, "3D_Assets", "RPG DUNGEON", "Characters(100x100 split)", "Orc", "Orc with shadows", sub_folder)
        if os.path.exists(folder):
            files = [f for f in os.listdir(folder) if f.endswith(".png")]
            files.sort(key=lambda x: int(os.path.splitext(x)[0]) if os.path.splitext(x)[0].isdigit() else x)
            for f in files:
                try:
                    img = pygame.image.load(os.path.join(folder, f)).convert_alpha()
                    iw, ih = img.get_size()
                    # Trim shadow pixels at the bottom
                    if ih > 4:
                        img = img.subsurface((0, 0, iw, ih - 3))
                        iw, ih = img.get_size()
                    frames.append(pygame.transform.scale(img, (int(iw * scale * 2.2), int(ih * scale * 2.2))))
                except Exception:
                    pass

    if not frames:
        s = pygame.Surface((int(32 * scale), int(34 * scale)), pygame.SRCALPHA)
        pygame.draw.rect(s, (120, 160, 80), (4, 4, int(24 * scale), int(26 * scale)))
        frames = [s]

    return frames

class OrcEnemy:
    def __init__(self, x, y):
        self.anims = {
            "idle": load_orc_anim("idle", 1.75),
            "walk": load_orc_anim("walk", 1.75),
            "attack": load_orc_anim("attack", 1.75),
            "attack2": load_orc_anim("attack2", 1.75),
            "hurt": load_orc_anim("hurt", 1.75),
            "death": load_orc_anim("death", 1.75),
        }
        self.current_anim = "idle"
        self.frame_index = 0
        self.anim_timer = 0.0
        self.anim_speed = 0.08
        self.image = self.anims[self.current_anim][0]

        # Grounded hitbox with feet firmly touching floor
        self.rect = pygame.Rect(x, 0, 44, 56)
        self.rect.bottom = WINDOW_HEIGHT - 60
        self.max_hp = 45
        self.hp = 45
        self.is_dead = False
        self.facing_right = False
        self.stun_timer = 0.0
        self.attack_cooldown = random.uniform(0.3, 0.7)
        self.knockback_x = 0.0
        self.has_hit_this_attack = False

    def set_animation(self, name):
        if self.current_anim != name and name in self.anims:
            self.current_anim = name
            self.frame_index = 0
            self.anim_timer = 0.0
            if "attack" in name:
                self.has_hit_this_attack = False

    def take_damage(self, amount, floating_texts, kb_dir=0.0):
        if self.is_dead: return
        self.hp -= amount
        floating_texts.append(FloatingText(self.rect.centerx, self.rect.top - 12, f"-{amount}", (255, 120, 80)))
        if kb_dir != 0.0:
            self.knockback_x = kb_dir * 260.0
        if sfx_hit:
            random.choice(sfx_hit).play()
        if self.hp <= 0:
            self.hp = 0
            self.is_dead = True
            self.set_animation("death")
        else:
            self.set_animation("hurt")

    def freeze(self, duration, floating_texts):
        self.stun_timer = duration
        self.knockback_x = 0.0
        floating_texts.append(FloatingText(self.rect.centerx, self.rect.top - 25, "* FROZEN! *", (100, 200, 255)))

    def update(self, dt, player, floating_texts):
        self.rect.bottom = WINDOW_HEIGHT - 60

        if abs(self.knockback_x) > 5.0:
            self.rect.x += int(self.knockback_x * dt)
            self.knockback_x *= (1.0 - min(1.0, dt * 14.0))
        else:
            self.knockback_x = 0.0

        if self.is_dead:
            if self.current_anim == "death" and self.frame_index >= len(self.anims["death"]) - 1:
                return
        elif self.stun_timer > 0:
            self.stun_timer -= dt
            self.set_animation("idle")
        else:
            dist = player.rect.centerx - self.rect.centerx
            self.facing_right = dist > 0
            abs_dist = abs(dist)
            abs_y_dist = abs(player.rect.bottom - self.rect.bottom)

            # Orc is nimble & aggressive: moves fast and strikes quickly!
            if abs_dist < 85 and abs_y_dist < 50:
                self.attack_cooldown -= dt
                if self.attack_cooldown <= 0 and "attack" not in self.current_anim:
                    self.set_animation(random.choice(["attack", "attack2"]))
            elif abs_dist < 600 and "attack" not in self.current_anim:
                self.set_animation("walk")
                step = 3.6 if self.facing_right else -3.6
                self.rect.x += int(step)
            elif "attack" not in self.current_anim:
                self.set_animation("idle")

            # Active attack slash frames (frames 2 to 4)
            if "attack" in self.current_anim and 2 <= self.frame_index <= 4:
                if abs_dist < 95 and abs_y_dist < 50 and not self.has_hit_this_attack:
                    self.has_hit_this_attack = True
                    dmg = random.randint(4, 9)
                    keys = pygame.key.get_pressed()
                    is_shift = keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]
                    is_blocking = player.is_defending or (is_shift and player.shield_capacity > 0)

                    if not is_blocking:
                        player.hp = max(0, player.hp - dmg)
                        floating_texts.append(FloatingText(player.rect.centerx, player.rect.top - 10, f"-{dmg}", (255, 60, 60)))
                    else:
                        player.shield_capacity = max(0.0, player.shield_capacity - dmg * 1.2)
                        floating_texts.append(FloatingText(player.rect.centerx, player.rect.top - 10, "BLOCKED!", (100, 180, 255)))

        # Animation frame update
        self.anim_timer += dt
        if self.anim_timer >= self.anim_speed:
            self.anim_timer = 0.0
            self.frame_index += 1
            if self.frame_index >= len(self.anims[self.current_anim]):
                if "attack" in self.current_anim or self.current_anim == "hurt":
                    self.attack_cooldown = random.uniform(0.4, 0.9)
                    self.set_animation("idle")
                elif self.current_anim == "death":
                    self.frame_index = len(self.anims["death"]) - 1
                else:
                    self.frame_index = 0

        self.image = self.anims[self.current_anim][min(self.frame_index, len(self.anims[self.current_anim]) - 1)]

    def draw(self, surface, camera):
        draw_r = camera.apply_rect(self.rect)
        img = self.image
        if not self.facing_right:
            img = pygame.transform.flip(img, True, False)
        
        # Center sprite with grounded feet firmly on the floor
        img_r = img.get_rect(midbottom=draw_r.midbottom)
        surface.blit(img, img_r)

        # Health bar
        if not self.is_dead:
            bar_w = 42
            bar_h = 5
            bar_x = draw_r.centerx - bar_w // 2
            bar_y = draw_r.top - 10
            bar_rect = pygame.Rect(bar_x, bar_y, bar_w, bar_h)

            pygame.draw.rect(surface, (20, 15, 10), bar_rect.inflate(2, 2), border_radius=2)
            fill_w = max(0, int(bar_w * (self.hp / self.max_hp)))
            pygame.draw.rect(surface, (180, 40, 40), (bar_x, bar_y, fill_w, bar_h), border_radius=2)
            pygame.draw.rect(surface, (230, 180, 60), bar_rect.inflate(2, 2), 1, border_radius=2)

            if self.stun_timer > 0:
                crystal_rect = bar_rect.inflate(8, 6)
                pygame.draw.rect(surface, (100, 220, 255), crystal_rect, 2)

# --- MAIN CONTROLLER & SCENE MANAGER ---
async def main():
    global real_screen, show_inventory, show_codex
    clock = pygame.time.Clock()
    running = True
    game_state = "MAIN_MENU"
    show_inventory = False
    show_codex = False

    # Settings Variables
    saved_cfg = load_settings()
    current_language = saved_cfg.get("lang", "IDN")
    settings_master_vol = saved_cfg.get("master_vol", 100)
    settings_music_vol = saved_cfg.get("music_vol", 80)
    settings_sfx_vol = saved_cfg.get("sfx_vol", 100)
    settings_fullscreen = False

    # Tutorial State
    is_tutorial_mode = False
    first_time_tutorial = True
    tutorial_prompt_text = ""
    tutorial_prompt_timer = 0.0

    # In-Game State
    player = Player(100, 300)
    enemies = []
    projectiles = []
    floating_texts = []
    platforms = [
        pygame.Rect(0, WINDOW_HEIGHT - 60, 2400, 60),
        pygame.Rect(350, WINDOW_HEIGHT - 180, 220, 30),
        pygame.Rect(700, WINDOW_HEIGHT - 260, 220, 30),
        pygame.Rect(1100, WINDOW_HEIGHT - 180, 240, 30),
    ]
    camera = Camera(2400, WINDOW_HEIGHT)

    # Tutorial Stages: 0=M1 Strike, 1=E Glacial Strike, 2=Finish Frozen Golem
    tutorial_stage = 0
    tutorial_time_scale = 1.0
    tutorial_slowmo = False
    tutorial_delay_timer = 0.0
    tutorial_prompt = ""
    tutorial_subprompt = ""
    victory_cooldown = 0.0

    # ESC Confirmation Prompt
    esc_prompt_timer = 0.0
    esc_prompt_alpha = 0.0

    # Mobile & Tablet Multi-Touch Controller (Disabled by default on PC; auto-enabled on touchscreens/mobile)
    touch_ctrl = VirtualTouchController(WINDOW_WIDTH, WINDOW_HEIGHT, enabled=False)

    # RPG & Sandbox submodules
    rpg_game = None
    sandbox_game = None
    word_typist_game = None

    # Loading Scene State
    loading_target = "RPG_MODE"
    loading_progress = 0.0
    loading_stage = 0
    loading_timer = 0.0
    loading_stage_timer = 0.0

    # Multilingual Fonts
    font_chain = "malgungothic,notosanscjk,nanumgothic,applesdgothicneo,segoeui,arial,couriernew"
    menu_font = pygame.font.SysFont(font_chain, 20, bold=True)
    hud_font = pygame.font.SysFont(font_chain, 15, bold=True)
    prompt_font = pygame.font.SysFont(font_chain, 17, bold=True)
    credits_title_font = pygame.font.SysFont(font_chain, 19, bold=True)
    credits_hdr_font = pygame.font.SysFont(font_chain, 15, bold=True)
    credits_val_font = pygame.font.SysFont(font_chain, 15, bold=True)

    while running:
        await asyncio.sleep(0)
        dt = clock.tick(FPS) / 1000.0
        events = pygame.event.get()
        for ev in events:
            if ev.type == pygame.VIDEORESIZE:
                real_screen = pygame.display.set_mode((ev.w, ev.h), pygame.RESIZABLE)
                if touch_ctrl:
                    touch_ctrl.rebuild_layout(ev.w, ev.h)
                if rpg_game and hasattr(rpg_game, 'resize'):
                    rpg_game.resize(ev.w, ev.h)
                if sandbox_game:
                    sandbox_game.width, sandbox_game.height = ev.w, ev.h
                    if hasattr(sandbox_game, 'panel_rect'):
                        sandbox_game.panel_rect.x = ev.w - sandbox_game.panel_w
                        sandbox_game.panel_rect.height = ev.h
                if word_typist_game and hasattr(word_typist_game, 'resize'):
                    word_typist_game.resize(ev.w, ev.h)
        mx, my = get_mouse_pos()

        # =========================================================================
        # 1. MAIN MENU
        # =========================================================================
        if game_state == "MAIN_MENU":
            for layer in bg_layers:
                screen.blit(layer, (0, 0))

            # Title: The Awaiting Stars
            title_text = "The Awaiting Stars"
            base_title = menu_font.render(title_text, False, (255, 175, 50))
            shadow_title = menu_font.render(title_text, False, (0, 0, 0))
            scale_fac = 2
            title_txt = pygame.transform.scale(base_title, (base_title.get_width() * scale_fac, base_title.get_height() * scale_fac))
            shadow_txt = pygame.transform.scale(shadow_title, (shadow_title.get_width() * scale_fac, shadow_title.get_height() * scale_fac))
            title_rect = title_txt.get_rect(center=(WINDOW_WIDTH // 2, 110))

            for dx, dy in [(-3,0), (3,0), (0,-3), (0,3), (-3,-3), (3,-3), (-3,3), (3,3)]:
                screen.blit(shadow_txt, shadow_txt.get_rect(center=(title_rect.centerx + dx, title_rect.centery + dy)))
            screen.blit(title_txt, title_rect)

            # Draw 16-Bit Medieval Wood Button Helper
            def draw_wood_btn(y_pos, text):
                box_rect = pygame.Rect(0, 0, 240, 46)
                box_rect.center = (WINDOW_WIDTH // 2, y_pos)
                is_hover = box_rect.collidepoint(mx, my)
                
                bg_col = (140, 80, 35) if is_hover else (100, 50, 20)
                pygame.draw.rect(screen, (0, 0, 0), box_rect.inflate(4, 4), border_radius=6)
                pygame.draw.rect(screen, bg_col, box_rect, border_radius=6)
                pygame.draw.rect(screen, (255, 200, 100), box_rect, 2, border_radius=6)

                t = menu_font.render(text, False, (255, 230, 150) if is_hover else (255, 255, 255))
                screen.blit(t, t.get_rect(center=box_rect.center))
                return box_rect

            btn_play = draw_wood_btn(185, t("menu_play_rpg", current_language))
            btn_tutorial = draw_wood_btn(240, t("menu_word_typist", current_language))
            btn_sandbox = draw_wood_btn(295, t("menu_sandbox", current_language))
            btn_settings = draw_wood_btn(350, t("menu_settings", current_language))
            btn_credits = draw_wood_btn(405, t("menu_credits", current_language))
            btn_quit = draw_wood_btn(460, t("menu_quit", current_language))

            # Warning / Alert Prompt Banner
            if tutorial_prompt_timer > 0:
                tutorial_prompt_timer -= dt
                p_surf = prompt_font.render(tutorial_prompt_text, False, (255, 220, 60))
                p_rect = p_surf.get_rect(center=(WINDOW_WIDTH // 2, 520))
                bg_p = p_rect.inflate(24, 14)
                pygame.draw.rect(screen, (20, 10, 30), bg_p, border_radius=6)
                pygame.draw.rect(screen, (255, 180, 40), bg_p, 2, border_radius=6)
                screen.blit(p_surf, p_rect)

            for event in events:
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if btn_play.collidepoint(mx, my):
                        loading_target = "RPG_MODE"
                        loading_progress = 0.0
                        loading_stage = 0
                        loading_timer = 0.0
                        loading_stage_timer = 0.0
                        game_state = "LOADING"
                    elif btn_tutorial.collidepoint(mx, my):
                        loading_target = "WORD_TYPIST"
                        loading_progress = 0.0
                        loading_stage = 0
                        loading_timer = 0.0
                        loading_stage_timer = 0.0
                        game_state = "LOADING"
                    elif btn_sandbox.collidepoint(mx, my):
                        loading_target = "SANDBOX_MODE"
                        loading_progress = 0.0
                        loading_stage = 0
                        loading_timer = 0.0
                        loading_stage_timer = 0.0
                        game_state = "LOADING"
                    elif btn_settings.collidepoint(mx, my):
                        game_state = "SETTINGS"
                    elif btn_credits.collidepoint(mx, my):
                        game_state = "CREDITS"
                    elif btn_quit.collidepoint(mx, my):
                        running = False

            flip_display()
            continue

        # =========================================================================
        # 1.5 ANIMATED LOADING SCREEN (Smooth Preload Transition to RPG & Other Modes)
        # =========================================================================
        elif game_state == "LOADING":
            loading_timer += dt
            loading_stage_timer += dt

            for event in events:
                if event.type == pygame.QUIT:
                    running = False

            # Atmospheric dark cosmic background
            screen.fill((10, 12, 22))

            ticks = pygame.time.get_ticks()
            pulse = (math.sin(ticks * 0.005) + 1.0) * 0.5
            rot_angle = (ticks * 0.08) % 360

            # Subtle twinkling stars background
            for sx, sy in [(120, 80), (320, 60), (740, 90), (860, 140), (180, 520), (780, 540), (880, 480), (100, 360)]:
                twinkle = int(140 + 115 * math.sin(ticks * 0.004 + sx))
                pygame.draw.circle(screen, (twinkle, twinkle, min(255, twinkle + 40)), (sx, sy), 2)

            # Title
            t_title = menu_font.render(t("loading_title", current_language), False, (255, 215, 80))
            t_title_lg = pygame.transform.scale(t_title, (int(t_title.get_width() * 1.4), int(t_title.get_height() * 1.4)))
            screen.blit(t_title_lg, t_title_lg.get_rect(center=(WINDOW_WIDTH // 2, 120)))

            sub_title = hud_font.render(t("loading_sub", current_language), False, (140, 185, 230))
            screen.blit(sub_title, sub_title.get_rect(center=(WINDOW_WIDTH // 2, 165)))

            # Animated Celestial Compass / Orbit Spinner
            cx, cy = WINDOW_WIDTH // 2, 275
            spinner_radius = 46
            for i in range(12):
                angle_deg = rot_angle + (i * 30)
                rad = math.radians(angle_deg)
                dot_x = cx + math.cos(rad) * spinner_radius
                dot_y = cy + math.sin(rad) * spinner_radius
                alpha_factor = (i + 1) / 12.0
                dot_col = (
                    int(100 + 155 * alpha_factor),
                    int(170 + 85 * alpha_factor),
                    int(255 * alpha_factor)
                )
                dot_r = 3 if i < 6 else (4 if i < 10 else 6)
                pygame.draw.circle(screen, dot_col, (int(dot_x), int(dot_y)), dot_r)

            # Core pulsing star
            core_r = int(12 + pulse * 5)
            pygame.draw.circle(screen, (255, 215, 80), (cx, cy), core_r)
            pygame.draw.circle(screen, (255, 255, 230), (cx, cy), max(2, core_r - 4))

            # Progress Bar
            bar_w, bar_h = 460, 24
            bx = (WINDOW_WIDTH - bar_w) // 2
            by = 370
            bar_bg = pygame.Rect(bx, by, bar_w, bar_h)
            pygame.draw.rect(screen, (18, 22, 35), bar_bg, border_radius=12)
            pygame.draw.rect(screen, (60, 100, 160), bar_bg, 2, border_radius=12)

            # Smoothly interpolate progress
            target_prog = [0.25, 0.65, 0.92, 1.0][min(loading_stage, 3)]
            loading_progress += (target_prog - loading_progress) * min(1.0, dt * 5.0)

            fill_w = int((bar_w - 6) * loading_progress)
            if fill_w > 0:
                fill_rect = pygame.Rect(bx + 3, by + 3, fill_w, bar_h - 6)
                pygame.draw.rect(screen, (60, 150, 255), fill_rect, border_radius=9)
                gloss_rect = pygame.Rect(bx + 3, by + 3, fill_w, (bar_h - 6) // 2)
                pygame.draw.rect(screen, (140, 210, 255), gloss_rect, border_radius=7)

            # Percentage text inside / over bar
            pct_str = f"{int(loading_progress * 100)}%"
            pct_surf = prompt_font.render(pct_str, False, (230, 245, 255))
            screen.blit(pct_surf, pct_surf.get_rect(center=(WINDOW_WIDTH // 2, by + bar_h // 2)))

            # Real-time Status Text based on stage
            stage_messages = {
                "RPG_MODE": [
                    t("stage_rpg_0", current_language),
                    t("stage_rpg_1", current_language),
                    t("stage_rpg_2", current_language),
                    t("stage_rpg_3", current_language)
                ],
                "WORD_TYPIST": [
                    "Loading Lexical Vocabularies & Science Terminology...",
                    "Initializing Kinetic Typing Arena & Waves...",
                    "Calibrating Speed Multipliers...",
                    "Ready to Type!"
                ],
                "SANDBOX_MODE": [
                    "Initializing Civic Sandbox & Creative Tools...",
                    "Loading Tile Palettes & Architecture Assets...",
                    "Allocating Real-time Terrain Engine...",
                    "Sandbox Ready!"
                ]
            }
            msgs = stage_messages.get(loading_target, stage_messages["RPG_MODE"])
            cur_msg = msgs[min(loading_stage, len(msgs) - 1)]
            stat_surf = hud_font.render(cur_msg, False, (255, 230, 130))
            screen.blit(stat_surf, stat_surf.get_rect(center=(WINDOW_WIDTH // 2, 420)))

            # Educational Gameplay Tip Carousel
            tips = [
                t("tip_bag", current_language),
                t("tip_animals", current_language),
                t("tip_codex", current_language),
                t("tip_mining", current_language)
            ]
            tip_idx = int(loading_timer // 2.5) % len(tips)
            tip_surf = prompt_font.render(tips[tip_idx], False, (160, 180, 210))
            screen.blit(tip_surf, tip_surf.get_rect(center=(WINDOW_WIDTH // 2, 480)))

            flip_display()

            # State Progression with frame yield so WebAssembly/browser paints smoothly
            if loading_stage == 0 and loading_stage_timer > 0.4:
                loading_stage = 1
                loading_stage_timer = 0.0
                await asyncio.sleep(0.01)
            elif loading_stage == 1 and loading_stage_timer > 0.4:
                # Preload and instantiate game
                win_w, win_h = real_screen.get_size()
                if loading_target == "RPG_MODE":
                    from rpg_mode import RPGGame
                    rpg_game = RPGGame(win_w, win_h, BASE_DIR)
                    rpg_game.language = current_language
                elif loading_target == "WORD_TYPIST":
                    from word_typist import WordTypistGame
                    word_typist_game = WordTypistGame(win_w, win_h, BASE_DIR)
                elif loading_target == "SANDBOX_MODE":
                    from sandbox_mode import SandboxGame
                    sandbox_game = SandboxGame(win_w, win_h, BASE_DIR)
                loading_stage = 2
                loading_stage_timer = 0.0
                await asyncio.sleep(0.01)
            elif loading_stage == 2 and loading_stage_timer > 0.35:
                loading_stage = 3
                loading_stage_timer = 0.0
            elif loading_stage == 3 and loading_stage_timer > 0.3:
                game_state = loading_target
                loading_stage = 0
                loading_progress = 0.0

            continue

        # =========================================================================
        # 2. SETTINGS MENU
        # =========================================================================
        elif game_state == "SETTINGS":
            for layer in bg_layers:
                screen.blit(layer, (0, 0))

            overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 180))
            screen.blit(overlay, (0, 0))

            title = menu_font.render(t("settings_title", current_language), False, (255, 200, 60))
            screen.blit(title, title.get_rect(center=(WINDOW_WIDTH // 2, 38)))

            # Language Selection Header
            t_lang_lbl = hud_font.render(f"--- {t('settings_language', current_language)} ---", False, (255, 220, 140))
            screen.blit(t_lang_lbl, t_lang_lbl.get_rect(center=(WINDOW_WIDTH // 2, 70)))

            # 5 Language Selector Buttons: IDN / ENG / KOR / MXC / MYS
            lang_btns = {}
            start_x = (WINDOW_WIDTH - 412) // 2
            btn_y = 86
            for l_idx, l_code in enumerate(SUPPORTED_LANGUAGES):
                l_rect = pygame.Rect(start_x + l_idx * 84, btn_y, 76, 28)
                lang_btns[l_code] = l_rect
                is_sel = (l_code == current_language)
                is_hov = l_rect.collidepoint(mx, my)

                if is_sel:
                    bg_c = (220, 160, 40)
                    brd_c = (255, 235, 120)
                    txt_c = (20, 10, 5)
                elif is_hov:
                    bg_c = (70, 45, 95)
                    brd_c = (200, 140, 255)
                    txt_c = (255, 255, 255)
                else:
                    bg_c = (34, 22, 48)
                    brd_c = (110, 80, 140)
                    txt_c = (205, 195, 220)

                pygame.draw.rect(screen, bg_c, l_rect, border_radius=6)
                pygame.draw.rect(screen, brd_c, l_rect, 2, border_radius=6)

                lbl_str = f"{l_code}"
                lbl_btn = hud_font.render(lbl_str, False, txt_c)
                screen.blit(lbl_btn, lbl_btn.get_rect(center=l_rect.center))

            # Draw Sliders (Master, Music, SFX)
            def draw_slider(y_pos, label, val):
                lbl = hud_font.render(f"{label}: {val}%", False, (255, 230, 150))
                screen.blit(lbl, (WINDOW_WIDTH // 2 - 200, y_pos - 20))
                bar_rect = pygame.Rect(WINDOW_WIDTH // 2 - 200, y_pos, 400, 14)
                pygame.draw.rect(screen, (40, 20, 10), bar_rect, border_radius=4)
                fill_w = int(400 * (val / 100.0))
                pygame.draw.rect(screen, (220, 140, 40), (bar_rect.x, bar_rect.y, fill_w, 14), border_radius=4)
                pygame.draw.rect(screen, (255, 210, 100), bar_rect, 2, border_radius=4)
                return bar_rect

            slider_master = draw_slider(140, t("settings_master_vol", current_language), settings_master_vol)
            slider_music = draw_slider(180, t("settings_music_vol", current_language), settings_music_vol)
            slider_sfx = draw_slider(220, t("settings_sfx_vol", current_language), settings_sfx_vol)

            # Touch Controls Toggle Button
            btn_touch_toggle = pygame.Rect(WINDOW_WIDTH // 2 - 160, 256, 320, 28)
            is_touch_hover = btn_touch_toggle.collidepoint(mx, my)
            t_status_str = t("settings_touch_on", current_language) if touch_ctrl.enabled else t("settings_touch_off", current_language)
            t_col = (60, 200, 90) if touch_ctrl.enabled else (210, 60, 60)
            pygame.draw.rect(screen, (40, 35, 55) if is_touch_hover else (25, 20, 35), btn_touch_toggle, border_radius=5)
            pygame.draw.rect(screen, t_col, btn_touch_toggle, width=2, border_radius=5)
            t_lbl = hud_font.render(f"{t('settings_touch', current_language)}: {t_status_str}", False, (240, 240, 255))
            screen.blit(t_lbl, t_lbl.get_rect(center=btn_touch_toggle.center))

            # Controls Overview Card
            kb_rect = pygame.Rect(WINDOW_WIDTH // 2 - 340, 296, 680, 222)
            pygame.draw.rect(screen, (20, 15, 30), kb_rect, border_radius=8)
            pygame.draw.rect(screen, (220, 160, 50), kb_rect, 2, border_radius=8)
            kb_title = hud_font.render(t("settings_controls_title", current_language), False, (255, 210, 80))
            screen.blit(kb_title, kb_title.get_rect(center=(WINDOW_WIDTH // 2, 312)))

            controls = [
                (t("ctrl_move_k", current_language), t("ctrl_move_d", current_language)),
                (t("ctrl_atk_k", current_language), t("ctrl_atk_d", current_language)),
                (t("ctrl_skill_k", current_language), t("ctrl_skill_d", current_language)),
                (t("ctrl_bag_k", current_language), t("ctrl_bag_d", current_language)),
                (t("ctrl_guard_k", current_language), t("ctrl_guard_d", current_language)),
                (t("ctrl_menu_k", current_language), t("ctrl_menu_d", current_language)),
            ]
            for idx, (k, d) in enumerate(controls):
                ky = 334 + idx * 24
                t_k = hud_font.render(k, False, (255, 220, 120))
                t_d = hud_font.render(f"- {d}", False, (220, 220, 220))
                screen.blit(t_k, (kb_rect.left + 20, ky))
                screen.blit(t_d, (kb_rect.left + 265, ky))

            # Back Button
            btn_back = pygame.Rect(WINDOW_WIDTH // 2 - 100, 532, 200, 42)
            is_b_hover = btn_back.collidepoint(mx, my)
            pygame.draw.rect(screen, (130, 70, 30) if is_b_hover else (90, 40, 15), btn_back, border_radius=6)
            pygame.draw.rect(screen, (255, 200, 80), btn_back, 2, border_radius=6)
            txt_b = menu_font.render(t("btn_back", current_language), False, (255, 255, 255))
            screen.blit(txt_b, txt_b.get_rect(center=btn_back.center))

            for event in events:
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    for l_code, l_rect in lang_btns.items():
                        if l_rect.collidepoint(mx, my):
                            current_language = l_code
                            save_settings({
                                "lang": current_language,
                                "master_vol": settings_master_vol,
                                "music_vol": settings_music_vol,
                                "sfx_vol": settings_sfx_vol
                            })
                            if rpg_game and hasattr(rpg_game, 'language'):
                                rpg_game.language = current_language
                    if slider_master.collidepoint(mx, my):
                        settings_master_vol = max(0, min(100, int((mx - slider_master.x) / slider_master.width * 100)))
                    elif slider_music.collidepoint(mx, my):
                        settings_music_vol = max(0, min(100, int((mx - slider_music.x) / slider_music.width * 100)))
                    elif slider_sfx.collidepoint(mx, my):
                        settings_sfx_vol = max(0, min(100, int((mx - slider_sfx.x) / slider_sfx.width * 100)))
                    elif btn_touch_toggle.collidepoint(mx, my):
                        touch_ctrl.enabled = not touch_ctrl.enabled
                    elif btn_back.collidepoint(mx, my):
                        save_settings({
                            "lang": current_language,
                            "master_vol": settings_master_vol,
                            "music_vol": settings_music_vol,
                            "sfx_vol": settings_sfx_vol
                        })
                        game_state = "MAIN_MENU"
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    save_settings({
                        "lang": current_language,
                        "master_vol": settings_master_vol,
                        "music_vol": settings_music_vol,
                        "sfx_vol": settings_sfx_vol
                    })
                    game_state = "MAIN_MENU"

            flip_display()
            continue

        # =========================================================================
        # 2b. CREDITS MENU
        # =========================================================================
        elif game_state == "CREDITS":
            for layer in bg_layers:
                screen.blit(layer, (0, 0))

            overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 195))
            screen.blit(overlay, (0, 0))

            # Title
            title_text = t("menu_credits", current_language)
            base_title = menu_font.render(title_text, False, (255, 175, 50))
            shadow_title = menu_font.render(title_text, False, (0, 0, 0))
            scale_fac = 4
            title_w, title_h = int(base_title.get_width() * scale_fac), int(base_title.get_height() * scale_fac)
            title_txt = pygame.transform.scale(base_title, (title_w, title_h))
            shadow_txt = pygame.transform.scale(shadow_title, (title_w, title_h))
            title_rect = title_txt.get_rect(center=(WINDOW_WIDTH // 2, 50))

            for dx, dy in [(-3,0), (3,0), (0,-3), (0,3), (-3,-3), (3,-3), (-3,3), (3,3)]:
                screen.blit(shadow_txt, shadow_txt.get_rect(center=(title_rect.centerx + dx, title_rect.centery + dy)))
            screen.blit(title_txt, title_rect)

            # Credits Card Panel
            card_w = 720
            card_h = 440
            card_rect = pygame.Rect((WINDOW_WIDTH - card_w) // 2, 85, card_w, card_h)
            pygame.draw.rect(screen, (0, 0, 0), card_rect.inflate(6, 6), border_radius=10)
            pygame.draw.rect(screen, (24, 16, 12), card_rect, border_radius=10)
            pygame.draw.rect(screen, (180, 130, 50), card_rect, 2, border_radius=10)
            pygame.draw.rect(screen, (90, 55, 25), card_rect.inflate(-8, -8), 1, border_radius=8)

            # Credits Title & Divider
            t_y = card_rect.y + 26
            sh_t = credits_title_font.render("THE AWAITING STARS : TWO WORLDS, ONE DESTINY", True, (0, 0, 0))
            fg_t = credits_title_font.render("THE AWAITING STARS : TWO WORLDS, ONE DESTINY", True, (255, 215, 75))
            screen.blit(sh_t, (WINDOW_WIDTH // 2 - sh_t.get_width() // 2 + 1, t_y - sh_t.get_height() // 2 + 1))
            screen.blit(fg_t, (WINDOW_WIDTH // 2 - fg_t.get_width() // 2, t_y - fg_t.get_height() // 2))

            div_y = t_y + 18
            pygame.draw.line(screen, (170, 115, 45), (card_rect.x + 40, div_y), (card_rect.right - 40, div_y), 2)

            def draw_credits_text(font, text, color, center_x, center_y):
                sh = font.render(text, True, (0, 0, 0))
                fg = font.render(text, True, color)
                screen.blit(sh, (center_x - sh.get_width() // 2 + 1, center_y - sh.get_height() // 2 + 1))
                screen.blit(fg, (center_x - fg.get_width() // 2, center_y - fg.get_height() // 2))

            # Credits Sections distributed evenly across card height
            sections = [
                {
                    "left_hdr": "Team Supervisor", "left_val": "M. Saepudin, S. Pd (Musa)",
                    "right_hdr": "Team Leader", "right_val": "Daffa Irawan Harjianto"
                },
                {
                    "center_hdr": "Lead Game Developer", "center_val": "Raka Alfarizi"
                },
                {
                    "left_hdr": "Game Concept & Design", "left_val": "Daffa Irawan Harjianto",
                    "right_hdr": "Audio & Universal Music", "right_val": "El Niko Alman Fahrezi"
                },
                {
                    "left_hdr": "Journal & Research Poster", "left_val": "Raka Alfarizi & El Niko A. F.",
                    "right_hdr": "References & Academic Data", "right_val": "Abdul Fattah R. & M. Rizky R."
                },
                {
                    "left_hdr": "Core Engine & Architecture", "left_val": "Python (Pygame-CE)",
                    "right_hdr": "Development Environment", "right_val": "Visual Studio Code"
                }
            ]

            start_y = div_y + 28
            spacing_y = 66
            left_x = card_rect.left + card_w // 4 + 10
            right_x = card_rect.right - card_w // 4 - 10
            center_x = WINDOW_WIDTH // 2

            for i, sec in enumerate(sections):
                sec_y = start_y + i * spacing_y
                hdr_y = sec_y
                val_y = sec_y + 22

                if "center_hdr" in sec:
                    draw_credits_text(credits_hdr_font, sec["center_hdr"], (255, 205, 90), center_x, hdr_y)
                    draw_credits_text(credits_val_font, sec["center_val"], (245, 240, 230), center_x, val_y)
                else:
                    draw_credits_text(credits_hdr_font, sec["left_hdr"], (255, 205, 90), left_x, hdr_y)
                    draw_credits_text(credits_val_font, sec["left_val"], (245, 240, 230), left_x, val_y)
                    draw_credits_text(credits_hdr_font, sec["right_hdr"], (255, 205, 90), right_x, hdr_y)
                    draw_credits_text(credits_val_font, sec["right_val"], (245, 240, 230), right_x, val_y)


            # Back Button
            btn_back_credits = pygame.Rect(WINDOW_WIDTH // 2 - 90, 542, 180, 40)
            is_bc_hover = btn_back_credits.collidepoint(mx, my)
            pygame.draw.rect(screen, (0, 0, 0), btn_back_credits.inflate(4, 4), border_radius=6)
            pygame.draw.rect(screen, (130, 75, 35) if is_bc_hover else (95, 45, 18), btn_back_credits, border_radius=6)
            pygame.draw.rect(screen, (255, 200, 80), btn_back_credits, 2, border_radius=6)
            txt_bc = menu_font.render(t("btn_back", current_language), False, (255, 255, 255))
            screen.blit(txt_bc, txt_bc.get_rect(center=btn_back_credits.center))

            for event in events:
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if btn_back_credits.collidepoint(mx, my):
                        game_state = "MAIN_MENU"
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    game_state = "MAIN_MENU"

            flip_display()
            continue

        # =========================================================================
        # 3. RPG MODE DELEGATION
        # =========================================================================
        elif game_state == "RPG_MODE":
            if rpg_game:
                for event in events:
                    if event.type == pygame.VIDEORESIZE:
                        rpg_game.width, rpg_game.height = event.w, event.h
                    elif event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
                        settings_fullscreen = not settings_fullscreen
                        if settings_fullscreen:
                            real_screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
                        else:
                            real_screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.RESIZABLE)
                        win_w, win_h = real_screen.get_size()
                        rpg_game.width, rpg_game.height = win_w, win_h

                rpg_game.update(dt, events)
                rpg_game.draw(real_screen)
                pygame.display.flip()

                if getattr(rpg_game, 'request_main_menu', False):
                    game_state = "MAIN_MENU"
            else:
                game_state = "MAIN_MENU"

            continue

        # =========================================================================
        # 4. SANDBOX MODE DELEGATION
        # =========================================================================
        elif game_state == "SANDBOX_MODE":
            if sandbox_game:
                for event in events:
                    if event.type == pygame.VIDEORESIZE:
                        sandbox_game.width, sandbox_game.height = event.w, event.h
                        sandbox_game.panel_rect.x = event.w - sandbox_game.panel_w
                        sandbox_game.panel_rect.height = event.h
                    elif event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
                        settings_fullscreen = not settings_fullscreen
                        if settings_fullscreen:
                            real_screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
                        else:
                            real_screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.RESIZABLE)
                        win_w, win_h = real_screen.get_size()
                        sandbox_game.width, sandbox_game.height = win_w, win_h
                        sandbox_game.panel_rect.x = win_w - sandbox_game.panel_w
                        sandbox_game.panel_rect.height = win_h

                sandbox_game.update(dt, events)
                sandbox_game.draw(real_screen)
                pygame.display.flip()

                if getattr(sandbox_game, 'request_main_menu', False):
                    game_state = "MAIN_MENU"
            else:
                game_state = "MAIN_MENU"

            continue
        # =========================================================================
        # 5. WORD TYPIST ARCADE MODE (ZType-style Social Studies Typing Defense)
        # =========================================================================
        elif game_state == "WORD_TYPIST":
            if word_typist_game:
                for event in events:
                    if event.type == pygame.VIDEORESIZE:
                        word_typist_game.resize(event.w, event.h)
                    elif event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
                        settings_fullscreen = not settings_fullscreen
                        if settings_fullscreen:
                            real_screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
                        else:
                            real_screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.RESIZABLE)
                        win_w, win_h = real_screen.get_size()
                        word_typist_game.resize(win_w, win_h)

                word_typist_game.update(dt, events)
                word_typist_game.draw(real_screen)
                pygame.display.flip()

                if getattr(word_typist_game, 'request_main_menu', False):
                    game_state = "MAIN_MENU"
            else:
                game_state = "MAIN_MENU"

            continue

        # =========================================================================
        # 6. VICTORY SCREEN
        # =========================================================================
        elif game_state == "VICTORY":
            if victory_cooldown > 0:
                victory_cooldown -= dt

            screen.fill((15, 12, 24))

            # Golden Frame Box
            box_w, box_h = 640, 380
            box_rect = pygame.Rect((WINDOW_WIDTH - box_w) // 2, (WINDOW_HEIGHT - box_h) // 2, box_w, box_h)
            pygame.draw.rect(screen, (24, 20, 36), box_rect, border_radius=12)
            pygame.draw.rect(screen, (255, 215, 60), box_rect, width=4, border_radius=12)
            pygame.draw.rect(screen, (140, 100, 30), box_rect.inflate(-8, -8), width=2, border_radius=10)

            # Title
            t_title = menu_font.render(t("victory_title", current_language), False, (255, 230, 90))
            screen.blit(t_title, t_title.get_rect(center=(WINDOW_WIDTH // 2, box_rect.top + 60)))

            lines = [
                t("victory_line1", current_language),
                t("victory_line2", current_language),
                t("victory_line3", current_language)
            ]
            for idx, l_str in enumerate(lines):
                col = (255, 255, 255) if idx == 0 else (220, 220, 235)
                ts = hud_font.render(l_str, False, col)
                screen.blit(ts, ts.get_rect(center=(WINDOW_WIDTH // 2, box_rect.top + 140 + idx * 36)))

            if victory_cooldown <= 0:
                pulse = int(math.sin(pygame.time.get_ticks() * 0.006) * 4)
                t_p = prompt_font.render(t("victory_prompt", current_language), False, (255, 220, 90))
                screen.blit(t_p, t_p.get_rect(center=(WINDOW_WIDTH // 2, box_rect.bottom - 50 + pulse)))

            for event in events:
                if event.type == pygame.QUIT:
                    running = False
                elif victory_cooldown <= 0 and (event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN):
                    game_state = "MAIN_MENU"

            flip_display()
            continue

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    asyncio.run(main())
