import pygame
import os
import random
import math
import sys
import array
import json
from touch_controls import VirtualTouchController

if getattr(sys, 'frozen', False):
    BASE_DIR = getattr(sys, '_MEIPASS', os.path.dirname(sys.executable))
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

try:
    from translations import t, load_settings
except Exception:
    def t(key, lang="ENG", default=None):
        return default if default is not None else key
    def load_settings():
        return {"lang": "ENG"}

# Global Font Cache (Eliminates repeated Windows font disk scanning during 60FPS render loop)
_FONT_CACHE = {}
def get_rpg_font(size, bold=True, name="malgungothic,notosanscjk,nanumgothic,applesdgothicneo,segoeui,arial,consolas,couriernew,monospace"):
    key = (name, size, bold)
    if key not in _FONT_CACHE:
        try:
            _FONT_CACHE[key] = pygame.font.SysFont(name, size, bold=bold)
        except Exception:
            _FONT_CACHE[key] = pygame.font.Font(None, size)
    return _FONT_CACHE[key]

class RetroSoundManager:
    def __init__(self):
        self.sounds = {}
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=44100, size=-16, channels=2)
            self.build_sounds()
        except Exception as e:
            print("Audio init warning:", e)

    def generate_tone(self, freqs, duration, wave_type='square', volume=0.4, pitch_slide=False):
        try:
            sample_rate = 44100
            n_samples = int(sample_rate * duration)
            buf = array.array('h')
            if not isinstance(freqs, list):
                freqs = [freqs]
            
            steps = len(freqs)
            samples_per_step = n_samples // steps
            
            for step_idx, freq in enumerate(freqs):
                for i in range(samples_per_step):
                    t = float(i) / sample_rate
                    cur_freq = freq
                    if pitch_slide:
                        cur_freq = freq + (i / samples_per_step) * freq * 1.5
                    
                    if wave_type == 'square':
                        val = 32767 if (t * cur_freq) % 1.0 < 0.5 else -32768
                    elif wave_type == 'triangle':
                        phase = (t * cur_freq) % 1.0
                        val = int((4 * abs(phase - 0.5) - 1) * 32767)
                    elif wave_type == 'sine':
                        val = int(math.sin(2 * math.pi * cur_freq * t) * 32767)
                    else: # noise
                        val = random.randint(-32768, 32767)
                    
                    env = max(0.0, 1.0 - (i / samples_per_step))
                    val = int(val * volume * env)
                    buf.append(val)
                    buf.append(val)
            return pygame.mixer.Sound(buffer=buf)
        except Exception:
            return None

    def build_sounds(self):
        # --- 8-BIT NES CHIPTUNE RETRO SOUND EFFECTS ---
        self.sounds['alert'] = self.generate_tone([1046.5, 1567.98], 0.16, 'square', 0.5) # 8-Bit NES Alert Double-Beep
        self.sounds['key'] = self.generate_tone([1046.5, 1318.5, 1567.98, 2093.0], 0.18, 'square', 0.5) # 8-Bit NES Key Crystal Chime
        self.sounds['gold'] = self.generate_tone([987.77, 1318.5], 0.12, 'square', 0.5) # 8-Bit NES Coin Arpeggio
        self.sounds['chest'] = self.generate_tone([523.25, 659.25, 783.99, 1046.5], 0.35, 'square', 0.5) # 8-Bit NES Treasure Fanfare
        self.sounds['door_unlock'] = self.generate_tone([440.0, 659.25, 880.0], 0.22, 'square', 0.5) # 8-Bit NES Lock Unlock Pulse
        self.sounds['door_locked'] = self.generate_tone([160.0, 100.0], 0.20, 'square', 0.5) # 8-Bit NES Error Buzz
        self.sounds['slash'] = self.generate_tone([800.0, 400.0, 200.0], 0.10, 'noise', 0.4) # 8-Bit NES Sword Slash Noise Burst
        self.sounds['potion'] = self.generate_tone([659.25, 783.99, 987.77, 1318.5], 0.25, 'triangle', 0.45) # 8-Bit NES Health Powerup
        self.sounds['mine_hit'] = self.generate_tone([1400.0, 800.0], 0.08, 'triangle', 0.45) # 8-Bit Rock Hit Clink
        self.sounds['anvil_clang'] = self.generate_tone([1760.0, 880.0, 440.0], 0.22, 'triangle', 0.5) # 8-Bit Blacksmith Anvil Clang
        self.sounds['item_pickup'] = self.generate_tone([880.0, 1320.0], 0.10, 'sine', 0.45) # 8-Bit Item Chime
        self.sounds['craft_success'] = self.generate_tone([523.25, 659.25, 783.99, 1046.5], 0.18, 'triangle', 0.45) # 8-Bit Craft Fanfare
        
        # 8-Bit Retro Fallbacks for Jump, Land & Dialogue Speech Blips
        self.sounds['text_blip'] = self.generate_tone([523.25, 659.25], 0.03, 'square', 0.22) # 8-Bit NES Retro Speech Blip
        self.sounds['synth_jump'] = self.generate_tone([180.0, 350.0, 600.0], 0.15, 'square', 0.35, pitch_slide=True)
        self.sounds['synth_land'] = self.generate_tone([120.0, 60.0], 0.08, 'noise', 0.4)
        self.sounds['synth_step'] = self.generate_tone([200.0], 0.04, 'noise', 0.25)
        
        # Synthesized Thunder & Ambient Rain Sounds
        self.sounds['thunder_heavy'] = self._generate_thunder(duration=1.4, volume=0.55)
        self.sounds['thunder_distant'] = self._generate_thunder(duration=0.9, volume=0.35)
        self.sounds['rain_ambient'] = self._generate_rain_noise(duration=1.8, volume=0.20)

    def _generate_thunder(self, duration=1.4, volume=0.5):
        try:
            sample_rate = 44100
            n_samples = int(sample_rate * duration)
            buf = array.array('h')
            for i in range(n_samples):
                t = float(i) / sample_rate
                env = math.exp(-2.6 * t)
                noise = random.randint(-32768, 32767)
                sine = math.sin(2 * math.pi * 50 * t) * 32767
                val = int((noise * 0.45 + sine * 0.55) * env * volume)
                buf.append(val)
                buf.append(val)
            return pygame.mixer.Sound(buffer=buf)
        except Exception:
            return None

    def _generate_rain_noise(self, duration=1.8, volume=0.18):
        try:
            sample_rate = 44100
            n_samples = int(sample_rate * duration)
            buf = array.array('h')
            for i in range(n_samples):
                t = float(i) / sample_rate
                env = math.sin(math.pi * (i / n_samples))
                noise = random.randint(-16000, 16000)
                val = int(noise * env * volume)
                buf.append(val)
                buf.append(val)
            return pygame.mixer.Sound(buffer=buf)
        except Exception:
            return None

        # Load Realistic SFX Packs (Free Fantasy SFX Pack by TomMusic)
        sfx_root = os.path.join(BASE_DIR, "Voices_Soundeffect", "Free Fantasy SFX Pack By TomMusic", "WAV Files", "SFX")
        
        def load_sfx_list(rel_dir, prefix, count):
            arr = []
            for i in range(1, count + 1):
                p = os.path.join(sfx_root, rel_dir, f"{prefix} {i}.wav")
                if os.path.exists(p):
                    try:
                        snd = pygame.mixer.Sound(p)
                        snd.set_volume(0.4)
                        arr.append(snd)
                    except Exception: pass
            return arr

        def load_sfx_single(rel_dir, filename):
            p = os.path.join(sfx_root, rel_dir, filename)
            if os.path.exists(p):
                try:
                    snd = pygame.mixer.Sound(p)
                    snd.set_volume(0.5)
                    return snd
                except Exception: pass
            return None

        # Footsteps by surface
        self.sounds['dirt_walk'] = load_sfx_list(r"Footsteps\Dirt", "Dirt Walk", 5)
        self.sounds['stone_walk'] = load_sfx_list(r"Footsteps\Stone", "Stone Walk", 5)
        self.sounds['wood_walk'] = load_sfx_list(r"Footsteps\Wood", "Wood Walk", 5)

        # Jump & Land by surface
        self.sounds['dirt_jump'] = load_sfx_single(r"Footsteps\Dirt", "Dirt Jump.wav")
        self.sounds['dirt_land'] = load_sfx_single(r"Footsteps\Dirt", "Dirt Land.wav")

        self.sounds['stone_jump'] = load_sfx_single(r"Footsteps\Stone", "Stone Jump.wav")
        self.sounds['stone_land'] = load_sfx_single(r"Footsteps\Stone", "Stone Land.wav")

        self.sounds['wood_jump'] = load_sfx_single(r"Footsteps\Wood", "Wood Jump.wav")
        self.sounds['wood_land'] = load_sfx_single(r"Footsteps\Wood", "Wood Land.wav")

        # Doors & Chests
        self.sounds['door_open'] = [load_sfx_single(r"Doors Gates and Chests", f"Door Open {i}.wav") for i in (1, 2)]
        self.sounds['door_open'] = [s for s in self.sounds['door_open'] if s]

        self.sounds['door_close'] = [load_sfx_single(r"Doors Gates and Chests", f"Door Close {i}.wav") for i in (1, 2)]
        self.sounds['door_close'] = [s for s in self.sounds['door_close'] if s]

        self.sounds['chest_open'] = [load_sfx_single(r"Doors Gates and Chests", f"Chest Open {i}.wav") for i in (1, 2)]
        self.sounds['chest_open'] = [s for s in self.sounds['chest_open'] if s]

        self.sounds['chest_close'] = [load_sfx_single(r"Doors Gates and Chests", f"Chest Close {i}.wav") for i in (1, 2)]
        self.sounds['chest_close'] = [s for s in self.sounds['chest_close'] if s]

        self.sounds['lock_unlock'] = load_sfx_single(r"Doors Gates and Chests", "Lock Unlock.wav")

    def play_footstep(self, surface_type="dirt"):
        key = f"{surface_type}_walk"
        if key in self.sounds and self.sounds[key]:
            random.choice(self.sounds[key]).play()
        elif 'dirt_walk' in self.sounds and self.sounds['dirt_walk']:
            random.choice(self.sounds['dirt_walk']).play()

    def play_jump(self, surface_type="dirt"):
        key = f"{surface_type}_jump"
        if key in self.sounds and self.sounds[key]:
            self.sounds[key].play()
        elif self.sounds.get('dirt_jump'):
            self.sounds['dirt_jump'].play()

    def play_land(self, surface_type="dirt"):
        key = f"{surface_type}_land"
        if key in self.sounds and self.sounds[key]:
            self.sounds[key].play()
        elif self.sounds.get('dirt_land'):
            self.sounds['dirt_land'].play()

    def play_door_open(self):
        if self.sounds.get('door_open'):
            random.choice(self.sounds['door_open']).play()
        if self.sounds.get('lock_unlock'):
            self.sounds['lock_unlock'].play()

    def play_door_close(self):
        if self.sounds.get('door_close'):
            random.choice(self.sounds['door_close']).play()

    def play_chest_open(self):
        if self.sounds.get('chest_open'):
            random.choice(self.sounds['chest_open']).play()

    def play_chest_close(self):
        if self.sounds.get('chest_close'):
            random.choice(self.sounds['chest_close']).play()

    def play(self, sound_name):
        if sound_name in self.sounds and self.sounds[sound_name]:
            try:
                snd = self.sounds[sound_name]
                if isinstance(snd, list):
                    if snd: random.choice(snd).play()
                else:
                    snd.play()
            except Exception:
                pass

# Global Sound Manager Instance
sound_mgr = RetroSoundManager()

class PianoSynth:
    def __init__(self):
        self.sounds = {}
        self.sound_cache = {}
        # Full 61-Note QWERTY Virtual Piano Mapping (MIDI 36 to 96)
        # White Keys: Normal lowercase QWERTY keys
        # Black Keys: Shift + Capital QWERTY keys (# / Flats)
        self.mapping = [
            ('1', 'C2', 36, False), ('!', 'C#2', 37, True),
            ('2', 'D2', 38, False), ('@', 'D#2', 39, True),
            ('3', 'E2', 40, False),
            ('4', 'F2', 41, False), ('$', 'F#2', 42, True),
            ('5', 'G2', 43, False), ('%', 'G#2', 44, True),
            ('6', 'A2', 45, False), ('^', 'A#2', 46, True),
            ('7', 'B2', 47, False),
            ('8', 'C3', 48, False), ('*', 'C#3', 49, True),
            ('9', 'D3', 50, False), ('(', 'D#3', 51, True),
            ('0', 'E3', 52, False),
            ('q', 'F3', 53, False), ('Q', 'F#3', 54, True),
            ('w', 'G3', 55, False), ('W', 'G#3', 56, True),
            ('e', 'A3', 57, False), ('E', 'A#3', 58, True),
            ('r', 'B3', 59, False),
            ('t', 'C4', 60, False), ('T', 'C#4', 61, True),
            ('y', 'D4', 62, False), ('Y', 'D#4', 63, True),
            ('u', 'E4', 64, False),
            ('i', 'F4', 65, False), ('I', 'F#4', 66, True),
            ('o', 'G4', 67, False), ('O', 'G#4', 68, True),
            ('p', 'A4', 69, False), ('P', 'A#4', 70, True),
            ('a', 'B4', 71, False),
            ('s', 'C5', 72, False), ('S', 'C#5', 73, True),
            ('d', 'D5', 74, False), ('D', 'D#5', 75, True),
            ('f', 'E5', 76, False),
            ('g', 'F5', 77, False), ('G', 'F#5', 78, True),
            ('h', 'G5', 79, False), ('H', 'G#5', 80, True),
            ('j', 'A5', 81, False), ('J', 'A#5', 82, True),
            ('k', 'B5', 83, False),
            ('l', 'C6', 84, False), ('L', 'C#6', 85, True),
            ('z', 'D6', 86, False), ('Z', 'D#6', 87, True),
            ('x', 'E6', 88, False),
            ('c', 'F6', 89, False), ('C', 'F#6', 90, True),
            ('v', 'G6', 91, False), ('V', 'G#6', 92, True),
            ('b', 'A6', 93, False), ('B', 'A#6', 94, True),
            ('n', 'B6', 95, False),
            ('m', 'C7', 96, False)
        ]
        self.char_to_info = {char: (name, midi, is_black) for char, name, midi, is_black in self.mapping}
        # Pre-cache middle octave (C4-B4) for instant response, lazy-cache rest on demand
        for char in ['t', 'T', 'y', 'Y', 'u', 'i', 'I', 'o', 'O', 'p', 'P', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k']:
            if char in self.char_to_info:
                self._gen_and_cache(char, sustain=False, soft=False, sostenuto=False)

    def _gen_and_cache(self, char, sustain, soft, sostenuto):
        cache_key = (char, sustain, soft, sostenuto)
        if cache_key in self.sound_cache:
            return self.sound_cache[cache_key]
        sound = self._gen_sound_variant(char, sustain, soft, sostenuto)
        self.sound_cache[cache_key] = sound
        return sound

    def play_char(self, char, sustain=False, soft=False, sostenuto=False):
        if char in self.char_to_info:
            cache_key = (char, sustain, soft, sostenuto)
            sound = self.sound_cache.get(cache_key)
            if sound is None:
                sound = self._gen_and_cache(char, sustain, soft, sostenuto)
            if sound:
                try:
                    sound.play()
                except Exception:
                    pass

    def _gen_sound_variant(self, char, sustain, soft, sostenuto):
        if not pygame.mixer.get_init():
            return None
        info = self.char_to_info.get(char)
        if not info:
            return None
        name, midi, is_black = info
        freq = 440.0 * (2.0 ** ((midi - 69) / 12.0))
        
        init_res = pygame.mixer.get_init()
        sr = init_res[0] if init_res else 44100
        channels = init_res[2] if init_res else 2
        
        # Relative pitch (0.0 at lowest C2 to 1.0 at highest C7)
        rel_pitch = max(0.0, min(1.0, (midi - 36) / 60.0))

        # Real Acoustic Grand Piano Envelope:
        if sustain:
            dur = 3.6 - 0.8 * rel_pitch
            base_decay = 0.65 + 0.45 * rel_pitch
        elif sostenuto:
            dur = 3.0 - 0.7 * rel_pitch
            base_decay = 0.85 + 0.55 * rel_pitch
        else:
            # Normal key playback: natural grand piano bloom and singing sustain
            dur = 2.2 - 0.6 * rel_pitch
            base_decay = 1.25 + 0.75 * rel_pitch

        vol = 0.55 if soft else 1.0
        
        try:
            import numpy as np
            n_samples = int(sr * dur)
            t = np.linspace(0, dur, n_samples, endpoint=False, dtype=np.float32)
            t_2pi = 2.0 * np.pi * t

            # Physical Inharmonicity Coefficient for steel piano wire
            B = 0.00015
            
            # Dual-stage decay: prompt soundboard vibration + lingering string resonance
            prompt = 0.65 * np.exp(-t * (base_decay * 1.5)) + 0.35 * np.exp(-t * (base_decay * 0.6))
            
            # Harmonics with physical inharmonicity and unison detuning (triple strings chorus)
            val = np.zeros_like(t)
            harmonics = [
                (1, 1.00, 1.0),
                (2, 0.62, 1.3),
                (3, 0.35, 1.7),
                (4, 0.18, 2.2),
                (5, 0.09, 2.7),
                (6, 0.04, 3.3)
            ]
            for n, amp, dec_mult in harmonics:
                fn = n * freq * np.sqrt(1.0 + B * (n ** 2))
                h_env = np.exp(-t * (base_decay * dec_mult)) * amp
                s1 = np.sin(fn * t_2pi)
                s2 = 0.85 * np.sin((fn * 1.00085) * t_2pi)
                s3 = 0.85 * np.sin((fn * 0.99915) * t_2pi)
                val += ((s1 + s2 + s3) / 2.7) * h_env

            if sostenuto:
                val += 0.22 * np.sin((freq * 2.003) * t_2pi) * np.exp(-t * (base_decay * 0.85))

            # Soft felt hammer knock impulse transient
            thump = 0.18 * np.exp(-t / 0.012) * np.sin(95.0 * t_2pi)
            
            # Smooth anti-click attack ramp
            attack = np.minimum(t * 320.0, 1.0)
            
            val = ((val * prompt) + thump) * attack * vol
            
            # Normalize without clipping
            max_v = np.max(np.abs(val))
            if max_v > 0.01:
                val = val / max_v
            
            samples = (val * 24000.0).clip(-32767, 32767).astype(np.int16)
            
            if channels == 2:
                # Spatial Acoustic Panning: bass left, treble right
                pan_left = 0.65 - 0.30 * rel_pitch
                pan_right = 0.35 + 0.30 * rel_pitch
                left_ch = (samples * pan_left).astype(np.int16)
                right_ch = (samples * pan_right).astype(np.int16)
                stereo = np.column_stack((left_ch, right_ch)).ravel()
                return pygame.mixer.Sound(buffer=stereo.tobytes())
            else:
                return pygame.mixer.Sound(buffer=samples.tobytes())
        except Exception:
            # Fallback pure Python if numpy is unavailable
            n_samples = int(sr * min(dur, 2.0))
            buf = array.array('h')
            for i in range(n_samples):
                t_val = i / float(sr)
                env = math.exp(-t_val * base_decay)
                attack = min(t_val * 320.0, 1.0)
                s1 = math.sin(2.0 * math.pi * freq * t_val)
                s2 = 0.8 * math.sin(2.0 * math.pi * (freq * 1.00085) * t_val)
                s3 = 0.8 * math.sin(2.0 * math.pi * (freq * 0.99915) * t_val)
                h2 = 0.5 * math.sin(4.0 * math.pi * freq * t_val) * math.exp(-t_val * base_decay * 1.3)
                v = (((s1 + s2 + s3) / 2.6) + h2) * env * attack * vol
                s_val = int(max(-32767, min(32767, (v / 1.5) * 22000.0)))
                if channels == 2:
                    buf.append(s_val)
                    buf.append(s_val)
                else:
                    buf.append(s_val)
            return pygame.mixer.Sound(buffer=buf)

class PianoUI:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.synth = PianoSynth()
        self.active_chars = set()
        self.recent_notes = []
        self.shift_pressed = False
        
        # Pre-cache UI Fonts ONCE on startup
        self.font_title = get_rpg_font(18, bold=True)
        self.font_sub = get_rpg_font(11, bold=True)
        self.font_key = get_rpg_font(9, bold=True)
        self.font_black = get_rpg_font(8, bold=True)
        self.font_pedal = get_rpg_font(9, bold=True)
        
        # 3 Piano Pedals
        self.pedal_sustain = False
        self.pedal_soft = False
        self.pedal_sostenuto = False
        
        # World Cultural Heritage Song Guide: Beethoven's Ode to Joy
        self.song_guide_active = False
        self.song_notes = ['3', '3', '4', '5', '5', '4', '3', '2', '1', '1', '2', '3', '3', '2', '2']
        self.song_step = 0
        self.song_completed = False
        self.pulse_timer = 0.0

        # Authentic Yiruma - River Flows in You Song Sequencer (74 BPM)
        self.river_flows_score = [
            ('j', 0.60), ('H', 0.20), ('j', 0.40), ('H', 0.20), ('j', 0.20), ('f', 0.80), ('j', 0.40), ('d', 1.40),
            ('p', 0.40), ('S', 0.40),
            ('j', 0.60), ('H', 0.20), ('j', 0.40), ('H', 0.20), ('j', 0.20), ('f', 0.80), ('j', 0.40), ('d', 1.40),
            ('p', 0.40), ('S', 0.40),
            ('j', 0.60), ('H', 0.20), ('j', 0.40), ('p', 0.80), ('S', 0.80),
            ('e', 0.40), ('s', 0.40), ('f', 0.40), ('k', 0.40), ('l', 0.40), ('k', 0.40),
            ('i', 0.40), ('h', 0.40), ('l', 0.40), ('g', 0.40), ('s', 0.40), ('f', 1.20)
        ]
        self.is_playing_river_flows = False
        self.river_flows_timer = 0.0
        self.river_flows_idx = 0
        self.btn_river_flows_rect = pygame.Rect(width - 240, 18, 220, 28)
        
        self.transition_alpha = 0
        self.transition_state = "none"
        self.close_requested = False

    def play_river_flows_in_you(self):
        """Start playing Yiruma's 'River Flows in You' with accurate 74 BPM timing."""
        self.is_playing_river_flows = True
        self.river_flows_timer = 0.0
        self.river_flows_idx = 0
        self.pedal_sustain = True
        self.active_chars.clear()
        if self.river_flows_score:
            first_ch, _ = self.river_flows_score[0]
            self.synth.play_char(first_ch, sustain=True)
            self.active_chars.add(first_ch)
            if first_ch in self.synth.char_to_info:
                name, _, _ = self.synth.char_to_info[first_ch]
                self.recent_notes.append(name)

    def open(self):
        self.transition_state = "fading_in"
        self.transition_alpha = 0
        self.active_chars.clear()
        self.shift_pressed = False
        self.pedal_sustain = False
        self.pedal_soft = False
        self.pedal_sostenuto = False
        self.recent_notes.clear()
        self.close_requested = False

    def close(self):
        self.transition_state = "fading_out"

    def is_active(self):
        return self.transition_state in ["active", "fading_in", "fading_out"]

    @property
    def active(self):
        return self.is_active()

    @active.setter
    def active(self, value):
        if value:
            self.open()
            self.transition_state = "active"
            self.transition_alpha = 255
        else:
            self.close()

    def update(self, dt, events, keys=None):
        if self.transition_state == "fading_in":
            self.transition_alpha += dt * 600
            if self.transition_alpha >= 255:
                self.transition_alpha = 255
                self.transition_state = "active"
        elif self.transition_state == "fading_out":
            self.transition_alpha -= dt * 600
            if self.transition_alpha <= 0:
                self.transition_alpha = 0
                self.transition_state = "none"
            return

        if self.transition_state != "active":
            return

        keys = pygame.key.get_pressed()
        self.shift_pressed = bool(keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT])
        self.pulse_timer += dt
        
        # Track 3 Piano Pedals
        self.pedal_soft = bool(keys[pygame.K_LCTRL] or keys[pygame.K_RCTRL])
        self.pedal_sostenuto = bool(keys[pygame.K_TAB])
        self.pedal_sustain = bool(keys[pygame.K_SPACE])

        # Advance River Flows in You Song Sequencer
        if self.is_playing_river_flows:
            self.river_flows_timer += dt
            if self.river_flows_idx < len(self.river_flows_score):
                curr_ch, curr_dur = self.river_flows_score[self.river_flows_idx]
                if self.river_flows_timer >= curr_dur:
                    self.river_flows_timer -= curr_dur
                    self.river_flows_idx += 1
                    if self.river_flows_idx < len(self.river_flows_score):
                        next_ch, _ = self.river_flows_score[self.river_flows_idx]
                        self.active_chars.clear()
                        self.synth.play_char(next_ch, sustain=True)
                        self.active_chars.add(next_ch)
                        if next_ch in self.synth.char_to_info:
                            name, _, _ = self.synth.char_to_info[next_ch]
                            self.recent_notes.append(name)
                            if len(self.recent_notes) > 8:
                                self.recent_notes.pop(0)
                    else:
                        self.is_playing_river_flows = False
                        self.active_chars.clear()
            else:
                self.is_playing_river_flows = False
                self.active_chars.clear()

        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.close()
                    return
                elif event.key == pygame.K_F1:
                    self.song_guide_active = not self.song_guide_active
                elif event.key == pygame.K_F2:
                    self.play_river_flows_in_you()
                elif event.unicode:
                    ch = event.unicode
                    if ch:
                        if ch in self.synth.char_to_info:
                            name, midi, is_black = self.synth.char_to_info[ch]
                            self.synth.play_char(ch, sustain=self.pedal_sustain, soft=self.pedal_soft, sostenuto=self.pedal_sostenuto)
                            self.active_chars.add(ch)
                            self.recent_notes.append(name)
                            if len(self.recent_notes) > 8:
                                self.recent_notes.pop(0)
                            
                            # Check Song Guide Progression
                            if self.song_guide_active:
                                if self.song_step < len(self.song_notes) and ch == self.song_notes[self.song_step]:
                                    self.song_step += 1
                                    if self.song_step >= len(self.song_notes):
                                        self.song_completed = True

            elif event.type == pygame.KEYUP:
                if event.unicode:
                    ch = event.unicode
                    if ch in self.active_chars and not self.is_playing_river_flows:
                        self.active_chars.remove(ch)

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self.btn_river_flows_rect.collidepoint(event.pos):
                    self.play_river_flows_in_you()

    def draw(self, surface):
        if self.transition_state == "none":
            return

        # Semi-transparent backdrop overlay
        overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        overlay.fill((15, 15, 25, int(min(235, self.transition_alpha))))
        surface.blit(overlay, (0, 0))

        if self.transition_state not in ["active", "fading_in", "fading_out"]:
            return

        # Wooden Piano Stand Frame (Full 61-Key Width + Pedals Height)
        stand_rect = pygame.Rect(self.width // 2 - 390, self.height // 2 - 180, 780, 360)
        pygame.draw.rect(surface, (45, 25, 18), stand_rect, border_radius=14)
        pygame.draw.rect(surface, (160, 100, 50), stand_rect, 4, border_radius=14)

        # Title
        title_txt = self.font_title.render("FULL 61-KEY PIANO - WORLD CULTURAL HERITAGE", False, (255, 220, 120))
        surface.blit(title_txt, (self.width // 2 - title_txt.get_width() // 2, stand_rect.top + 12))

        # River Flows in You Button
        mx, my = pygame.mouse.get_pos()
        is_rf_hover = self.btn_river_flows_rect.collidepoint(mx, my)
        rf_bg = (120, 70, 20) if self.is_playing_river_flows else ((90, 50, 25) if is_rf_hover else (60, 32, 16))
        rf_border = (255, 220, 90) if self.is_playing_river_flows else ((220, 180, 70) if is_rf_hover else (150, 100, 40))
        pygame.draw.rect(surface, (0, 0, 0), self.btn_river_flows_rect.inflate(4, 4), border_radius=6)
        pygame.draw.rect(surface, rf_bg, self.btn_river_flows_rect, border_radius=6)
        pygame.draw.rect(surface, rf_border, self.btn_river_flows_rect, 2, border_radius=6)
        rf_lbl = "PLAYING RIVER FLOWS..." if self.is_playing_river_flows else "PLAY: RIVER FLOWS [F2]"
        rf_txt = self.font_sub.render(rf_lbl, False, (255, 240, 160) if is_rf_hover or self.is_playing_river_flows else (220, 210, 190))
        surface.blit(rf_txt, rf_txt.get_rect(center=self.btn_river_flows_rect.center))

        # Instructions / Cultural Header
        sub_color = (255, 220, 100) if self.shift_pressed else (210, 220, 240)
        sub_txt = self.font_sub.render("Beethoven's Ode to Joy [F1] | Yiruma: River Flows in You [F2] | [ESC] Exit", False, sub_color)
        surface.blit(sub_txt, (self.width // 2 - sub_txt.get_width() // 2, stand_rect.top + 36))

        # Music Sheet Display
        sheet_rect = pygame.Rect(self.width // 2 - 340, stand_rect.top + 56, 680, 28)
        pygame.draw.rect(surface, (25, 18, 12), sheet_rect, border_radius=6)
        pygame.draw.rect(surface, (220, 180, 100), sheet_rect, 2, border_radius=6)
        
        if self.song_guide_active:
            if self.song_completed:
                sheet_msg = "CONGRATULATIONS! You played Beethoven's Ode to Joy (Anthem of World Brotherhood & Peace)!"
                notes_txt = self.font_sub.render(sheet_msg, False, (255, 225, 80))
            else:
                next_key = self.song_notes[self.song_step]
                sheet_msg = f"ODE TO JOY [Step {self.song_step + 1}/15]: Press '{next_key}' | Sequence: 3 3 4 5  5 4 3 2  1 1 2 3  3 2 2"
                notes_txt = self.font_sub.render(sheet_msg, False, (255, 235, 170))
        else:
            notes_str = " - ".join(self.recent_notes) if self.recent_notes else "Free Play: Press any QWERTY keys to play melodies! [F1] for Song Guide"
            notes_txt = self.font_sub.render(notes_str, False, (255, 240, 180))
            
        surface.blit(notes_txt, (sheet_rect.centerx - notes_txt.get_width() // 2, sheet_rect.centery - notes_txt.get_height() // 2))

        # Render 61 Piano Keys (36 White Keys & 25 Black Keys)
        keys_start_x = self.width // 2 - 350
        keys_y = stand_rect.top + 95
        white_w = 19
        white_h = 135
        black_w = 13
        black_h = 80

        next_ch = self.song_notes[self.song_step] if (self.song_guide_active and not self.song_completed) else None

        # Pass 1: Draw White Keys
        white_count = 0
        white_positions = {}

        for char, name, midi, is_black in self.synth.mapping:
            if not is_black:
                kx = keys_start_x + white_count * (white_w + 1)
                white_positions[midi] = kx
                is_pressed = char in self.active_chars
                is_target = (char == next_ch)
                
                ky = keys_y + (4 if is_pressed else 0)
                k_rect = pygame.Rect(kx, ky, white_w, white_h - (4 if is_pressed else 0))
                
                if is_pressed:
                    k_color = (255, 235, 120)
                elif is_target:
                    pulse_val = int(220 + 35 * math.sin(self.pulse_timer * 6.0))
                    k_color = (255, pulse_val, 160)
                else:
                    k_color = (248, 248, 248)
                    
                pygame.draw.rect(surface, k_color, k_rect, border_radius=3)
                pygame.draw.rect(surface, (40, 40, 40), k_rect, 1, border_radius=3)
                
                if is_target:
                    pygame.draw.rect(surface, (255, 200, 30), k_rect.inflate(2, 2), 2, border_radius=4)
                
                # Render cached label
                lbl = self.font_key.render(char, False, (20, 20, 20) if is_target else (40, 40, 40))
                surface.blit(lbl, (kx + white_w // 2 - lbl.get_width() // 2, ky + white_h - 18))
                
                white_count += 1

        # Pass 2: Draw Black Keys (Overlaid on white key gaps)
        for char, name, midi, is_black in self.synth.mapping:
            if is_black:
                prev_white_x = white_positions.get(midi - 1, keys_start_x)
                bx = prev_white_x + white_w - (black_w // 2)
                is_pressed = char in self.active_chars
                is_target = (char == next_ch)
                
                by = keys_y + (4 if is_pressed else 0)
                b_rect = pygame.Rect(bx, by, black_w, black_h - (4 if is_pressed else 0))
                
                if is_pressed:
                    b_color = (255, 200, 50)
                elif is_target:
                    b_color = (220, 160, 40)
                elif self.shift_pressed:
                    b_color = (60, 60, 70)
                else:
                    b_color = (25, 25, 28)
                    
                pygame.draw.rect(surface, b_color, b_rect, border_radius=2)
                pygame.draw.rect(surface, (10, 10, 10), b_rect, 1, border_radius=2)
                
                if is_target:
                    pygame.draw.rect(surface, (255, 215, 60), b_rect.inflate(2, 2), 2, border_radius=3)
                
                if self.shift_pressed or is_pressed or is_target:
                    lbl = self.font_black.render(char, False, (255, 255, 255) if not is_pressed else (0, 0, 0))
                    surface.blit(lbl, (bx + black_w // 2 - lbl.get_width() // 2, by + black_h - 16))

        # Render 3 Brass Metallic Piano Pedals at Bottom
        pedal_w = 40
        pedal_h = 45
        pedal_y = keys_y + white_h + 15
        
        pedals_info = [
            ("SOFT [CTRL]", self.pedal_soft, self.width // 2 - 110),
            ("REVERB [TAB]", self.pedal_sostenuto, self.width // 2 - 20),
            ("SUSTAIN [SPACE]", self.pedal_sustain, self.width // 2 + 70)
        ]

        for label, is_active, px in pedals_info:
            py = pedal_y + (5 if is_active else 0)
            p_rect = pygame.Rect(px, py, pedal_w, pedal_h - (5 if is_active else 0))
            
            # Brass metallic color (Gold when active, Metallic Brass when idle)
            p_color = (255, 220, 90) if is_active else (210, 170, 60)
            pygame.draw.rect(surface, p_color, p_rect, border_radius=6)
            pygame.draw.rect(surface, (255, 240, 160) if is_active else (130, 90, 20), p_rect, 2, border_radius=6)
            
            # Label (Pixel Comic Sans font) - Highlight bright gold when active, warm cream when idle
            lbl_color = (255, 235, 120) if is_active else (210, 195, 170)
            lbl = self.font_pedal.render(label, False, lbl_color)
            surface.blit(lbl, (px + pedal_w // 2 - lbl.get_width() // 2, pedal_y + pedal_h + 6))

class RPGCamera:
    def __init__(self, width, height):
        self.camera = pygame.Rect(0, 0, width, height)
        self.width = width
        self.height = height
        self.float_x = 0.0
        self.float_y = 0.0

    def apply_rect(self, rect):
        return rect.move(self.camera.topleft)

    def apply_point(self, pos):
        return (pos[0] + self.camera.x, pos[1] + self.camera.y)

    def update(self, target_rect, dt=0.016, max_w=None, max_h=None):
        target_x = -target_rect.centerx + int(self.width / 2)
        target_y = -target_rect.centery + int(self.height / 2)
        # Bounded clamping only when explicit limits are given (e.g. dungeon interior)
        if max_w is not None and max_w > self.width:
            target_x = max(-(max_w - self.width), min(0, target_x))
        if max_h is not None and max_h > self.height:
            target_y = max(-(max_h - self.height), min(0, target_y))
        # Infinite world: no clamping when max_w/max_h are None
        
        # Instant 1-to-1 camera tracking with ZERO lag, zero delay, and zero rubberbanding!
        self.float_x = float(target_x)
        self.float_y = float(target_y)
        self.camera = pygame.Rect(int(self.float_x), int(self.float_y), self.width, self.height)

class RPGPlayer:
    def __init__(self, x, y, base_dir):
        self.rect = pygame.Rect(x, y, 64, 64)
        self.speed = 250
        self.hp = 100
        self.max_hp = 100
        
        # Load animations from free_player
        self.animations = {}
        possible_dirs = [
            os.path.join(base_dir, "3D_Assets", "Fantasy Chronicles", "sprites", "free_player"),
            os.path.join(base_dir, "3D_Assets", "Fantasy Chronicles", "sprites", "free_player"),
        ]
        if getattr(sys, 'frozen', False):
            meipass = getattr(sys, '_MEIPASS', base_dir)
            possible_dirs.insert(0, os.path.join(meipass, "3D_Assets", "Fantasy Chronicles", "sprites", "free_player"))
            possible_dirs.insert(1, os.path.join(meipass, "3D_Assets", "Fantasy Chronicles", "sprites", "free_player"))
        
        player_dir = None
        for pd in possible_dirs:
            if os.path.exists(pd):
                player_dir = pd
                break
        if not player_dir:
            player_dir = possible_dirs[0]

        directions = ["Up", "Down", "Left", "Right"]
        actions = ["Jump", "Walk", "Slash", "Death"]
        
        for d in directions:
            for a in actions:
                candidates = [
                    os.path.join(player_dir, f"Sprite_{d}", a),
                    os.path.join(player_dir, f"sprite_{d.lower()}", a),
                    os.path.join(player_dir, f"Sprite_{d.lower()}", a),
                    os.path.join(player_dir, f"sprite_{d}", a)
                ]
                anim_dir = None
                for c in candidates:
                    if os.path.exists(c):
                        anim_dir = c
                        break
                
                frames = []
                if anim_dir and os.path.exists(anim_dir):
                    files = [f for f in os.listdir(anim_dir) if f.endswith('.png')]
                    def sort_key(name):
                        try:
                            return (0, int(os.path.splitext(name)[0]))
                        except ValueError:
                            return (1, name)
                    files.sort(key=sort_key)
                    
                    for f in files:
                        frame_path = os.path.join(anim_dir, f)
                        try:
                            img = pygame.image.load(frame_path).convert_alpha()
                            width, height = img.get_size()
                            img = pygame.transform.scale(img, (width * 2, height * 2))
                            frames.append(img)
                        except Exception:
                            pass
                
                if not frames:
                    # Robust fallback surface so character is ALWAYS visible
                    fb = pygame.Surface((32 * 2, 32 * 2), pygame.SRCALPHA)
                    pygame.draw.circle(fb, (60, 140, 240), (32, 32), 24)
                    pygame.draw.circle(fb, (255, 255, 255), (32, 32), 24, 2)
                    frames.append(fb)

                self.animations[f"{d}_{a}"] = frames
                
        self.facing = "Down"
        self.action = "Stand"
        self.frame_index = 0
        self.anim_timer = 0
        self.is_attacking = False
        
        self.z = 0.0
        self.z_vel = 0.0
        self.is_jumping = False
        self.footstep_timer = 0.0
        self.disable_input = False
        self.door_interaction = False
        self.silver_keys_collected = 0
        self.equipped_tool_img = None

    def get_terrain_at(self, map_obj):
        """Detects surface terrain type for outside world (dirt, stone, wood)."""
        p_rect = pygame.Rect(self.rect.x + 8, self.rect.bottom - 16, 32, 16)
        if map_obj and hasattr(map_obj, 'objects'):
            for obj in map_obj.objects:
                if obj.get("type") in ["house", "stairs", "slab"]:
                    if "hitbox" in obj and p_rect.inflate(12, 12).colliderect(obj["hitbox"]):
                        return "stone"
        return "dirt"
        
    def update(self, dt, keys, map_obj, touch_ctrl=None, game=None):
        if self.disable_input:
            return

        mouse_pressed = pygame.mouse.get_pressed()
        touch_atk = bool(touch_ctrl and touch_ctrl.is_button_pressed("attack"))
        joy_x, joy_y = touch_ctrl.get_movement_vector() if touch_ctrl else (0.0, 0.0)
        
        if self.is_attacking:
            self.anim_timer += dt
            if self.anim_timer > 0.15:
                self.anim_timer = 0
                self.frame_index += 1
                
                # Check if animation finished
                anim_key = f"{self.facing}_{self.action}"
                frames = self.animations.get(anim_key, [])
                if self.frame_index >= len(frames):
                    self.is_attacking = False
                    self.action = "Stand"
                    self.frame_index = 0
                    
            if not getattr(self, 'has_dealt_damage', False) and int(self.frame_index) >= 1:
                self.has_dealt_damage = True
                sword_rect = self.rect.copy()
                if self.facing == "Up":
                    sword_rect = pygame.Rect(self.rect.centerx - 36, self.rect.top - 48, 72, 60)
                elif self.facing == "Down":
                    sword_rect = pygame.Rect(self.rect.centerx - 36, self.rect.bottom - 12, 72, 60)
                elif self.facing == "Left":
                    sword_rect = pygame.Rect(self.rect.left - 48, self.rect.centery - 36, 60, 72)
                elif self.facing == "Right":
                    sword_rect = pygame.Rect(self.rect.right - 12, self.rect.centery - 36, 60, 72)
                    
                dead_entities = []
                for obj in map_obj.objects:
                    # Check equipped tool from hotbar
                    equipped = game.get_equipped_item() if game and hasattr(game, 'get_equipped_item') else None
                    eq_name = equipped["name"] if equipped else ""

                    if obj.get("type") == "bear":
                        b = obj["bear_obj"]
                        # Check collision against full bear body or hitbox
                        if (sword_rect.colliderect(b.rect) or sword_rect.colliderect(b.hitbox)) and b.hurt_timer <= 0:
                            dmg = 2 if ("Sword" in eq_name or "Blade" in eq_name) else 1
                            b.take_damage(dmg, self.facing, map_obj)
                            if b.hp <= 0:
                                dead_entities.append(obj)
                                # Defeating bears drops high-protein Raw Bear Meat!
                                if hasattr(map_obj, 'ground_items'):
                                    map_obj.ground_items.append(
                                        RPGGroundItem(b.rect.centerx, b.rect.centery, "Raw Bear Meat", random.randint(1, 2), "raw_meat.png", map_obj.base_dir, "Fresh wild game meat harvested from forest bears. High in protein; cook over coal to make hearty steak.", heal=15)
                                    )
                                if game and hasattr(game, 'discover_social_studies'):
                                    game.discover_social_studies("ecology")
                    elif obj.get("type") == "village_animal":
                        anim = obj["animal_obj"]
                        if (sword_rect.colliderect(anim.rect) or sword_rect.colliderect(anim.hitbox)) and anim.hurt_timer <= 0:
                            anim.take_damage(1, self.facing, map_obj, sound_mgr)
                            if anim.hp <= 0:
                                dead_entities.append(obj)
                    elif obj.get("type") == "mineable_rock":
                        m = obj["mineable_obj"]
                        if (sword_rect.colliderect(m.rect) or sword_rect.colliderect(m.hitbox)):
                            hits_to_deal = 2 if "Pickaxe" in eq_name else 1
                            broken = False
                            for _ in range(hits_to_deal):
                                broken = m.take_hit()
                                if broken:
                                    break
                            sound_mgr.play('mine_hit')
                            if broken:
                                dead_entities.append(obj)
                                drops = m.get_drops()
                                if hasattr(map_obj, 'ground_items'):
                                    map_obj.ground_items.extend(drops)
                                if game and hasattr(game, 'discover_social_studies'):
                                    game.discover_social_studies("mineralogy")
                    elif obj.get("type") == "tree":
                        if sword_rect.colliderect(obj["hitbox"]):
                            dmg = 2 if "Axe" in eq_name else 1
                            obj["hits"] = obj.get("hits", 0) + dmg
                            obj["hit_timer"] = 0.25
                            sound_mgr.play('mine_hit')
                            # Drop Wood Log on hit
                            if hasattr(map_obj, 'ground_items'):
                                map_obj.ground_items.append(
                                    RPGGroundItem(obj["hitbox"].centerx + random.randint(-12, 12),
                                                  obj["hitbox"].bottom + random.randint(4, 16),
                                                  "Wood Log", 1, "wood_log.png",
                                                  map_obj.base_dir, "Dense timber harvested from forest trees. Rich in natural cellulose; crafts into wood planks.")
                                )
                            if game and hasattr(game, 'discover_social_studies'):
                                game.discover_social_studies("cellulose")
                            # If tree depleted, fell the tree!
                            if obj["hits"] >= obj.get("max_hits", 4):
                                dead_entities.append(obj)
                                for _ in range(random.randint(2, 3)):
                                    if hasattr(map_obj, 'ground_items'):
                                        map_obj.ground_items.append(
                                            RPGGroundItem(obj["hitbox"].centerx + random.randint(-20, 20),
                                                          obj["hitbox"].bottom + random.randint(-8, 16),
                                                          "Wood Log", 1, "wood_log.png",
                                                          map_obj.base_dir, "Dense timber harvested from forest trees. Rich in natural cellulose; crafts into wood planks.")
                                        )
                                sound_mgr.play('anvil_clang')
                                if game:
                                    game.prompt_text = "Tree felled! Timber collected."
                                    game.prompt_timer = 2.5
                                
                for de in dead_entities:
                    if hasattr(map_obj, 'remove_object'):
                        map_obj.remove_object(de)
                    sound_mgr.play('alert')
            return # Don't allow movement while attacking
            
        if (mouse_pressed[0] or touch_atk) and not self.is_jumping and not getattr(self, 'disable_attack', False): # Left Mouse Button or Touch Attack
            self.is_attacking = True
            self.has_dealt_damage = False
            self.action = "Slash"
            self.frame_index = 0
            self.anim_timer = 0
            sound_mgr.play('slash')
            return
            
        dx, dy = 0, 0
        is_moving = False

        if abs(joy_x) > 0.15 or abs(joy_y) > 0.15:
            dx += joy_x * self.speed * dt
            dy += joy_y * self.speed * dt
            is_moving = True
            if abs(joy_x) > abs(joy_y):
                self.facing = "Right" if joy_x > 0 else "Left"
            else:
                self.facing = "Down" if joy_y > 0 else "Up"
        else:
            if keys[pygame.K_w]:
                dy -= self.speed * dt
                self.facing = "Up"
                is_moving = True
            elif keys[pygame.K_s]:
                dy += self.speed * dt
                self.facing = "Down"
                is_moving = True
                
            if keys[pygame.K_a]:
                dx -= self.speed * dt
                self.facing = "Left"
                is_moving = True
            elif keys[pygame.K_d]:
                dx += self.speed * dt
                self.facing = "Right"
                is_moving = True
                
        self.door_interaction = False
        
        if is_moving:
            new_rect = self.rect.copy()
            new_rect.x += dx
            new_rect.y += dy
            
            # No world boundary clamp — world is infinite in all directions!
            
            # Precise collision detection against map objects using feet hitbox
            collision = False
            player_hitbox = pygame.Rect(new_rect.x + 16, new_rect.bottom - 20, 32, 20)
            
            # Check door interaction specifically for houses (W key or joystick up)
            for obj in map_obj.objects:
                if obj["type"] == "house":
                    door_hitbox = pygame.Rect(obj["rect"].x + 50, obj["rect"].bottom - 50, 60, 50)
                    if player_hitbox.colliderect(door_hitbox) and (keys[pygame.K_w] or joy_y < -0.3):
                        self.door_interaction = True
                        sound_mgr.play_door_open()
                        sound_mgr.play('alert')
                        
                # Use pre-calculated physics hitboxes (only solid terrain, NOT bears)
                if obj["type"] in ["house", "tree", "bush"] and "hitbox" in obj and player_hitbox.colliderect(obj["hitbox"]):
                    collision = True
                    break
                    
            if not collision:
                self.rect = new_rect

            # Play surface footstep sound every 0.32s while walking
            self.footstep_timer += dt
            if self.footstep_timer >= 0.32:
                self.footstep_timer = 0.0
                terrain = self.get_terrain_at(map_obj)
                sound_mgr.play_footstep(terrain)
        else:
            self.footstep_timer = 0.30
        
        if not self.is_jumping and keys[pygame.K_SPACE]:
            self.is_jumping = True
            self.z_vel = 250.0
            self.action = "Jump"
            self.frame_index = 0
            self.anim_timer = 0
            terrain = self.get_terrain_at(map_obj)
            sound_mgr.play_jump(terrain)
            
        if self.is_jumping:
            self.z += self.z_vel * dt
            self.z_vel -= 800.0 * dt
            if self.z <= 0:
                self.z = 0
                self.z_vel = 0
                self.is_jumping = False
                terrain = self.get_terrain_at(map_obj)
                sound_mgr.play_land(terrain)
                
        if not self.is_jumping:
            if is_moving:
                self.action = "Walk"
                self.anim_timer += dt
                if self.anim_timer > 0.1:
                    self.anim_timer = 0
                    self.frame_index += 1
            else:
                self.action = "Stand"
        else:
            self.anim_timer += dt
            if self.anim_timer > 0.15:
                self.anim_timer = 0
                self.frame_index += 1
            
    def draw(self, surface, camera):
        display_action = self.action
        if self.action == "Stand":
            display_action = "Jump"
            
        anim_key = f"{self.facing}_{display_action}"
        frames = self.animations.get(anim_key, [])
        if frames:
            idx = int(self.frame_index)
            if self.action == "Stand":
                idx = 0
            elif self.action in ["Slash", "Death", "Jump"]:
                # Clamp at last frame for attacks, death, and jumps
                if idx >= len(frames):
                    idx = len(frames) - 1
            else:
                # Loop continuously for Walk
                idx = idx % len(frames)
                
            img = frames[idx]
            
            draw_rect = camera.apply_rect(self.rect)
            
            # Always draw an 8-bit chunky shadow to ground the character
            shadow = pygame.Surface((32, 12), pygame.SRCALPHA)
            pygame.draw.rect(shadow, (0, 0, 0, 100), (4, 0, 24, 12))
            pygame.draw.rect(shadow, (0, 0, 0, 100), (0, 4, 32, 4))
            shadow_rect = shadow.get_rect(center=(draw_rect.centerx, draw_rect.bottom - 8))
            surface.blit(shadow, shadow_rect)
                
            # Center the image perfectly over the collision box and apply Z offset
            img_rect = img.get_rect(midbottom=draw_rect.midbottom)
            img_rect.y -= int(self.z)
            surface.blit(img, img_rect)
            
            # Draw overhead healthbar above player
            hp_w = 40
            hp_h = 5
            hp_x = draw_rect.centerx - hp_w // 2
            hp_y = img_rect.top - 8
            
            # Dark outer frame & drop shadow
            pygame.draw.rect(surface, (10, 8, 12), (hp_x - 1, hp_y - 1, hp_w + 2, hp_h + 2), border_radius=2)
            pygame.draw.rect(surface, (50, 20, 20), (hp_x, hp_y, hp_w, hp_h), border_radius=1)
            
            hp_pct = max(0.0, min(1.0, self.hp / float(self.max_hp)))
            fill_w = int(hp_w * hp_pct)
            if fill_w > 0:
                hp_col = (50, 220, 90) if hp_pct > 0.5 else ((240, 190, 40) if hp_pct > 0.25 else (230, 50, 50))
                pygame.draw.rect(surface, hp_col, (hp_x, hp_y, fill_w, hp_h), border_radius=1)
                # Gloss highlight
                pygame.draw.line(surface, (255, 255, 255), (hp_x, hp_y), (hp_x + fill_w - 1, hp_y))

class RPGBear:
    _cached_anims = None
    _cached_anims_trans = None
    _cached_shadow = None

    def __init__(self, x, y, base_dir):
        self.rect = pygame.Rect(x, y, 48, 48)
        self.hitbox = pygame.Rect(x + 8, y + 24, 32, 24)
        self.speed = 80.0
        self.hp = 2
        self.max_hp = 2
        
        self.facing = random.choice(["Down", "Up", "Left", "Right"])
        self.action = "idle" # idle, walk, attack, hurt
        self.frame_index = 0
        self.anim_timer = 0.0
        self.wander_timer = random.uniform(1.0, 3.0)
        self.hurt_timer = 0.0
        self.attack_cooldown = 0.0
        
        # Load and cache animations ONCE across all bear instances
        if RPGBear._cached_anims is None:
            RPGBear._cached_anims = {}
            bear_dir = os.path.join(base_dir, "3D_Assets", "AttackingAnimal", "Bear")
            
            # ASSET DIRECTION CORRECTION (Asset pack is completely scrambled):
            # _down_ file = Bear faces DOWN (Correct)
            # _right_ file = Bear faces UP (Back of head)
            # _up_ file = Bear faces LEFT (Snout on left)
            # _left_ file = Bear faces RIGHT (Snout on right)
            dir_file_map = {
                "Down": "down",
                "Up": "right",
                "Left": "up",
                "Right": "left"
            }
            
            actions = ["idle", "walk", "attack", "hurt"]
            for act in actions:
                folder_name = f"normal_{act}"
                folder_path = os.path.join(bear_dir, folder_name)
                for facing, file_tag in dir_file_map.items():
                    frames = []
                    if os.path.exists(folder_path):
                        for i in range(1, 5):
                            fname = f"{folder_name}_{file_tag}_{i}.png"
                            fpath = os.path.join(folder_path, fname)
                            if os.path.exists(fpath):
                                img = pygame.image.load(fpath).convert_alpha()
                                img = pygame.transform.scale(img, (48, 48))
                                frames.append(img)
                    RPGBear._cached_anims[f"{facing}_{act}"] = frames

            # Pre-render semi-transparent versions for depth occlusion behind trees/houses
            RPGBear._cached_anims_trans = {}
            for k, v in RPGBear._cached_anims.items():
                trans_frames = []
                for frame in v:
                    tf = frame.copy()
                    tf.fill((255, 255, 255, 140), special_flags=pygame.BLEND_RGBA_MULT)
                    trans_frames.append(tf)
                RPGBear._cached_anims_trans[k] = trans_frames

            # Create 8-bit chunky shadow for bear
            sw, sh = 36, 14
            shadow_surf = pygame.Surface((sw, sh), pygame.SRCALPHA)
            pygame.draw.rect(shadow_surf, (0, 0, 0, 100), (4, 0, sw - 8, sh))
            pygame.draw.rect(shadow_surf, (0, 0, 0, 100), (0, 4, sw, sh - 8))
            RPGBear._cached_shadow = shadow_surf

        self.animations = RPGBear._cached_anims
        self.animations_trans = RPGBear._cached_anims_trans
        self.shadow = RPGBear._cached_shadow
        
    def take_damage(self, amount, knockback_dir, map_obj=None):
        self.hp -= amount
        self.action = "hurt"
        self.hurt_timer = 0.4
        self.frame_index = 0
        
        step_x, step_y = 0, 0
        if knockback_dir == "Up": step_y = -1
        elif knockback_dir == "Down": step_y = 1
        elif knockback_dir == "Left": step_x = -1
        elif knockback_dir == "Right": step_x = 1

        solids = getattr(map_obj, 'solid_objects', []) if map_obj else []
        for _ in range(30):
            test_rect = self.rect.copy()
            test_rect.x += step_x
            test_rect.y += step_y
            test_hitbox = pygame.Rect(test_rect.x + 8, test_rect.bottom - 16, 32, 16)
            
            collision = False
            for obj in solids:
                if "hitbox" in obj and test_hitbox.colliderect(obj["hitbox"]):
                    collision = True
                    break
            if not collision:
                self.rect = test_rect
                self.hitbox = test_hitbox
            else:
                break

    def update(self, dt, player, map_obj):
        self.anim_timer += dt
        if self.anim_timer > 0.12:
            self.anim_timer = 0
            self.frame_index += 1
            
        if self.hurt_timer > 0:
            self.hurt_timer -= dt
            if self.hurt_timer <= 0:
                self.action = "idle"
            return
            
        if self.attack_cooldown > 0:
            self.attack_cooldown -= dt

        # Attack animation completion
        if self.action == "attack":
            frames = self.animations.get(f"{self.facing}_attack", [])
            if frames and self.frame_index >= len(frames):
                self.action = "idle"
                self.frame_index = 0

        # Target acquisition: Check both player and nearby NPCs!
        all_objs = getattr(map_obj, 'objects', [])
        nearby_npcs = [o["npc_obj"] for o in all_objs if o.get("type") == "npc" and hasattr(o.get("npc_obj"), "rect")]
        
        target_entity = None
        target_dist = 999999
        
        # Check player
        p_dx = player.rect.centerx - self.rect.centerx
        p_dy = player.rect.centery - self.rect.centery
        p_dist = (p_dx*p_dx + p_dy*p_dy)**0.5
        if p_dist < 220:
            target_entity = ("player", player, p_dx, p_dy, p_dist)
            target_dist = p_dist
            
        # Check nearby NPCs (targets NPC if closer than player or player is out of range)
        for npc in nearby_npcs:
            n_dx = npc.rect.centerx - self.rect.centerx
            n_dy = npc.rect.centery - self.rect.centery
            n_dist = (n_dx*n_dx + n_dy*n_dy)**0.5
            if n_dist < 250 and (n_dist < target_dist or target_entity is None):
                target_entity = ("npc", npc, n_dx, n_dy, n_dist)
                target_dist = n_dist

        solids = getattr(map_obj, 'solid_objects', [])

        if target_entity and target_dist > 1 and self.action != "attack":
            self.is_chasing = True
            e_type, entity, t_dx, t_dy, t_dist = target_entity
            self.action = "walk"
            if abs(t_dx) > abs(t_dy):
                self.facing = "Right" if t_dx > 0 else "Left"
            else:
                self.facing = "Down" if t_dy > 0 else "Up"
                
            move_x = (t_dx / t_dist) * self.speed * dt
            move_y = (t_dy / t_dist) * self.speed * dt
            
            new_rect = self.rect.copy()
            new_rect.x += move_x
            new_rect.y += move_y
            
            new_hitbox = pygame.Rect(new_rect.x + 8, new_rect.bottom - 16, 32, 16)
            collision = False
            for obj in solids:
                if "hitbox" in obj and new_hitbox.colliderect(obj["hitbox"]):
                    collision = True
                    break
            if not collision:
                self.rect = new_rect
                self.hitbox = new_hitbox
                
            if t_dist < 45 and self.attack_cooldown <= 0:
                self.action = "attack"
                self.frame_index = 0
                self.attack_cooldown = 1.5
                if e_type == "npc":
                    entity.set_emote("Surprised")
        else:
            if getattr(self, 'is_chasing', False):
                self.is_chasing = False
                self.action = "idle"
                self.frame_index = 0
                self.wander_timer = random.uniform(1.5, 4.0)

            self.wander_timer -= dt
            if self.wander_timer <= 0:
                self.wander_timer = random.uniform(2.0, 5.0)
                self.action = random.choice(["idle", "idle", "walk"])
                self.facing = random.choice(["Down", "Up", "Left", "Right"])
                
            if self.action == "walk":
                move_x, move_y = 0, 0
                if self.facing == "Up": move_y = -self.speed * 0.5 * dt
                elif self.facing == "Down": move_y = self.speed * 0.5 * dt
                elif self.facing == "Left": move_x = -self.speed * 0.5 * dt
                elif self.facing == "Right": move_x = self.speed * 0.5 * dt
                
                new_rect = self.rect.copy()
                new_rect.x += move_x
                new_rect.y += move_y
                
                new_hitbox = pygame.Rect(new_rect.x + 8, new_rect.bottom - 16, 32, 16)
                collision = False
                for obj in solids:
                    if "hitbox" in obj and new_hitbox.colliderect(obj["hitbox"]):
                        collision = True
                        break
                if not collision:
                    self.rect = new_rect
                    self.hitbox = new_hitbox
                else:
                    self.action = "idle"

    def draw(self, surface, camera, is_transparent=False):
        screen_rect = camera.apply_rect(self.rect)
        shadow_rect = self.shadow.get_rect(center=(screen_rect.centerx, screen_rect.bottom - 4))
        surface.blit(self.shadow, shadow_rect)
        
        anim_key = f"{self.facing}_{self.action}"
        anim_dict = self.animations_trans if is_transparent else self.animations
        frames = anim_dict.get(anim_key, [])
        if not frames:
            anim_key = f"{self.facing}_idle"
            frames = anim_dict.get(anim_key, [])
            
        if frames:
            idx = int(self.frame_index) % len(frames)
            img = frames[idx]
            surface.blit(img, screen_rect)

class RPGGroundItem:
    _cached_item_sprites = {}

    def __init__(self, x, y, item_name, qty, img_file, base_dir, desc="", heal=0):
        self.x = float(x)
        self.y = float(y)
        self.item_name = item_name
        self.qty = qty
        self.img_file = img_file
        self.base_dir = base_dir
        self.desc = desc
        self.heal = heal
        self.bob_timer = random.uniform(0.0, math.pi * 2)
        self.lifetime = 240.0 # 4 minutes persistence
        self.pickup_cooldown = 0.25 # Brief moment before pickup can be triggered

        if img_file not in RPGGroundItem._cached_item_sprites:
            p = os.path.join(base_dir, "3D_Assets", "ScienceRPG", img_file)
            if getattr(sys, 'frozen', False):
                meipass = getattr(sys, '_MEIPASS', base_dir)
                p2 = os.path.join(meipass, "3D_Assets", "ScienceRPG", img_file)
                if os.path.exists(p2): p = p2
            if os.path.exists(p):
                try:
                    img = pygame.image.load(p).convert_alpha()
                    img = pygame.transform.scale(img, (28, 28))
                    RPGGroundItem._cached_item_sprites[img_file] = img
                except Exception:
                    RPGGroundItem._cached_item_sprites[img_file] = None
            else:
                RPGGroundItem._cached_item_sprites[img_file] = None

        self.sprite = RPGGroundItem._cached_item_sprites.get(img_file)
        if self.sprite is None:
            self.sprite = pygame.Surface((28, 28), pygame.SRCALPHA)
            pygame.draw.circle(self.sprite, (220, 180, 50), (14, 14), 12)
            pygame.draw.circle(self.sprite, (255, 255, 255), (14, 14), 12, 1)

        self.rect = pygame.Rect(int(self.x) - 14, int(self.y) - 14, 28, 28)

    def update(self, dt, player=None):
        self.bob_timer += dt
        self.lifetime -= dt
        if self.pickup_cooldown > 0:
            self.pickup_cooldown -= dt

        if player and hasattr(player, 'rect') and self.pickup_cooldown <= 0:
            px, py = player.rect.centerx, player.rect.centery
            dx = px - self.x
            dy = py - self.y
            dist = math.hypot(dx, dy)
            if dist < 110.0 and dist > 1.0:
                spd = 260.0
                self.x += (dx / dist) * spd * dt
                self.y += (dy / dist) * spd * dt
                self.rect.center = (int(self.x), int(self.y))
                if dist < 34.0:
                    return True # Collected!
        return False

    def draw(self, surface, camera):
        screen_pos = camera.apply_point((int(self.x), int(self.y)))
        # Subtle ground shadow
        shadow_rect = pygame.Rect(screen_pos[0] - 10, screen_pos[1] + 6, 20, 7)
        sh_surf = pygame.Surface((20, 7), pygame.SRCALPHA)
        pygame.draw.ellipse(sh_surf, (0, 0, 0, 95), (0, 0, 20, 7))
        surface.blit(sh_surf, shadow_rect.topleft)

        # Floating item icon with gentle sinusoidal bob
        bob_y = int(math.sin(self.bob_timer * 4.5) * 4.0)
        draw_rect = self.sprite.get_rect(center=(screen_pos[0], screen_pos[1] - 4 + bob_y))
        surface.blit(self.sprite, draw_rect)

        # Quantity badge if qty > 1
        if self.qty > 1:
            font = get_rpg_font(10, bold=True)
            txt = font.render(str(self.qty), True, (255, 255, 240))
            shd = font.render(str(self.qty), True, (10, 10, 10))
            bx = draw_rect.right - 6
            by = draw_rect.bottom - 8
            surface.blit(shd, (bx + 1, by + 1))
            surface.blit(txt, (bx, by))

class RPGMineableObject:
    _cached_sprites = {}

    def __init__(self, x, y, obj_type, base_dir):
        self.x = x
        self.y = y
        self.obj_type = obj_type
        self.base_dir = base_dir

        # Exact specification:
        # small rock: 2 hits, drops 1 to 3 rock
        # medium rock: 4 hits, drops 3 to 6 rock
        # big rock: 6 hits, drops 7 to 10 rocks
        # coal/iron/ruby/diamond ores: 4 hits, drops 1 to 2
        if obj_type == "small_rock":
            self.max_hp = 2
            self.draw_size = (30, 30)
            self.drop_type = "Rock"
            self.drop_range = (1, 3)
            self.drop_img = "rock_item.png"
            self.desc = "Chunky geological stone broken from field boulders. Essential material for crafting and masonry."
            self.sprite_file = "small_rock.png"
        elif obj_type == "medium_rock":
            self.max_hp = 4
            self.draw_size = (44, 44)
            self.drop_type = "Rock"
            self.drop_range = (3, 6)
            self.drop_img = "rock_item.png"
            self.desc = "Chunky geological stone broken from field boulders. Essential material for crafting and masonry."
            self.sprite_file = "medium_rock.png"
        elif obj_type == "big_rock":
            self.max_hp = 6
            self.draw_size = (56, 56)
            self.drop_type = "Rock"
            self.drop_range = (7, 10)
            self.drop_img = "rock_item.png"
            self.desc = "Chunky geological stone broken from field boulders. Essential material for crafting and masonry."
            self.sprite_file = "big_rock.png"
        elif obj_type == "coal_ore":
            self.max_hp = 4
            self.draw_size = (44, 44)
            self.drop_type = "Coal Lump"
            self.drop_range = (1, 2)
            self.drop_img = "coal_lump.png"
            self.desc = "Carbon-rich mineral ore. High calorific fuel used for smelting ingots and torches."
            self.sprite_file = "coal_ore.png"
        elif obj_type == "iron_ore":
            self.max_hp = 4
            self.draw_size = (44, 44)
            self.drop_type = "Iron Ore"
            self.drop_range = (1, 2)
            self.drop_img = "iron_ore.png"
            self.desc = "Raw unrefined iron ore (hematite). Take to the village Blacksmith to smelt into an Iron Ingot!"
            self.sprite_file = "iron_ore.png"
        elif obj_type == "ruby_ore":
            self.max_hp = 4
            self.draw_size = (44, 44)
            self.drop_type = "Ruby Ore"
            self.drop_range = (1, 2)
            self.drop_img = "ruby_gem.png"
            self.desc = "Raw unrefined ruby crystal ore. Take to the village Blacksmith to smelt into a precious Ruby Gem!"
            self.sprite_file = "ruby_ore.png"
        elif obj_type == "diamond_ore":
            self.max_hp = 4
            self.draw_size = (44, 44)
            self.drop_type = "Diamond Ore"
            self.drop_range = (1, 2)
            self.drop_img = "diamond_gem.png"
            self.desc = "Raw unrefined diamond mineral. Take to the village Blacksmith to smelt into an exquisite Diamond Gem!"
            self.sprite_file = "diamond_ore.png"
        else:
            self.max_hp = 3
            self.draw_size = (34, 34)
            self.drop_type = "Rock"
            self.drop_range = (1, 2)
            self.drop_img = "rock_item.png"
            self.desc = "Rock fragment."
            self.sprite_file = "small_rock.png"

        self.hp = self.max_hp
        self.rect = pygame.Rect(x, y, self.draw_size[0], self.draw_size[1])
        self.hitbox = pygame.Rect(x + 4, y + self.draw_size[1] // 2, self.draw_size[0] - 8, self.draw_size[1] // 2)
        self.shake_timer = 0.0
        self.flash_timer = 0.0

        if self.sprite_file not in RPGMineableObject._cached_sprites:
            p = os.path.join(base_dir, "3D_Assets", "ScienceRPG", self.sprite_file)
            if getattr(sys, 'frozen', False):
                meipass = getattr(sys, '_MEIPASS', base_dir)
                p2 = os.path.join(meipass, "3D_Assets", "ScienceRPG", self.sprite_file)
                if os.path.exists(p2): p = p2
            if os.path.exists(p):
                try:
                    img = pygame.image.load(p).convert_alpha()
                    img = pygame.transform.scale(img, self.draw_size)
                    RPGMineableObject._cached_sprites[self.sprite_file] = img
                except Exception:
                    RPGMineableObject._cached_sprites[self.sprite_file] = None
            else:
                RPGMineableObject._cached_sprites[self.sprite_file] = None

        self.sprite = RPGMineableObject._cached_sprites.get(self.sprite_file)
        if self.sprite is None:
            self.sprite = pygame.Surface(self.draw_size, pygame.SRCALPHA)
            pygame.draw.circle(self.sprite, (130, 130, 135), (self.draw_size[0]//2, self.draw_size[1]//2), self.draw_size[0]//2 - 2)

    def take_hit(self):
        self.hp -= 1
        self.shake_timer = 0.18
        self.flash_timer = 0.12
        return self.hp <= 0

    def get_drops(self):
        qty = random.randint(self.drop_range[0], self.drop_range[1])
        return [RPGGroundItem(self.rect.centerx + random.randint(-8, 8),
                              self.rect.centery + random.randint(-8, 8),
                              self.drop_type, qty, self.drop_img, self.base_dir, self.desc)]

    def update(self, dt):
        if self.shake_timer > 0:
            self.shake_timer -= dt
        if self.flash_timer > 0:
            self.flash_timer -= dt

    def draw(self, surface, camera):
        screen_rect = camera.apply_rect(self.rect)
        sw = int(self.draw_size[0] * 0.9)
        sh = max(8, int(self.draw_size[1] * 0.28))
        sh_surf = pygame.Surface((sw, sh), pygame.SRCALPHA)
        pygame.draw.ellipse(sh_surf, (0, 0, 0, 85), (0, 0, sw, sh))
        surface.blit(sh_surf, (screen_rect.centerx - sw // 2, screen_rect.bottom - sh // 2))

        ox, oy = 0, 0
        if self.shake_timer > 0:
            ox = random.choice([-2, 2])
            oy = random.choice([-1, 1])

        blit_pos = (screen_rect.x + ox, screen_rect.y + oy)
        if self.flash_timer > 0:
            flash_surf = self.sprite.copy()
            flash_surf.fill((255, 255, 255, 160), special_flags=pygame.BLEND_RGB_ADD)
            surface.blit(flash_surf, blit_pos)
        else:
            surface.blit(self.sprite, blit_pos)

        # Durability indicator bar when damaged
        if self.hp < self.max_hp:
            bar_w = 26
            bar_h = 4
            bx = screen_rect.centerx - bar_w // 2
            by = screen_rect.y - 7
            pygame.draw.rect(surface, (20, 15, 10), (bx - 1, by - 1, bar_w + 2, bar_h + 2), border_radius=2)
            fill_w = max(1, int(bar_w * (self.hp / self.max_hp)))
            col = (230, 80, 50) if self.hp == 1 else (230, 190, 40)
            pygame.draw.rect(surface, col, (bx, by, fill_w, bar_h), border_radius=1)

class RPGVillageAnimal:
    _cached_animal_frames = {}

    def __init__(self, x, y, animal_type, base_dir, home_village=(0, 0)):
        self.animal_type = animal_type # "chicken", "cow", "pig", "sheep"
        self.home_village = home_village
        self.rect = pygame.Rect(x, y, 48 if animal_type == "cow" else 32, 48 if animal_type == "cow" else 32)
        self.hitbox = pygame.Rect(x + 4, y + (16 if animal_type == "cow" else 8), self.rect.width - 8, self.rect.height - (20 if animal_type == "cow" else 12))
        self.speed = 25.0
        self.hp = 1
        self.hurt_timer = 0.0
        self.facing = random.choice(["Left", "Right"])
        self.action = "idle"
        self.anim_timer = 0.0
        self.frame_index = 0
        self.wander_timer = random.uniform(2.0, 5.0)

        # Load & cache frames
        if animal_type not in RPGVillageAnimal._cached_animal_frames:
            anim_dir = os.path.join(base_dir, "3D_Assets", "Fantasy Chronicles", "sprites", "Farming", "Animals", animal_type)
            frames = []
            if os.path.exists(anim_dir):
                files = sorted([f for f in os.listdir(anim_dir) if f.endswith('.png')])
                for f in files:
                    try:
                        img = pygame.image.load(os.path.join(anim_dir, f)).convert_alpha()
                        if animal_type == "cow":
                            img = pygame.transform.scale(img, (48, 48))
                        else:
                            img = pygame.transform.scale(img, (32, 32))
                        frames.append(img)
                    except Exception:
                        pass
            RPGVillageAnimal._cached_animal_frames[animal_type] = frames
        self.frames = RPGVillageAnimal._cached_animal_frames[animal_type]

        # Shadow
        sw, sh = (36, 12) if animal_type == "cow" else (24, 8)
        self.shadow = pygame.Surface((sw, sh), pygame.SRCALPHA)
        pygame.draw.ellipse(self.shadow, (0, 0, 0, 80), (0, 0, sw, sh))

    def take_damage(self, amount, knockback_dir, map_obj, sound_mgr):
        self.hp -= amount
        self.hurt_timer = 0.3
        if self.hp <= 0:
            if hasattr(map_obj, 'on_animal_killed'):
                map_obj.on_animal_killed(self.home_village, self.rect.center, sound_mgr)

    def update(self, dt, map_obj):
        self.anim_timer += dt
        if self.anim_timer > 0.18:
            self.anim_timer = 0.0
            self.frame_index += 1

        if self.hurt_timer > 0:
            self.hurt_timer -= dt

        self.wander_timer -= dt
        if self.wander_timer <= 0:
            self.wander_timer = random.uniform(2.0, 6.0)
            self.action = random.choice(["idle", "idle", "walk"])
            self.facing = random.choice(["Left", "Right", "Up", "Down"])

        if self.action == "walk":
            move_x, move_y = 0, 0
            if self.facing == "Left": move_x = -self.speed * dt
            elif self.facing == "Right": move_x = self.speed * dt
            elif self.facing == "Up": move_y = -self.speed * dt
            elif self.facing == "Down": move_y = self.speed * dt

            new_rect = self.rect.copy()
            new_rect.x += move_x
            new_rect.y += move_y

            new_hitbox = pygame.Rect(new_rect.x + 4, new_rect.y + (16 if self.animal_type == "cow" else 8), self.rect.width - 8, self.rect.height - (20 if self.animal_type == "cow" else 12))
            collision = False
            solids = map_obj.solid_objects if hasattr(map_obj, 'solid_objects') else []
            for obj in solids:
                if "hitbox" in obj and new_hitbox.colliderect(obj["hitbox"]):
                    collision = True
                    break
            if not collision:
                self.rect = new_rect
                self.hitbox = new_hitbox
            else:
                self.action = "idle"

    def draw(self, surface, camera, is_transparent=False):
        screen_rect = camera.apply_rect(self.rect)
        shadow_rect = self.shadow.get_rect(center=(screen_rect.centerx, screen_rect.bottom - 2))
        surface.blit(self.shadow, shadow_rect)

        if self.frames:
            idx = (self.frame_index if self.action == "walk" else 0) % len(self.frames)
            img = self.frames[idx]
            if self.facing == "Right":
                img = pygame.transform.flip(img, True, False)
            surface.blit(img, screen_rect)

class RPGNPC:
    _cached_skin_anims = {}
    _cached_emotes = None

    def __init__(self, x, y, base_dir, skin_name="NPC_1", name="Village Resident", dialogues=None, default_emote="Happy", home_village=(0, 0)):
        self.skin_name = skin_name
        self.name = name
        self.home_pos = (x, y)
        self.home_village = home_village
        self.rect = pygame.Rect(x, y, 36, 48)
        self.hitbox = pygame.Rect(x + 6, y + 32, 24, 16)
        self.speed = 35.0
        self.facing = random.choice(["Down", "Up", "Left", "Right"])
        self.action = "idle" # ONLY "idle" or "walk" per user directive!
        self.anim_timer = 0.0
        self.frame_index = 0
        self.wander_timer = random.uniform(2.0, 5.0)

        # Dialogue lines & Emote state
        self.dialogues = dialogues or [
            ("Happy", "Welcome to our village, traveler! The air is fresh today."),
            ("Surprised", "Beware of the ancient dungeon portal in the woods!"),
            ("Star", "If you need rest, feel free to visit the houses nearby.")
        ]
        self.dialogue_index = 0
        self.current_emote = default_emote
        self.emote_timer = 0.0
        self.emote_frame = 0
        self.is_talking = False  # Only True while player is in active dialogue with this NPC or when shouting

        # Rage & Anger State
        self.rage_state = "normal"  # "normal", "scolding", "raging", "tired", "returning"
        self.rage_timer = 0.0
        self.tired_timer = 0.0
        self.shout_text = ""
        self.shout_timer = 0.0
        self.attack_cooldown = 0.0

        # Load & cache animations for this specific skin
        if skin_name not in RPGNPC._cached_skin_anims:
            RPGNPC._cached_skin_anims[skin_name] = self._load_skin_animations(base_dir, skin_name)
        self.animations = RPGNPC._cached_skin_anims[skin_name]

        # Load & cache animated emotes
        if RPGNPC._cached_emotes is None:
            RPGNPC._cached_emotes = self._load_emotes(base_dir)

        # Build 8-bit chunky grounded shadow
        sw, sh = 28, 10
        self.shadow = pygame.Surface((sw, sh), pygame.SRCALPHA)
        pygame.draw.rect(self.shadow, (0, 0, 0, 90), (3, 0, sw - 6, sh))
        pygame.draw.rect(self.shadow, (0, 0, 0, 90), (0, 3, sw, sh - 6))

    def _load_skin_animations(self, base_dir, skin_name):
        anims = {}
        npc_path = os.path.join(base_dir, "3D_Assets", "NPC", skin_name)
        directions = ["up", "down", "left", "right"]
        anim_types = ["idle", "walk"] # ONLY idle and walk animations!

        for anim in anim_types:
            folder = os.path.join(npc_path, anim)
            if os.path.exists(folder):
                for d in directions:
                    frames = []
                    for i in range(1, 5):
                        filename = f"{anim}_{d}_{i}.png"
                        p = os.path.join(folder, filename)
                        if os.path.exists(p):
                            try:
                                img = pygame.image.load(p).convert_alpha()
                                img = pygame.transform.scale(img, (36, 48))
                                frames.append(img)
                            except Exception:
                                pass
                    key = f"{d.capitalize()}_{anim}" # e.g. "Down_idle", "Up_walk"
                    anims[key] = frames
        return anims

    def _load_emotes(self, base_dir):
        emotes = {}
        emotes_path = os.path.join(base_dir, "3D_Assets", "Emotes")
        if os.path.exists(emotes_path):
            for emote_folder in os.listdir(emotes_path):
                folder_p = os.path.join(emotes_path, emote_folder)
                if os.path.isdir(folder_p):
                    frames = []
                    for f in sorted(os.listdir(folder_p)):
                        if f.endswith(".png"):
                            try:
                                img = pygame.image.load(os.path.join(folder_p, f)).convert_alpha()
                                img = pygame.transform.scale(img, (18, 18))
                                frames.append(img)
                            except Exception:
                                pass
                    if frames:
                        emotes[emote_folder] = frames
        return emotes

    def set_emote(self, emote_name):
        if RPGNPC._cached_emotes and emote_name in RPGNPC._cached_emotes:
            self.current_emote = emote_name
            self.emote_frame = 0

    def get_current_dialogue(self):
        if self.rage_state == "raging":
            return "Evil", "YOU HURT OUR ANIMALS! PREPARE TO FACE MY WRATH!"
        elif self.rage_state == "scolding":
            return "Angry", "Why did you harm our poor animal?! Leave our livestock alone, monster!"
        elif self.rage_state == "tired":
            return "Surprised", "Huff... puff... don't you dare harm any more of our village animals!"
        
        emote, text = self.dialogues[self.dialogue_index]
        self.dialogue_index = (self.dialogue_index + 1) % len(self.dialogues)
        self.set_emote(emote)
        return emote, text

    def update(self, dt, map_obj, player=None):
        self.anim_timer += dt
        if self.anim_timer > 0.15:
            self.anim_timer = 0
            self.frame_index += 1

        # Emote bubble animation timer
        self.emote_timer += dt
        if self.emote_timer > 0.15:
            self.emote_timer = 0
            self.emote_frame += 1

        if self.shout_timer > 0:
            self.shout_timer -= dt
            if self.shout_timer <= 0:
                self.shout_text = ""

        if self.attack_cooldown > 0:
            self.attack_cooldown -= dt

        # --- RAGING BEHAVIOR (Sprint & catch the player!) ---
        if self.rage_state == "raging":
            self.is_talking = True
            self.rage_timer -= dt
            
            if player:
                p_dx = player.rect.centerx - self.rect.centerx
                p_dy = player.rect.centery - self.rect.centery
                p_dist = (p_dx*p_dx + p_dy*p_dy)**0.5
                
                # Check 100-block (4800px) radius from village center!
                chunk_px = getattr(map_obj, 'chunk_px', 768)
                vx = self.home_village[0] * chunk_px + chunk_px / 2
                vy = self.home_village[1] * chunk_px + chunk_px / 2
                dist_from_village = ((self.rect.centerx - vx)**2 + (self.rect.centery - vy)**2)**0.5
                
                if dist_from_village > 4800 or self.rage_timer <= 0:
                    self.rage_state = "tired"
                    self.tired_timer = 4.5
                    self.set_emote("Surprised")
                    self.shout_text = "Huff... puff... you got lucky! Don't you EVER step foot in our village again!"
                    self.shout_timer = 4.5
                    self.speed = 35.0
                    self.action = "idle"
                    return
                else:
                    self.action = "walk"
                    self.speed = 125.0
                    if abs(p_dx) > abs(p_dy):
                        self.facing = "Right" if p_dx > 0 else "Left"
                    else:
                        self.facing = "Down" if p_dy > 0 else "Up"
                    
                    move_x = (p_dx / max(1.0, p_dist)) * self.speed * dt
                    move_y = (p_dy / max(1.0, p_dist)) * self.speed * dt
                    
                    new_rect = self.rect.copy()
                    new_rect.x += move_x
                    new_rect.y += move_y
                    new_hitbox = pygame.Rect(new_rect.x + 6, new_rect.bottom - 16, 24, 16)
                    collision = False
                    solids = map_obj.solid_objects if hasattr(map_obj, 'solid_objects') else []
                    for obj in solids:
                        if "hitbox" in obj and new_hitbox.colliderect(obj["hitbox"]):
                            collision = True
                            break
                    if not collision:
                        self.rect = new_rect
                        self.hitbox = new_hitbox

                    # Catch player
                    if p_dist < 40 and self.attack_cooldown <= 0:
                        self.attack_cooldown = 2.0
                        self.shout_text = "Take that! Leave our animals alone!"
                        self.shout_timer = 2.5
                        if hasattr(player, 'rect'):
                            player.rect.x += int((p_dx / max(1.0, p_dist)) * 25)
                            player.rect.y += int((p_dy / max(1.0, p_dist)) * 25)
            return

        # --- TIRED BEHAVIOR (Resting after chase) ---
        elif self.rage_state == "tired":
            self.action = "idle"
            self.tired_timer -= dt
            if self.tired_timer <= 0:
                self.rage_state = "returning"
                self.set_emote("Happy")
                self.is_talking = False
            return

        # --- RETURNING BEHAVIOR (Walking back to village) ---
        elif self.rage_state == "returning":
            h_dx = self.home_pos[0] - self.rect.x
            h_dy = self.home_pos[1] - self.rect.y
            h_dist = (h_dx*h_dx + h_dy*h_dy)**0.5
            if h_dist < 15:
                self.rect.x, self.rect.y = self.home_pos
                self.rage_state = "normal"
                self.action = "idle"
                self.is_talking = False
            else:
                self.action = "walk"
                self.speed = 40.0
                if abs(h_dx) > abs(h_dy):
                    self.facing = "Right" if h_dx > 0 else "Left"
                else:
                    self.facing = "Down" if h_dy > 0 else "Up"
                move_x = (h_dx / max(1.0, h_dist)) * self.speed * dt
                move_y = (h_dy / max(1.0, h_dist)) * self.speed * dt
                self.rect.x += move_x
                self.rect.y += move_y
            return

        # --- SCOLDING BEHAVIOR (Angry at player for 1st animal killed) ---
        elif self.rage_state == "scolding":
            if self.shout_timer <= 0:
                self.rage_state = "normal"
                self.set_emote("Happy")
                self.is_talking = False

        # Normal Peaceful / Frightened Update
        # Check for nearby bears in active chunks!
        all_objs = map_obj.objects if hasattr(map_obj, 'objects') else []
        nearby_bears = [o["bear_obj"] for o in all_objs if o.get("type") == "bear" and hasattr(o.get("bear_obj"), "rect")]
        
        closest_bear = None
        min_bear_dist = 999999
        for bear in nearby_bears:
            bdx = bear.rect.centerx - self.rect.centerx
            bdy = bear.rect.centery - self.rect.centery
            bdist = (bdx*bdx + bdy*bdy)**0.5
            if bdist < min_bear_dist:
                min_bear_dist = bdist
                closest_bear = (bear, bdx, bdy, bdist)

        # Frightened behavior if bear is within 250px!
        if closest_bear and closest_bear[3] < 250:
            bear, bdx, bdy, bdist = closest_bear
            self.set_emote("Exclamation")
            
            # Run away fast from bear!
            if abs(bdx) > abs(bdy):
                self.facing = "Left" if bdx > 0 else "Right"
            else:
                self.facing = "Up" if bdy > 0 else "Down"
            
            run_speed = 95.0
            move_x = (-bdx / max(1.0, bdist)) * run_speed * dt
            move_y = (-bdy / max(1.0, bdist)) * run_speed * dt
            self.action = "walk"
        else:
            self.wander_timer -= dt
            if self.wander_timer <= 0:
                self.wander_timer = random.uniform(2.0, 6.0)
                self.action = random.choice(["idle", "idle", "walk"])
                self.facing = random.choice(["Down", "Up", "Left", "Right"])

            move_x, move_y = 0, 0
            if self.action == "walk":
                if self.facing == "Up": move_y = -self.speed * dt
                elif self.facing == "Down": move_y = self.speed * dt
                elif self.facing == "Left": move_x = -self.speed * dt
                elif self.facing == "Right": move_x = self.speed * dt

        if self.action == "walk":
            new_rect = self.rect.copy()
            new_rect.x += move_x
            new_rect.y += move_y

            new_hitbox = pygame.Rect(new_rect.x + 6, new_rect.bottom - 16, 24, 16)
            collision = False
            solids = map_obj.solid_objects if hasattr(map_obj, 'solid_objects') else []
            for obj in solids:
                if "hitbox" in obj and new_hitbox.colliderect(obj["hitbox"]):
                    collision = True
                    break
            if not collision:
                self.rect = new_rect
                self.hitbox = new_hitbox
            else:
                self.action = "idle"

    def draw(self, surface, camera, is_transparent=False):
        screen_rect = camera.apply_rect(self.rect)
        shadow_rect = self.shadow.get_rect(center=(screen_rect.centerx, screen_rect.bottom - 4))
        surface.blit(self.shadow, shadow_rect)

        anim_key = f"{self.facing}_{self.action}"
        frames = self.animations.get(anim_key, [])
        if not frames:
            anim_key = f"{self.facing}_idle"
            frames = self.animations.get(anim_key, [])

        if frames:
            idx = int(self.frame_index) % len(frames)
            img = frames[idx]
            surface.blit(img, screen_rect)

        # Draw Animated Emote Bubble floating above NPC's head — only during active dialogue or anger!
        if self.is_talking and self.current_emote and RPGNPC._cached_emotes and self.current_emote in RPGNPC._cached_emotes:
            e_frames = RPGNPC._cached_emotes[self.current_emote]
            if e_frames:
                e_img = e_frames[self.emote_frame % len(e_frames)]
                bob_offset = math.sin(pygame.time.get_ticks() * 0.006) * 3
                e_rect = e_img.get_rect(center=(screen_rect.centerx, screen_rect.top - 16 + int(bob_offset)))
                
                # Speech bubble background
                bg_rect = e_rect.inflate(8, 6)
                pygame.draw.rect(surface, (20, 20, 28), bg_rect, border_radius=5)
                pygame.draw.rect(surface, (240, 200, 80), bg_rect, width=2, border_radius=5)
                surface.blit(e_img, e_rect)

        # Draw Floating Gold-bordered Speech Bubble if shouting!
        if self.shout_timer > 0 and self.shout_text:
            font_shout = get_rpg_font(11, bold=True)
            txt_surf = font_shout.render(self.shout_text, False, (255, 245, 200))
            bubble_w = txt_surf.get_width() + 16
            bubble_h = txt_surf.get_height() + 10
            bubble_rect = pygame.Rect(screen_rect.centerx - bubble_w // 2, screen_rect.top - 46, bubble_w, bubble_h)
            
            pygame.draw.rect(surface, (15, 15, 22), bubble_rect, border_radius=6)
            b_color = (255, 90, 90) if self.rage_state == "raging" else (255, 215, 80)
            pygame.draw.rect(surface, b_color, bubble_rect, width=2, border_radius=6)
            surface.blit(txt_surf, (bubble_rect.x + 8, bubble_rect.y + 5))

class RPGBlacksmithNPC(RPGNPC):
    _cached_blacksmith_sprite = None

    def __init__(self, x, y, base_dir, home_village=(0, 0)):
        super().__init__(x, y, base_dir, skin_name="NPC_1", name="Master Blacksmith", dialogues=[], default_emote="Happy", home_village=home_village)
        self.stand_pos = (x, y)
        self.house_door_pos = (x, y - 55) # Doorway into village house
        self.state = "IDLE" # "IDLE", "WALKING_IN", "SMELTING", "WALKING_OUT"
        self.smelt_timer = 0.0
        self.smelt_duration = 6.0
        self.gold_fee = 0
        self.target_ore = None
        self.target_ingot = None
        self.target_ingot_img = None
        self.target_ingot_desc = ""
        self.visible = True
        self.is_smelt_dialogue = False
        self.smoke_particles = [] # [(x, y, vx, vy, lifetime)]
        self.anvil_sound_timer = 0.0

        if RPGBlacksmithNPC._cached_blacksmith_sprite is None:
            p = os.path.join(base_dir, "3D_Assets", "ScienceRPG", "blacksmith_npc.png")
            if getattr(sys, 'frozen', False):
                meipass = getattr(sys, '_MEIPASS', base_dir)
                p2 = os.path.join(meipass, "3D_Assets", "ScienceRPG", "blacksmith_npc.png")
                if os.path.exists(p2): p = p2
            if os.path.exists(p):
                try:
                    img = pygame.image.load(p).convert_alpha()
                    RPGBlacksmithNPC._cached_blacksmith_sprite = pygame.transform.scale(img, (48, 48))
                except Exception:
                    pass
        self.blacksmith_sprite = RPGBlacksmithNPC._cached_blacksmith_sprite

    def interact(self, game):
        if self.state == "SMELTING":
            rem = int(math.ceil(self.smelt_timer))
            game.prompt_text = f"Master Blacksmith is currently smelting inside his workshop! ({rem}s remaining)"
            game.prompt_timer = 2.0
            return

        if self.state != "IDLE":
            return

        ore_map = {
            "Diamond Ore": ("Diamond Gem", "diamond_gem.png", "Pure octahedral carbon crystal. The hardest natural mineral on earth; priceless value."),
            "Ruby Ore": ("Ruby Gem", "ruby_gem.png", "Brilliant polished corundum gemstone. Highly prized by kingdom merchants and jewelers."),
            "Iron Ore": ("Iron Ingot", "iron_ingot.png", "Smelted pure metallic iron ingot. High durability metal for forging weapons and sturdy tools."),
            "Raw Bear Meat": ("Cooked Bear Steak", "cooked_steak.png", "Succulent seasoned bear steak flame-seared in the forge furnace. Restores 45 HP!"),
            "Raw Meat": ("Hearty Cooked Steak", "cooked_steak.png", "Tender savory flame-grilled steak. Restores 35 HP!"),
            "Coal Lump": ("Refined Coal", "coal_lump.png", "Purified high-calorific metallurgical carbon fuel.")
        }

        found_ore = None
        # Prioritize diamond > ruby > iron > meat > coal
        for candidate in ["Diamond Ore", "Ruby Ore", "Iron Ore", "Raw Bear Meat", "Raw Meat", "Coal Lump"]:
            for item in game.inventory_ui.items:
                if item["name"] == candidate and item["qty"] > 0:
                    found_ore = candidate
                    break
            if found_ore:
                break

        if not found_ore:
            self.dialogues = [
                ("Interrogation", "Greetings adventurer! Bring me raw Coal, Iron Ore, Ruby, Diamond, or Raw Bear Meat from the wilderness, and I'll smelt and cook them up for ya!")
            ]
            self.dialogue_index = 0
            self.is_smelt_dialogue = False
            game.dialogue_ui.start_dialogue(self, game.sound_mgr)
            return

        fee = random.randint(4, 12)
        ingot_name, ingot_img, ingot_desc = ore_map[found_ore]
        self.gold_fee = fee
        self.target_ore = found_ore
        self.target_ingot = ingot_name
        self.target_ingot_img = ingot_img
        self.target_ingot_desc = ingot_desc
        self.is_smelt_dialogue = True

        # Exact requested dialogues:
        # 1. "Hmm...?"
        # 2. "You shall Owe me ... Gold, then i will make it for ya!"
        self.dialogues = [
            ("Interrogation", "Hmm...?"),
            ("Happy", f"You shall Owe me {fee} Gold, then i will make it for ya!")
        ]
        self.dialogue_index = 0
        game.dialogue_ui.start_dialogue(self, game.sound_mgr)

    def on_smelt_dialogue_finished(self, game):
        if not self.is_smelt_dialogue:
            return
        self.is_smelt_dialogue = False

        gold_item = None
        for it in game.inventory_ui.items:
            if "Gold" in it["name"]:
                gold_item = it
                break

        current_gold = gold_item["qty"] if gold_item else 0
        if current_gold < self.gold_fee:
            game.prompt_text = f"You only have {current_gold} Gold! You need {self.gold_fee} Gold for the Blacksmith."
            game.prompt_timer = 3.5
            game.sound_mgr.play('door_locked')
            return

        gold_item["qty"] -= self.gold_fee
        for it in game.inventory_ui.items:
            if it["name"] == self.target_ore:
                it["qty"] -= 1
                if it["qty"] <= 0:
                    game.inventory_ui.items.remove(it)
                break

        game.sound_mgr.play('gold')
        game.prompt_text = f"Handed over {self.target_ore} and {self.gold_fee} Gold! Blacksmith enters his forge..."
        game.prompt_timer = 3.0
        self.state = "WALKING_IN"

    def update(self, dt, map_obj, player=None, game=None):
        # Update smoke particles
        for p in self.smoke_particles[:]:
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[4] -= dt
            if p[4] <= 0:
                self.smoke_particles.remove(p)

        if self.state == "WALKING_IN":
            dx = self.house_door_pos[0] - self.rect.x
            dy = self.house_door_pos[1] - self.rect.y
            dist = math.hypot(dx, dy)
            if dist < 6.0:
                self.rect.topleft = self.house_door_pos
                self.visible = False
                self.state = "SMELTING"
                self.smelt_timer = self.smelt_duration
                self.anvil_sound_timer = 0.6
                if game and hasattr(game, 'sound_mgr'):
                    game.sound_mgr.play_door_close()
            else:
                self.rect.x += (dx / dist) * 70.0 * dt
                self.rect.y += (dy / dist) * 70.0 * dt

        elif self.state == "SMELTING":
            self.smelt_timer -= dt
            self.anvil_sound_timer -= dt
            if self.anvil_sound_timer <= 0:
                self.anvil_sound_timer = 1.5
                if game and hasattr(game, 'sound_mgr'):
                    game.sound_mgr.play('anvil_clang')
                chimney_x = self.house_door_pos[0] + 45
                chimney_y = self.house_door_pos[1] - 110
                for _ in range(4):
                    self.smoke_particles.append([
                        chimney_x + random.uniform(-6, 6),
                        chimney_y,
                        random.uniform(-12, 12),
                        random.uniform(-35, -20),
                        random.uniform(1.2, 2.0)
                    ])

            if self.smelt_timer <= 0:
                self.state = "WALKING_OUT"
                self.visible = True
                self.rect.topleft = self.house_door_pos
                if game and hasattr(game, 'sound_mgr'):
                    game.sound_mgr.play_door_open()

        elif self.state == "WALKING_OUT":
            dx = self.stand_pos[0] - self.rect.x
            dy = self.stand_pos[1] - self.rect.y
            dist = math.hypot(dx, dy)
            if dist < 6.0:
                self.rect.topleft = self.stand_pos
                self.state = "IDLE"
                if game:
                    game.inventory_ui.add_item(
                        self.target_ingot, 1, self.target_ingot_desc, self.target_ingot_img
                    )
                    game.discover_social_studies("metallurgy")
                    if "Steak" in self.target_ingot:
                        game.discover_social_studies("agrarian")
                    game.sound_mgr.play('chest')
                    # Exact requested completion quote:
                    # "Hey!, Here is your .... Ingot, Thanks for the gold kid."
                    self.dialogues = [
                        ("Star", f"Hey!, Here is your {self.target_ingot}, Thanks for the gold kid.")
                    ]
                    self.dialogue_index = 0
                    self.is_smelt_dialogue = False
                    game.dialogue_ui.start_dialogue(self, game.sound_mgr)
            else:
                self.rect.x += (dx / dist) * 70.0 * dt
                self.rect.y += (dy / dist) * 70.0 * dt

        super().update(dt, map_obj, player)

    def draw(self, surface, camera, is_transparent=False):
        # Draw smoke particles
        for p in self.smoke_particles:
            sp = camera.apply_point((int(p[0]), int(p[1])))
            r = int(5 + (2.0 - p[4]) * 5)
            smoke_surf = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
            alpha = int(max(0, min(180, (p[4] / 2.0) * 160)))
            pygame.draw.circle(smoke_surf, (190, 190, 195, alpha), (r, r), r)
            surface.blit(smoke_surf, (sp[0] - r, sp[1] - r))

        if not self.visible:
            return

        screen_rect = camera.apply_rect(self.rect)
        shadow_rect = self.shadow.get_rect(center=(screen_rect.centerx, screen_rect.bottom - 4))
        surface.blit(self.shadow, shadow_rect)

        if self.blacksmith_sprite:
            surface.blit(self.blacksmith_sprite, screen_rect)
        else:
            super().draw(surface, camera, is_transparent)

        # Draw emote bubble if talking
        if self.is_talking and self.current_emote and RPGNPC._cached_emotes and self.current_emote in RPGNPC._cached_emotes:
            e_frames = RPGNPC._cached_emotes[self.current_emote]
            if e_frames:
                e_img = e_frames[self.emote_frame % len(e_frames)]
                bob_offset = math.sin(pygame.time.get_ticks() * 0.006) * 3
                e_rect = e_img.get_rect(center=(screen_rect.centerx, screen_rect.top - 16 + int(bob_offset)))
                bg_rect = e_rect.inflate(8, 6)
                pygame.draw.rect(surface, (20, 20, 28), bg_rect, border_radius=5)
                pygame.draw.rect(surface, (240, 200, 80), bg_rect, width=2, border_radius=5)
                surface.blit(e_img, e_rect)

class WeatherSystem:
    def __init__(self, screen_w, screen_h):
        self.screen_w = screen_w
        self.screen_h = screen_h
        
        # Weather States: "CLEAR", "CLOUDY", "RAIN", "THUNDERSTORM"
        self.states = ["CLEAR", "CLOUDY", "RAIN", "THUNDERSTORM"]
        self.current_weather = "CLEAR"
        self.weather_timer = random.uniform(180.0, 360.0) # Changes every 3-6 minutes
        
        # Atmospheric Tint Alpha Transitions
        self.current_tint_alpha = 0.0
        self.target_tint_alpha = 0.0
        self.tint_color = (0, 0, 0)
        
        # Particles: Rain Streaks
        self.num_raindrops = 160
        self.raindrops = []
        for _ in range(self.num_raindrops):
            self.raindrops.append({
                "x": random.uniform(0, screen_w + 200),
                "y": random.uniform(-100, screen_h),
                "speed": random.uniform(500, 850),
                "length": random.randint(10, 18),
                "alpha": random.randint(140, 230),
                "thick": random.choice([1, 1, 2])
            })
            
        # Particles: Ground Splash Ripples
        self.splashes = []
        self.splash_pool_max = 30
        
        # Particles: Drifting Cloud Shadows
        self.cloud_shadows = []
        for _ in range(6):
            self.cloud_shadows.append({
                "x": random.uniform(-400, screen_w + 600),
                "y": random.uniform(-200, screen_h + 400),
                "w": random.randint(220, 480),
                "h": random.randint(120, 260),
                "speed": random.uniform(15, 35)
            })
            
        # Thunderstorm Lightning & Rumble System
        self.lightning_timer = random.uniform(5.0, 14.0)
        self.lightning_flash_alpha = 0.0
        self.screen_shake_timer = 0.0
        self.shake_offset = (0, 0)
        
        # Ambient Audio Patter Timer
        self.rain_sound_timer = 0.0

    def set_weather(self, weather_type):
        if weather_type in self.states:
            self.current_weather = weather_type
            self.weather_timer = random.uniform(180.0, 360.0)
            if weather_type == "CLEAR":
                self.target_tint_alpha = 0.0
            elif weather_type == "CLOUDY":
                self.target_tint_alpha = 45.0
                self.tint_color = (25, 35, 45)
            elif weather_type == "RAIN":
                self.target_tint_alpha = 75.0
                self.tint_color = (18, 28, 48)
            elif weather_type == "THUNDERSTORM":
                self.target_tint_alpha = 120.0
                self.tint_color = (12, 16, 32)
                self.lightning_timer = random.uniform(4.0, 10.0)

    def update(self, dt, is_outside=True, sound_mgr=None):
        # Countdown organic weather cycle
        self.weather_timer -= dt
        if self.weather_timer <= 0:
            next_weather = random.choice(self.states)
            self.set_weather(next_weather)

        # Smooth tint transition
        if self.current_tint_alpha < self.target_tint_alpha:
            self.current_tint_alpha = min(self.target_tint_alpha, self.current_tint_alpha + dt * 40.0)
        elif self.current_tint_alpha > self.target_tint_alpha:
            self.current_tint_alpha = max(self.target_tint_alpha, self.current_tint_alpha - dt * 40.0)

        # Update Drifting Cloud Shadows
        for c in self.cloud_shadows:
            c["x"] += c["speed"] * dt
            if c["x"] > self.screen_w + 700:
                c["x"] = -c["w"] - random.uniform(100, 400)
                c["y"] = random.uniform(-200, self.screen_h + 300)

        # Only simulate outdoor precipitation & lightning if outside
        if not is_outside:
            self.lightning_flash_alpha = max(0.0, self.lightning_flash_alpha - dt * 1200.0)
            self.screen_shake_timer = 0.0
            self.shake_offset = (0, 0)
            return

        # Update Rain & Thunderstorms
        if self.current_weather in ["RAIN", "THUNDERSTORM"]:
            # Rain sound trigger
            self.rain_sound_timer -= dt
            if self.rain_sound_timer <= 0:
                self.rain_sound_timer = random.uniform(1.2, 2.5)
                if sound_mgr and hasattr(sound_mgr, 'play'):
                    sound_mgr.play('rain_ambient')

            # Update Raindrops
            active_count = self.num_raindrops if self.current_weather == "THUNDERSTORM" else self.num_raindrops // 2
            wind_x = 180 if self.current_weather == "THUNDERSTORM" else 90
            
            for i in range(active_count):
                drop = self.raindrops[i]
                drop["y"] += drop["speed"] * dt
                drop["x"] += wind_x * dt
                
                # Check ground hit
                if drop["y"] >= self.screen_h:
                    # Spawn ground splash ripple
                    if len(self.splashes) < self.splash_pool_max and random.random() < 0.35:
                        self.splashes.append({
                            "x": drop["x"],
                            "y": drop["y"] - random.randint(2, 20),
                            "radius": 1.0,
                            "max_radius": random.randint(4, 7),
                            "alpha": 200
                        })
                    drop["y"] = random.uniform(-60, -10)
                    drop["x"] = random.uniform(-100, self.screen_w + 100)

            # Update Splash Ripples
            for splash in self.splashes[:]:
                splash["radius"] += dt * 14.0
                splash["alpha"] -= dt * 500.0
                if splash["alpha"] <= 0 or splash["radius"] >= splash["max_radius"]:
                    self.splashes.remove(splash)

        # Thunderstorm Lightning & Screen Shake
        if self.current_weather == "THUNDERSTORM":
            self.lightning_timer -= dt
            if self.lightning_timer <= 0:
                self.lightning_timer = random.uniform(5.0, 14.0)
                # Lightning screen flash
                self.lightning_flash_alpha = random.randint(200, 255)
                self.screen_shake_timer = 0.35
                if sound_mgr and hasattr(sound_mgr, 'play'):
                    sound_mgr.play('thunder_heavy')

            if self.lightning_flash_alpha > 0:
                self.lightning_flash_alpha = max(0.0, self.lightning_flash_alpha - dt * 900.0)

            if self.screen_shake_timer > 0:
                self.screen_shake_timer -= dt
                mag = 3
                self.shake_offset = (random.randint(-mag, mag), random.randint(-mag, mag))
            else:
                self.shake_offset = (0, 0)
        else:
            self.lightning_flash_alpha = 0.0
            self.screen_shake_timer = 0.0
            self.shake_offset = (0, 0)

    def draw_cloud_shadows(self, surface, camera):
        # Draw soft semi-transparent drifting cloud shadows on world terrain
        if self.current_weather in ["CLOUDY", "RAIN", "THUNDERSTORM"]:
            for c in self.cloud_shadows:
                screen_r = pygame.Rect(c["x"], c["y"], c["w"], c["h"])
                c_surf = pygame.Surface((c["w"], c["h"]), pygame.SRCALPHA)
                pygame.draw.ellipse(c_surf, (0, 0, 0, 35 if self.current_weather == "CLOUDY" else 55), (0, 0, c["w"], c["h"]))
                surface.blit(c_surf, screen_r.topleft)

    def draw(self, surface):
        # 1. Atmospheric Sky Tint Overlay
        if self.current_tint_alpha > 0:
            tint_surf = pygame.Surface((self.screen_w, self.screen_h), pygame.SRCALPHA)
            tint_surf.fill((*self.tint_color, int(self.current_tint_alpha)))
            surface.blit(tint_surf, (0, 0))

        # 2. Ground Splash Ripples
        for splash in self.splashes:
            if splash["alpha"] > 0:
                s_surf = pygame.Surface((int(splash["radius"]*2 + 4), int(splash["radius"] + 4)), pygame.SRCALPHA)
                r = int(splash["radius"])
                pygame.draw.ellipse(s_surf, (200, 230, 255, int(splash["alpha"])), (0, 0, r*2, r))
                surface.blit(s_surf, (int(splash["x"] - r), int(splash["y"] - r//2)))

        # 3. Rain Streaks (Angled Pixel Streaks)
        if self.current_weather in ["RAIN", "THUNDERSTORM"]:
            active_count = self.num_raindrops if self.current_weather == "THUNDERSTORM" else self.num_raindrops // 2
            wind_dx = 5 if self.current_weather == "THUNDERSTORM" else 3
            
            for i in range(active_count):
                drop = self.raindrops[i]
                x1, y1 = int(drop["x"]), int(drop["y"])
                x2, y2 = x1 + wind_dx, y1 + drop["length"]
                color = (185, 215, 255, drop["alpha"]) if self.current_weather == "RAIN" else (160, 200, 240, drop["alpha"])
                
                # Draw sharp 16-bit rain pixel streak
                pygame.draw.line(surface, color, (x1, y1), (x2, y2), drop["thick"])

        # 4. Lightning Flash (Bright Electric White / Cyan Pulse)
        if self.lightning_flash_alpha > 0:
            flash_surf = pygame.Surface((self.screen_w, self.screen_h), pygame.SRCALPHA)
            flash_surf.fill((230, 245, 255, int(self.lightning_flash_alpha)))
            surface.blit(flash_surf, (0, 0))

class RetroDialogueUI:
    def __init__(self, screen_w, screen_h):
        self.screen_w = screen_w
        self.screen_h = screen_h
        self.active = False
        self.npc = None
        self.full_text = ""
        self.displayed_text = ""
        self.char_index = 0
        self.typewriter_timer = 0.0
        self.typewriter_speed = 0.035 # Snappy retro typewriter text speed
        self.is_finished = False
        
        # Dialogue box rect at bottom center
        box_w = min(720, screen_w - 40)
        box_h = 140
        self.box_rect = pygame.Rect((screen_w - box_w) // 2, screen_h - box_h - 20, box_w, box_h)
        self.font_title = pygame.font.SysFont("consolas,couriernew,monospace", 15, bold=True)
        self.font_body = pygame.font.SysFont("consolas,couriernew,monospace", 13, bold=True)

    def start_dialogue(self, npc, sound_mgr):
        self.npc = npc
        self.active = True
        npc.is_talking = True  # Show emote bubble while talking
        self.dialogue_step = 0
        if getattr(npc, 'rage_state', 'normal') in ["raging", "scolding", "tired"]:
            emote, text = npc.get_current_dialogue()
            self.dialogue_list = [(emote, text)]
        elif hasattr(npc, 'dialogues') and npc.dialogues:
            self.dialogue_list = list(npc.dialogues)
        else:
            emote, text = npc.get_current_dialogue()
            self.dialogue_list = [(emote, text)]

        emote, text = self.dialogue_list[0]
        if hasattr(npc, 'set_emote'):
            npc.set_emote(emote)
        self.full_text = text
        self.displayed_text = ""
        self.char_index = 0
        self.typewriter_timer = 0.0
        self.is_finished = False
        sound_mgr.play('alert')

    def update(self, dt, events, sound_mgr, game=None):
        if not self.active:
            return

        # Typewriter text animation (word-by-word / character-by-character)
        if not self.is_finished:
            self.typewriter_timer += dt
            if self.typewriter_timer >= self.typewriter_speed:
                self.typewriter_timer = 0.0
                if self.char_index < len(self.full_text):
                    self.char_index += 1
                    self.displayed_text = self.full_text[:self.char_index]
                    # Play retro 8-bit speech blip sound on non-space characters
                    if self.full_text[self.char_index - 1] != ' ' and self.char_index % 2 == 0:
                        sound_mgr.play('text_blip')
                else:
                    self.is_finished = True

        # Handle keypress / click to advance or close dialogue
        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key in [pygame.K_e, pygame.K_ESCAPE, pygame.K_SPACE, pygame.K_RETURN]:
                    if not self.is_finished:
                        # Instant skip typewriter to full text
                        self.char_index = len(self.full_text)
                        self.displayed_text = self.full_text
                        self.is_finished = True
                    else:
                        # Advance to next dialogue line in conversation
                        self.dialogue_step += 1
                        if hasattr(self, 'dialogue_list') and self.dialogue_step < len(self.dialogue_list):
                            emote, text = self.dialogue_list[self.dialogue_step]
                            if hasattr(self.npc, 'set_emote'):
                                self.npc.set_emote(emote)
                            self.full_text = text
                            self.displayed_text = ""
                            self.char_index = 0
                            self.typewriter_timer = 0.0
                            self.is_finished = False
                            sound_mgr.play('alert')
                        else:
                            # Close dialogue
                            self.active = False
                            if self.npc:
                                self.npc.is_talking = False  # Hide emote bubble when done talking
                                if hasattr(self.npc, 'on_smelt_dialogue_finished') and getattr(self.npc, 'is_smelt_dialogue', False):
                                    self.npc.on_smelt_dialogue_finished(game)
                            sound_mgr.play('alert')

    def draw(self, surface):
        if not self.active or not self.npc:
            return

        # Retro Frame Box: Dark slate background with double golden pixel borders
        pygame.draw.rect(surface, (20, 22, 32), self.box_rect, border_radius=8)
        pygame.draw.rect(surface, (210, 170, 70), self.box_rect, width=3, border_radius=8)
        pygame.draw.rect(surface, (110, 85, 30), self.box_rect.inflate(-6, -6), width=2, border_radius=6)

        # NPC Portrait Box (Left side)
        portrait_rect = pygame.Rect(self.box_rect.x + 15, self.box_rect.y + 15, 64, 80)
        pygame.draw.rect(surface, (12, 14, 20), portrait_rect, border_radius=6)
        pygame.draw.rect(surface, (180, 140, 50), portrait_rect, width=2, border_radius=6)

        # Draw NPC Portrait Image
        if hasattr(self.npc, 'animations') and self.npc.animations:
            frames = self.npc.animations.get("Down_idle", [])
            if frames:
                p_img = pygame.transform.scale(frames[0], (52, 68))
                surface.blit(p_img, p_img.get_rect(center=portrait_rect.center))

        # Speaker Name Tag (Top Left Badge)
        name_surf = self.font_title.render(self.npc.name, True, (255, 220, 100))
        surface.blit(name_surf, (self.box_rect.x + 95, self.box_rect.y + 15))

        # Word-wrapped typewriter text lines (Right side)
        text_x = self.box_rect.x + 95
        text_y = self.box_rect.y + 42
        max_w = self.box_rect.width - 115

        words = self.displayed_text.split(' ')
        line = ""
        lines = []
        for w in words:
            test_line = line + (" " if line else "") + w
            if self.font_body.size(test_line)[0] <= max_w:
                line = test_line
            else:
                lines.append(line)
                line = w
        if line:
            lines.append(line)

        for i, l in enumerate(lines[:3]):
            t_surf = self.font_body.render(l, True, (240, 240, 245))
            surface.blit(t_surf, (text_x, text_y + i * 22))

        # Retro Prompt Indicator: Pulsing arrow at bottom right when finished
        if self.is_finished:
            pulse = math.sin(pygame.time.get_ticks() * 0.008) * 3
            arrow_surf = self.font_body.render("> Press [E]", True, (255, 215, 80))
            arrow_rect = arrow_surf.get_rect(bottomright=(self.box_rect.right - 15, self.box_rect.bottom - 10 + int(pulse)))
            surface.blit(arrow_surf, arrow_rect)

class RPGMap:
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.chunk_size_tiles = 16
        self.tile_size = 48
        self.chunk_px = self.chunk_size_tiles * self.tile_size # 768px x 768px per chunk

        self.generated_chunks = {} # {(cx, cy): {"surface": Surface, "objects": [...], "npcs": [...], "solid_objects": [...]}}
        self.all_npcs = []

        tiles_dir = os.path.join(base_dir, "3D_Assets", "Fantasy Chronicles", "sprites")
        
        # --- PROPER PIXEL ART GRASS TUFTS & FLOWERS ---
        self.grass_small_img = pygame.Surface((16, 16), pygame.SRCALPHA)
        pygame.draw.rect(self.grass_small_img, (85, 140, 40), (0, 8, 4, 4))
        pygame.draw.rect(self.grass_small_img, (85, 140, 40), (12, 8, 4, 4))
        pygame.draw.rect(self.grass_small_img, (85, 140, 40), (4, 12, 8, 4))
        pygame.draw.rect(self.grass_small_img, (140, 205, 75), (0, 4, 4, 4))
        pygame.draw.rect(self.grass_small_img, (140, 205, 75), (12, 4, 4, 4))
        pygame.draw.rect(self.grass_small_img, (140, 205, 75), (4, 8, 8, 4))

        self.grass_tall_img = pygame.Surface((20, 24), pygame.SRCALPHA)
        pygame.draw.rect(self.grass_tall_img, (70, 120, 30), (0, 12, 4, 8))
        pygame.draw.rect(self.grass_tall_img, (70, 120, 30), (8, 8, 4, 16))
        pygame.draw.rect(self.grass_tall_img, (70, 120, 30), (16, 16, 4, 4))
        pygame.draw.rect(self.grass_tall_img, (120, 190, 60), (0, 4, 4, 8))
        pygame.draw.rect(self.grass_tall_img, (120, 190, 60), (8, 0, 4, 8))
        pygame.draw.rect(self.grass_tall_img, (120, 190, 60), (16, 12, 4, 4))
        
        self.house_img = None
        house_file = os.path.join(tiles_dir, "Outdor", "house.png")
        if os.path.exists(house_file):
            self.house_img = pygame.image.load(house_file).convert_alpha()
            self.house_img = pygame.transform.scale(self.house_img, (250, 250))
            self.house_img_trans = self.house_img.copy()
            self.house_img_trans.fill((255, 255, 255, 140), special_flags=pygame.BLEND_RGBA_MULT)
            
        self.tree_imgs = []
        self.tree_imgs_trans = []
        for tree_file in ["big_oak_tree_static.png", "medium_oak_tree_static.png", "small_oak_tree_static.png"]:
            tf = os.path.join(tiles_dir, "Outdor", tree_file)
            if os.path.exists(tf):
                img = pygame.image.load(tf).convert_alpha()
                if "big_" in tree_file:
                    img = pygame.transform.scale(img, (128, 160))
                else:
                    img = pygame.transform.scale(img, (256, 320))
                self.tree_imgs.append(img)
                trans = img.copy()
                trans.fill((255, 255, 255, 140), special_flags=pygame.BLEND_RGBA_MULT)
                self.tree_imgs_trans.append(trans)
            
        self.bush_imgs = []
        self.bush_imgs_trans = []
        bush_dir = os.path.join(base_dir, "3D_Assets", "Bush")
        if os.path.exists(bush_dir):
            for i in range(9):
                bf = os.path.join(bush_dir, f"{i}.png")
                if os.path.exists(bf):
                    img = pygame.image.load(bf).convert_alpha()
                    img = pygame.transform.scale(img, (64, 64))
                    self.bush_imgs.append(img)
                    trans = img.copy()
                    trans.fill((255, 255, 255, 140), special_flags=pygame.BLEND_RGBA_MULT)
                    self.bush_imgs_trans.append(trans)

        # Pre-create shadows
        self.shadows = {}
        sw, sh = 220, 60
        sh_house = pygame.Surface((sw, sh), pygame.SRCALPHA)
        pygame.draw.rect(sh_house, (0, 0, 0, 100), (sw//8, 0, sw - sw//4, sh))
        pygame.draw.rect(sh_house, (0, 0, 0, 100), (0, sh//3, sw, sh - 2*(sh//3)))
        self.shadows["house"] = sh_house
        
        sw, sh = 48, 16
        sh_bush = pygame.Surface((sw, sh), pygame.SRCALPHA)
        pygame.draw.rect(sh_bush, (0, 0, 0, 100), (sw//8, 0, sw - sw//4, sh))
        pygame.draw.rect(sh_bush, (0, 0, 0, 100), (0, sh//3, sw, sh - 2*(sh//3)))
        self.shadows["bush"] = sh_bush

        self.village_kill_counts = {} # {(cx, cy): kill_count}
        self.ground_items = [] # Active dropped items on the ground
        self.blacksmith_npc = None

        # Pre-generate Chunk (0, 0) as the Starting Village Hub
        self.get_chunk(0, 0)

    @property
    def objects(self):
        objs = []
        for chunk in self.generated_chunks.values():
            objs.extend(chunk.get("objects", []))
        return objs

    @objects.setter
    def objects(self, val):
        if not val:
            for chunk in self.generated_chunks.values():
                chunk["objects"] = []
                chunk["solid_objects"] = []

    @property
    def solid_objects(self):
        solids = []
        for chunk in self.generated_chunks.values():
            solids.extend(chunk.get("solid_objects", []))
        return solids

    @solid_objects.setter
    def solid_objects(self, val):
        if not val:
            for chunk in self.generated_chunks.values():
                chunk["solid_objects"] = []

    def remove_object(self, obj_to_remove):
        """Permanently removes an entity/object (e.g. defeated bear or animal) from its chunk."""
        for chunk in self.generated_chunks.values():
            if obj_to_remove in chunk["objects"]:
                chunk["objects"].remove(obj_to_remove)
            if obj_to_remove in chunk["solid_objects"]:
                chunk["solid_objects"].remove(obj_to_remove)

    def on_animal_killed(self, home_village, animal_pos, sound_mgr):
        """Called when a domestic village animal is slain."""
        self.village_kill_counts[home_village] = self.village_kill_counts.get(home_village, 0) + 1
        kills = self.village_kill_counts[home_village]

        # Find villagers in this village
        village_npcs = [npc for npc in self.all_npcs if getattr(npc, 'home_village', None) == home_village]
        if not village_npcs:
            village_npcs = self.all_npcs

        if village_npcs:
            # Pick the closest living villager to the slain animal
            village_npcs.sort(key=lambda n: (n.rect.centerx - animal_pos[0])**2 + (n.rect.centery - animal_pos[1])**2)
            chosen_npc = village_npcs[0]

            if kills == 1:
                # First kill: Kinda mad / scolding
                chosen_npc.rage_state = "scolding"
                chosen_npc.set_emote("Angry")
                chosen_npc.is_talking = True
                chosen_npc.shout_text = "HEY! Why did you harm our animal?! Leave our livestock alone!"
                chosen_npc.shout_timer = 5.0
                sound_mgr.play('alert')
            else:
                # Second kill (or more): Full Combat Rage!
                chosen_npc.rage_state = "raging"
                chosen_npc.set_emote("Evil")
                chosen_npc.is_talking = True
                chosen_npc.speed = 125.0
                chosen_npc.rage_timer = 20.0
                chosen_npc.shout_text = "YOU MONSTER! That's it! You're gonna PAY for what you did! GET OVER HERE!"
                chosen_npc.shout_timer = 6.0
                sound_mgr.play('alert')

    def is_village_chunk(self, cx, cy):
        """Determines if a chunk is a village (every ~100-150 blocks, i.e., every 7-8 chunks)."""
        if cx == 0 and cy == 0:
            return True
        return (cx % 8 == 0 and cy % 8 == 0)

    def get_chunk(self, cx, cy):
        key = (cx, cy)
        if key in self.generated_chunks:
            return self.generated_chunks[key]

        # Generate Chunk procedurally with seeded RNG for absolute chunk persistence!
        seed = (cx * 73856093) ^ (cy * 19349663)
        rng = random.Random(seed)

        c_surf = pygame.Surface((self.chunk_px, self.chunk_px)).convert()
        c_surf.fill((108, 175, 55)) # Vibrant RPG Grass Base

        objects = []
        npcs = []

        if self.is_village_chunk(cx, cy):
            # --- VILLAGE HUB CHUNK (cx, cy) - Spawns every 100-150 blocks! ---
            # Pre-render grass tufts directly onto village chunk surface
            for _ in range(40):
                gx = rng.randint(10, self.chunk_px - 30)
                gy = rng.randint(10, self.chunk_px - 30)
                if rng.random() < 0.6:
                    c_surf.blit(self.grass_small_img, (gx, gy))
                else:
                    c_surf.blit(self.grass_tall_img, (gx, gy))

            # Central Cobblestone Plaza (500x500 square in center)
            plaza_rect = pygame.Rect(134, 134, 500, 500)
            pygame.draw.rect(c_surf, (150, 135, 110), plaza_rect, border_radius=12)
            pygame.draw.rect(c_surf, (120, 105, 80), plaza_rect, width=4, border_radius=12)

            # Village Houses spaced wide apart so player NEVER gets stuck!
            house_positions = [
                (cx * self.chunk_px + 30, cy * self.chunk_px + 30),
                (cx * self.chunk_px + 480, cy * self.chunk_px + 30),
                (cx * self.chunk_px + 30, cy * self.chunk_px + 480),
                (cx * self.chunk_px + 480, cy * self.chunk_px + 480)
            ]
            for hx, hy in house_positions:
                rect = pygame.Rect(hx, hy, 250, 250)
                hitbox = pygame.Rect(rect.x + 20, rect.bottom - 80, 210, 80)
                trans_zone = pygame.Rect(rect.x + 20, rect.y, 210, rect.height - 60)
                objects.append({"type": "house", "rect": rect, "hitbox": hitbox, "trans_zone": trans_zone})

            # Decorative Bushes around Plaza
            for bx_local, by_local in [(290, 220), (420, 220), (290, 480), (420, 480)]:
                if self.bush_imgs:
                    bx = cx * self.chunk_px + bx_local
                    by = cy * self.chunk_px + by_local
                    b_img = self.bush_imgs[0]
                    b_trans = self.bush_imgs_trans[0]
                    b_rect = pygame.Rect(bx, by, 64, 64)
                    objects.append({
                        "type": "bush",
                        "rect": b_rect,
                        "img": b_img,
                        "img_trans": b_trans,
                        "hitbox": pygame.Rect(bx + 10, by + 44, 44, 20),
                        "trans_zone": pygame.Rect(bx + 10, by, 44, 49)
                    })

            # Village NPCs spawned in open central plaza paths
            def get_village_name(vx, vy):
                if vx == 0 and vy == 0:
                    return "Oakvale"
                prefixes = [
                    "River", "Stone", "Pine", "Green", "Silver", "Sun", "Willow", "Falcon",
                    "Bramble", "Elder", "Shadow", "Amber", "Wind", "Misty", "Copper", "Maple",
                    "Clear", "Moss", "Frost", "Iron", "Gold", "High", "Ash", "Cedar", "Wild"
                ]
                suffixes = [
                    "wood", "brook", "haven", "dale", "crest", "moor", "fall", "valley",
                    "ridge", "ford", "stead", "hollow", "glen", "field", "cross", "meadow"
                ]
                h = abs((vx * 73856093) ^ (vy * 19349663))
                p = prefixes[h % len(prefixes)]
                s = suffixes[(h // len(prefixes)) % len(suffixes)]
                return f"{p}{s}"

            v_name_prefix = get_village_name(cx, cy)
            npc_data = [
                (cx * self.chunk_px + 310, cy * self.chunk_px + 340, "NPC_1", f"Elder of {v_name_prefix}", [
                    ("Happy", f"Welcome to {v_name_prefix}! Our peaceful valley stretches infinitely."),
                    ("Star", "Feel free to rest in the houses or greet our domestic animals!"),
                    ("Angry", "Please don't harm our animals, or our village folk will be furious!")
                ], "Happy"),
                (cx * self.chunk_px + 440, cy * self.chunk_px + 340, "NPC_2", "Lilia the Farmer", [
                    ("Heart", "I take care of all our village chickens, cows, sheep, and pigs!"),
                    ("Happy", "They love grazing around the plaza! Treat them gently!"),
                    ("Surprised", "Beware of wild beasts in the wilderness!")
                ], "Heart"),
                (cx * self.chunk_px + 310, cy * self.chunk_px + 430, "NPC_3", "Garrick the Guard", [
                    ("Angry", "I protect this village and its livestock from any harm!"),
                    ("Surprised", "Keep your weapon sheathed near our animals, adventurer!"),
                    ("Star", "Have you explored the ancient dungeons?")
                ], "Angry"),
                (cx * self.chunk_px + 440, cy * self.chunk_px + 430, "NPC_1", "Villager Bram", [
                    ("Interrogation", "Are you traveling between the infinite realm villages?"),
                    ("Happy", "Our valley has fresh water and fertile green grass!"),
                    ("Exclamation", "Enjoy your stay in our village!")
                ], "Interrogation")
            ]

            for nx, ny, skin, name, dialogues, def_emote in npc_data:
                npc = RPGNPC(nx, ny, self.base_dir, skin, name, dialogues, def_emote, home_village=(cx, cy))
                npcs.append(npc)
                self.all_npcs.append(npc)

            # Domestic Village Farm Animals (Chickens, Cows, Pigs, Sheep)
            animal_spawns = [
                ("chicken", 250, 310),
                ("chicken", 280, 370),
                ("cow", 490, 380),
                ("pig", 260, 440),
                ("sheep", 480, 440)
            ]
            for a_type, ax_local, ay_local in animal_spawns:
                ax = cx * self.chunk_px + ax_local
                ay = cy * self.chunk_px + ay_local
                animal = RPGVillageAnimal(ax, ay, a_type, self.base_dir, home_village=(cx, cy))
                objects.append({
                    "type": "village_animal",
                    "rect": animal.rect,
                    "hitbox": animal.hitbox,
                    "trans_zone": pygame.Rect(animal.rect.x, animal.rect.y, animal.rect.width, animal.rect.height),
                    "animal_obj": animal
                })

            # Starting Village Hub (0, 0): Master Blacksmith outside house + starter rocks & ores
            if cx == 0 and cy == 0:
                bs = RPGBlacksmithNPC(cx * self.chunk_px + 550, cy * self.chunk_px + 245, self.base_dir, home_village=(cx, cy))
                npcs.append(bs)
                self.all_npcs.append(bs)
                self.blacksmith_npc = bs

                for r_type, rx_loc, ry_loc in [
                    ("small_rock", 120, 160),
                    ("small_rock", 620, 160),
                    ("medium_rock", 140, 580),
                    ("coal_ore", 640, 560),
                    ("iron_ore", 130, 480)
                ]:
                    rx = cx * self.chunk_px + rx_loc
                    ry = cy * self.chunk_px + ry_loc
                    rock_obj = RPGMineableObject(rx, ry, r_type, self.base_dir)
                    objects.append({
                        "type": "mineable_rock",
                        "rect": rock_obj.rect,
                        "hitbox": rock_obj.hitbox,
                        "mineable_obj": rock_obj
                    })

        else:
            # --- PROCEDURAL OUTER CHUNKS (cx, cy) ---
            # Grass tufts & flowers pre-rendered to chunk surface
            for _ in range(rng.randint(18, 32)):
                gx = rng.randint(0, self.chunk_px - 20)
                gy = rng.randint(0, self.chunk_px - 24)
                if rng.random() < 0.6:
                    c_surf.blit(self.grass_small_img, (gx, gy))
                else:
                    c_surf.blit(self.grass_tall_img, (gx, gy))

            # Procedural Trees in Outer Chunks
            if self.tree_imgs:
                for _ in range(rng.randint(3, 7)):
                    tx_local = rng.randint(20, self.chunk_px - 150)
                    ty_local = rng.randint(20, self.chunk_px - 180)
                    tx = cx * self.chunk_px + tx_local
                    ty = cy * self.chunk_px + ty_local
                    t_idx = rng.randint(0, len(self.tree_imgs) - 1)
                    t_img = self.tree_imgs[t_idx]
                    t_trans = self.tree_imgs_trans[t_idx]
                    tw, th = t_img.get_size()
                    t_rect = pygame.Rect(tx, ty, tw, th)

                    if tw == 128:
                        hitbox = pygame.Rect(t_rect.x + 56, t_rect.y + 120, 16, 16)
                        trans_zone = pygame.Rect(t_rect.x + 20, t_rect.y, 88, 120)
                    else:
                        hitbox = pygame.Rect(t_rect.x + 113, t_rect.y + 240, 30, 26)
                        trans_zone = pygame.Rect(t_rect.x + 40, t_rect.y, 176, 240)

                    objects.append({
                        "type": "tree",
                        "rect": t_rect,
                        "img": t_img,
                        "img_trans": t_trans,
                        "hitbox": hitbox,
                        "trans_zone": trans_zone,
                        "hits": 0,
                        "max_hits": 4,
                        "hit_timer": 0.0
                    })

            # Procedural Bushes in Outer Chunks
            if self.bush_imgs:
                for _ in range(rng.randint(3, 6)):
                    bx_local = rng.randint(20, self.chunk_px - 80)
                    by_local = rng.randint(20, self.chunk_px - 80)
                    bx = cx * self.chunk_px + bx_local
                    by = cy * self.chunk_px + by_local
                    b_idx = rng.randint(0, len(self.bush_imgs) - 1)
                    b_img = self.bush_imgs[b_idx]
                    b_trans = self.bush_imgs_trans[b_idx]
                    b_rect = pygame.Rect(bx, by, 64, 64)
                    objects.append({
                        "type": "bush",
                        "rect": b_rect,
                        "img": b_img,
                        "img_trans": b_trans,
                        "hitbox": pygame.Rect(bx + 10, by + 44, 44, 20),
                        "trans_zone": pygame.Rect(bx + 10, by, 44, 49)
                    })

            # Procedural Mineable Rocks & Ores in Outer Chunks
            # Small Rocks (2 hits, 1-3 drops)
            for _ in range(rng.randint(3, 6)):
                rx = cx * self.chunk_px + rng.randint(30, self.chunk_px - 60)
                ry = cy * self.chunk_px + rng.randint(30, self.chunk_px - 60)
                rock = RPGMineableObject(rx, ry, "small_rock", self.base_dir)
                objects.append({"type": "mineable_rock", "rect": rock.rect, "hitbox": rock.hitbox, "mineable_obj": rock})

            # Medium Rocks (4 hits, 3-6 drops)
            for _ in range(rng.randint(2, 4)):
                rx = cx * self.chunk_px + rng.randint(30, self.chunk_px - 60)
                ry = cy * self.chunk_px + rng.randint(30, self.chunk_px - 60)
                rock = RPGMineableObject(rx, ry, "medium_rock", self.base_dir)
                objects.append({"type": "mineable_rock", "rect": rock.rect, "hitbox": rock.hitbox, "mineable_obj": rock})

            # Big Rocks (6 hits, 7-10 drops)
            for _ in range(rng.randint(1, 2)):
                rx = cx * self.chunk_px + rng.randint(30, self.chunk_px - 70)
                ry = cy * self.chunk_px + rng.randint(30, self.chunk_px - 70)
                rock = RPGMineableObject(rx, ry, "big_rock", self.base_dir)
                objects.append({"type": "mineable_rock", "rect": rock.rect, "hitbox": rock.hitbox, "mineable_obj": rock})

            # Coal Ores (4 hits, 1-2 drops)
            for _ in range(rng.randint(1, 3)):
                rx = cx * self.chunk_px + rng.randint(30, self.chunk_px - 60)
                ry = cy * self.chunk_px + rng.randint(30, self.chunk_px - 60)
                ore = RPGMineableObject(rx, ry, "coal_ore", self.base_dir)
                objects.append({"type": "mineable_rock", "rect": ore.rect, "hitbox": ore.hitbox, "mineable_obj": ore})

            # Iron Ores (4 hits, 1-2 drops)
            for _ in range(rng.randint(1, 2)):
                rx = cx * self.chunk_px + rng.randint(30, self.chunk_px - 60)
                ry = cy * self.chunk_px + rng.randint(30, self.chunk_px - 60)
                ore = RPGMineableObject(rx, ry, "iron_ore", self.base_dir)
                objects.append({"type": "mineable_rock", "rect": ore.rect, "hitbox": ore.hitbox, "mineable_obj": ore})

            # Ruby Ores (4 hits, 1-2 drops, 45% chance per chunk)
            if rng.random() < 0.45:
                rx = cx * self.chunk_px + rng.randint(30, self.chunk_px - 60)
                ry = cy * self.chunk_px + rng.randint(30, self.chunk_px - 60)
                ore = RPGMineableObject(rx, ry, "ruby_ore", self.base_dir)
                objects.append({"type": "mineable_rock", "rect": ore.rect, "hitbox": ore.hitbox, "mineable_obj": ore})

            # Diamond Ores (4 hits, 1-2 drops, 35% chance per chunk)
            if rng.random() < 0.35:
                rx = cx * self.chunk_px + rng.randint(30, self.chunk_px - 60)
                ry = cy * self.chunk_px + rng.randint(30, self.chunk_px - 60)
                ore = RPGMineableObject(rx, ry, "diamond_ore", self.base_dir)
                objects.append({"type": "mineable_rock", "rect": ore.rect, "hitbox": ore.hitbox, "mineable_obj": ore})

            # Procedural Wandering Bears
            if rng.random() < 0.4:
                bx_local = rng.randint(100, self.chunk_px - 100)
                by_local = rng.randint(100, self.chunk_px - 100)
                bx = cx * self.chunk_px + bx_local
                by = cy * self.chunk_px + by_local
                bear = RPGBear(bx, by, self.base_dir)
                objects.append({
                    "type": "bear",
                    "rect": bear.rect,
                    "hitbox": bear.hitbox,
                    "trans_zone": pygame.Rect(bx + 8, by, 32, 24),
                    "bear_obj": bear
                })

        chunk_data = {
            "surface": c_surf,
            "objects": objects,
            "npcs": npcs,
            "solid_objects": [o for o in objects if o.get("type") in ["house", "tree", "mineable_rock"]]
        }
        self.generated_chunks[key] = chunk_data
        return chunk_data

    def update(self, dt, player=None, game=None):
        for npc in self.all_npcs:
            if isinstance(npc, RPGBlacksmithNPC):
                npc.update(dt, self, player, game=game)
            else:
                npc.update(dt, self, player)
        for obj in self.objects:
            if obj.get("type") == "village_animal":
                anim = obj["animal_obj"]
                anim.update(dt, self)
                obj["rect"] = anim.rect
                obj["hitbox"] = anim.hitbox
            elif obj.get("type") == "mineable_rock":
                obj["mineable_obj"].update(dt)

        for item in self.ground_items[:]:
            collected = item.update(dt, player)
            if collected:
                self.ground_items.remove(item)
                if game and hasattr(game, 'inventory_ui'):
                    game.inventory_ui.add_item(item.item_name, item.qty, item.desc, item.img_file, item.heal)
                    sound_mgr.play('item_pickup')
                    game.prompt_text = f"+{item.qty} {item.item_name} collected!"
                    game.prompt_timer = 2.0
            elif item.lifetime <= 0:
                self.ground_items.remove(item)

    def draw(self, surface, camera, player):
        cam_x, cam_y = -camera.camera.x, -camera.camera.y
        start_cx = int(math.floor(cam_x / self.chunk_px)) - 1
        end_cx = int(math.floor((cam_x + surface.get_width()) / self.chunk_px)) + 1
        start_cy = int(math.floor(cam_y / self.chunk_px)) - 1
        end_cy = int(math.floor((cam_y + surface.get_height()) / self.chunk_px)) + 1

        screen_bounds = surface.get_rect()
        visible_objs = []

        # 1. Blit pre-rendered chunk surfaces
        for cy in range(start_cy, end_cy + 1):
            for cx in range(start_cx, end_cx + 1):
                chunk = self.get_chunk(cx, cy)
                chunk_world_pos = (cx * self.chunk_px, cy * self.chunk_px)
                chunk_screen_rect = camera.apply_rect(pygame.Rect(chunk_world_pos[0], chunk_world_pos[1], self.chunk_px, self.chunk_px))
                surface.blit(chunk["surface"], chunk_screen_rect.topleft)

                for obj in chunk["objects"]:
                    screen_rect = camera.apply_rect(obj["rect"])
                    if screen_rect.colliderect(screen_bounds):
                        obj["_screen_rect"] = screen_rect
                        visible_objs.append(obj)

                for npc in chunk["npcs"]:
                    screen_rect = camera.apply_rect(npc.rect)
                    if screen_rect.colliderect(screen_bounds):
                        visible_objs.append({
                            "type": "npc",
                            "rect": npc.rect,
                            "hitbox": npc.hitbox,
                            "trans_zone": pygame.Rect(npc.rect.x + 4, npc.rect.y, 28, 24),
                            "npc_obj": npc,
                            "_screen_rect": screen_rect
                        })

        visible_objs.append({"type": "player", "rect": player.rect})

        def get_sort_y(obj):
            if obj["type"] == "player":
                return obj["rect"].bottom
            if "hitbox" in obj:
                return obj["hitbox"].bottom
            return obj["rect"].bottom

        sorted_objs = sorted(visible_objs, key=get_sort_y)
        for obj in sorted_objs:
            if obj["type"] == "player":
                player.draw(surface, camera)
            else:
                screen_rect = obj.get("_screen_rect") or camera.apply_rect(obj["rect"])
                if obj["type"] == "house":
                    shadow = self.shadows["house"]
                    offset = 20
                elif obj["type"] == "bush":
                    shadow = self.shadows["bush"]
                    offset = 8
                else:
                    shadow = None
                    offset = 0

                if shadow:
                    shadow_rect = shadow.get_rect(center=(screen_rect.centerx, screen_rect.bottom - offset))
                    surface.blit(shadow, shadow_rect)

                img_to_blit = None
                if obj["type"] == "house" and self.house_img:
                    img_to_blit = self.house_img
                elif obj["type"] in ["tree", "bush"]:
                    img_to_blit = obj.get("img")
                elif obj["type"] == "bear":
                    bear = obj["bear_obj"]
                    transparency_zone = obj.get("trans_zone")
                    player_body = pygame.Rect(player.rect.x + 16, player.rect.y + 16, 32, 48)
                    is_trans = False
                    if transparency_zone and player_body.colliderect(transparency_zone) and player.rect.bottom < obj["rect"].bottom:
                        is_trans = True
                    bear.draw(surface, camera, is_trans)
                elif obj["type"] == "village_animal":
                    animal = obj["animal_obj"]
                    animal.draw(surface, camera)
                elif obj["type"] == "mineable_rock":
                    m = obj["mineable_obj"]
                    m.draw(surface, camera)
                elif obj["type"] == "npc":
                    npc = obj["npc_obj"]
                    transparency_zone = obj.get("trans_zone")
                    player_body = pygame.Rect(player.rect.x + 16, player.rect.y + 16, 32, 48)
                    is_trans = False
                    if transparency_zone and player_body.colliderect(transparency_zone) and player.rect.bottom < obj["rect"].bottom:
                        is_trans = True
                    npc.draw(surface, camera, is_trans)

                if img_to_blit:
                    transparency_zone = obj.get("trans_zone")
                    player_body = pygame.Rect(player.rect.x + 16, player.rect.y + 16, 32, 48)
                    if transparency_zone and player_body.colliderect(transparency_zone) and player.rect.bottom < obj["rect"].bottom:
                        if obj["type"] == "house" and hasattr(self, "house_img_trans"):
                            img_to_blit = self.house_img_trans
                        elif "img_trans" in obj:
                            img_to_blit = obj["img_trans"]

                    if obj.get("type") == "tree" and obj.get("hit_timer", 0) > 0:
                        obj["hit_timer"] -= 0.016
                        shake_x = random.randint(-2, 2)
                        surface.blit(img_to_blit, (screen_rect.x + shake_x, screen_rect.y))
                    else:
                        surface.blit(img_to_blit, screen_rect)

                    # Draw Tree Healthbar pips if tree has been hit
                    if obj.get("type") == "tree" and obj.get("hits", 0) > 0:
                        max_h = obj.get("max_hits", 4)
                        cur_h = max(0, max_h - obj.get("hits", 0))
                        hb_screen = camera.apply_rect(obj["hitbox"])
                        bar_w = 44
                        bar_h = 6
                        bx = hb_screen.centerx - bar_w // 2
                        by = hb_screen.top - 12
                        pygame.draw.rect(surface, (20, 15, 10), (bx - 1, by - 1, bar_w + 2, bar_h + 2), border_radius=3)
                        fill_w = int((cur_h / max_h) * bar_w)
                        col = (80, 220, 70) if cur_h > 2 else ((240, 200, 50) if cur_h > 1 else (230, 60, 50))
                        if fill_w > 0:
                            pygame.draw.rect(surface, col, (bx, by, fill_w, bar_h), border_radius=2)
                        for pip in range(1, max_h):
                            px = bx + int((pip / max_h) * bar_w)
                            pygame.draw.line(surface, (10, 10, 10), (px, by), (px, by + bar_h - 1))

        # Draw floating ground items (with gentle bob & shadows)
        for item in self.ground_items:
            item.draw(surface, camera)

class HouseInterior:
    def __init__(self, width, height, base_dir):
        self.width = width
        self.height = height
        
        # Room bounds (centered on 800x600 screen)
        self.room_w = 624
        self.room_h = 432
        self.room_rect = pygame.Rect((width - self.room_w) // 2, (height - self.room_h) // 2 - 20, self.room_w, self.room_h)
        
        pack_dir = os.path.join(base_dir, "furnitures", "nws", "sierrassets furniture pack")
        fw_path = os.path.join(pack_dir, "floors and walls", "floor and walls spritesheet.png")
        furn_dir = os.path.join(pack_dir, "furniture", "individual sprites")
        
        # Build background surface
        self.bg_surface = pygame.Surface((width, height))
        self.bg_surface.fill((15, 15, 20)) # Dark vignette border
        
        fw_indiv_dir = os.path.join(pack_dir, "floors and walls", "individual sprites")
        
        # Load clean tile slices
        wood_slice = os.path.join(fw_indiv_dir, "Slice 1.png")
        wall_slice = os.path.join(fw_indiv_dir, "Slice 37.png")
        border_slice = os.path.join(fw_indiv_dir, "Slice 38.png")
        
        if os.path.exists(wood_slice):
            wood_floor = pygame.transform.scale(pygame.image.load(wood_slice).convert_alpha(), (48, 48))
            wall_top = pygame.transform.scale(pygame.image.load(wall_slice).convert_alpha(), (48, 48)) if os.path.exists(wall_slice) else wood_floor
            wall_border = pygame.transform.scale(pygame.image.load(border_slice).convert_alpha(), (48, 48)) if os.path.exists(border_slice) else wood_floor
            
            # Tile wooden floor
            for rx in range(self.room_rect.left, self.room_rect.right, 48):
                for ry in range(self.room_rect.top, self.room_rect.bottom, 48):
                    self.bg_surface.blit(wood_floor, (rx, ry))
                    
            # Tile wall wallpaper at top
            for rx in range(self.room_rect.left, self.room_rect.right, 48):
                self.bg_surface.blit(wall_top, (rx, self.room_rect.top))
                self.bg_surface.blit(wall_border, (rx, self.room_rect.top + 48))

        # Room frame / borders
        pygame.draw.rect(self.bg_surface, (60, 40, 25), self.room_rect, 6)
        
        # Exit doorway mat at bottom center
        self.exit_door_rect = pygame.Rect(self.room_rect.centerx - 48, self.room_rect.bottom - 12, 96, 16)
        pygame.draw.rect(self.bg_surface, (160, 90, 40), self.exit_door_rect)
        pygame.draw.rect(self.bg_surface, (220, 180, 80), self.exit_door_rect, 2)
        
        # Load furniture items
        self.furniture_objects = []
        
        def add_item(slice_name, rel_x, rel_y, scale=2.4, is_solid=True, flip_x=False):
            p = os.path.join(furn_dir, slice_name)
            if os.path.exists(p):
                img = pygame.image.load(p).convert_alpha()
                w, h = int(img.get_width() * scale), int(img.get_height() * scale)
                img = pygame.transform.scale(img, (w, h))
                if flip_x:
                    img = pygame.transform.flip(img, True, False)
                world_x = self.room_rect.left + rel_x
                world_y = self.room_rect.top + rel_y
                item_rect = pygame.Rect(world_x, world_y, w, h)
                hitbox = pygame.Rect(world_x + 4, world_y + h // 2, w - 8, h // 2) if is_solid else None
                item_dict = {
                    "rect": item_rect,
                    "img": img,
                    "hitbox": hitbox,
                    "type": "furniture"
                }
                self.furniture_objects.append(item_dict)
                return item_dict
            return None

        # Add furniture layout according to exact placement instructions:
        # 1. White Kitchen Counter & Fridge at Top-Left Corner
        add_item("part-Slice 489.png", 15, 70, scale=2.4)
        
        # 2. Black Kitchen Unit beside the White Kitchen
        add_item("part-Slice 490.png", 115, 70, scale=2.4)
        
        # 3. Loft Bed with Ladder & Table beside the Black Kitchen
        add_item("part-Slice 149.png", 269, 70, scale=2.4)
        
        # 4. Double Bed to the right of the Loft Bed with Ladder
        self.bed_item = add_item("part-Slice 263.png", 353, 70, scale=2.5)

        # 5. Playable Upright Piano in Top-Right Corner (Flipped facing left, rel_x = 441, rel_y = 70)
        self.piano_item = add_item("part-Slice 276.png", 441, 70, scale=2.5, flip_x=True)

    def update_player(self, player, dt, keys, game):
        dx, dy = 0, 0
        is_moving = False
        
        if keys[pygame.K_w]:
            dy -= player.speed * dt
            player.facing = "Up"
            is_moving = True
        elif keys[pygame.K_s]:
            dy += player.speed * dt
            player.facing = "Down"
            is_moving = True
            
        if keys[pygame.K_a]:
            dx -= player.speed * dt
            player.facing = "Left"
            is_moving = True
        elif keys[pygame.K_d]:
            dx += player.speed * dt
            player.facing = "Right"
            is_moving = True

        if is_moving:
            player.action = "Walk"
            player.anim_timer += dt
            if player.anim_timer > 0.1:
                player.anim_timer = 0
                player.frame_index += 1
        else:
            player.action = "Stand"

        new_rect = player.rect.copy()
        new_rect.x += dx
        new_rect.y += dy
        
        # Clamp to room walls (allow doorway exit at bottom)
        min_x = self.room_rect.left + 10
        max_x = self.room_rect.right - new_rect.width - 10
        min_y = self.room_rect.top + 70 # Account for top wall
        max_y = self.room_rect.bottom - new_rect.height - 5
        
        new_rect.x = max(min_x, min(new_rect.x, max_x))
        new_rect.y = max(min_y, min(new_rect.y, max_y))

        # Check collision with furniture hitboxes
        player_hitbox = pygame.Rect(new_rect.x + 16, new_rect.bottom - 20, 32, 20)
        collision = False
        for obj in self.furniture_objects:
            if obj.get("hitbox") and player_hitbox.colliderect(obj["hitbox"]):
                collision = True
                break
                
        if not collision:
            player.rect = new_rect

        # Bed interaction check
        if getattr(self, 'bed_item', None):
            bed_rect = self.bed_item["rect"]
            near_bed = player_hitbox.colliderect(bed_rect.inflate(24, 24))
            if near_bed:
                game.near_bed = True
                if keys[pygame.K_e]:
                    if game.has_slept_today:
                        game.bed_message = "You feel well rested! You can only sleep once per day."
                        game.bed_message_timer = 2.5
                    elif game.sleep_state == "none":
                        game.start_sleep()
            else:
                game.near_bed = False

        # Piano interaction check
        if getattr(self, 'piano_item', None):
            piano_rect = self.piano_item["rect"]
            near_piano = player_hitbox.colliderect(piano_rect.inflate(30, 30))
            if near_piano:
                game.near_piano = True
                if keys[pygame.K_e] and not game.piano_ui.active:
                    game.piano_ui.open()
            else:
                game.near_piano = False

    def draw(self, surface, player, game):
        # Blit pre-rendered room background
        surface.blit(self.bg_surface, (0, 0))
        
        # Draw UI prompt for exit, bed, or piano
        font = get_rpg_font(12, bold=True)
        if getattr(game, 'near_piano', False) and not game.piano_ui.active:
            prompt_str = "PRESS [E] TO PLAY PIANO | [ESC] TO EXIT"
        elif getattr(game, 'near_bed', False):
            prompt_str = "PRESS [E] TO SLEEP IN BED | [ESC] TO EXIT"
        else:
            prompt_str = "PRESS [ESC] OR WALK DOWN TO EXIT HOUSE"
            
        prompt = font.render(prompt_str, False, (240, 240, 240))
        surface.blit(prompt, (self.width // 2 - prompt.get_width() // 2, self.room_rect.top - 25))

        # Y-Sort player and furniture for depth
        all_objs = self.furniture_objects.copy()
        all_objs.append({"type": "player", "rect": player.rect})
        
        def get_sort_y(o):
            if o["type"] == "player":
                return o["rect"].bottom
            return o["rect"].bottom
            
        sorted_objs = sorted(all_objs, key=get_sort_y)
        
        # Fixed camera for interior
        class StaticCamera:
            def apply_rect(self, r): return r
            
        static_cam = StaticCamera()
        for obj in sorted_objs:
            if obj["type"] == "player":
                player.draw(surface, static_cam)
            else:
                surface.blit(obj["img"], obj["rect"])

class CircularPortalWorldObject:
    def __init__(self, base_dir):
        self.state = "inactive" # inactive, activating, active, deactivating
        self.x = 0
        self.y = 0
        self.timer = random.uniform(60.0, 180.0) # 1 to 3 minutes spawn interval
        self.active_timer = 0.0
        self.frame_index = 0.0
        self.animations = {"activating": [], "active": [], "deactivating": []}
        
        portal_dir = os.path.join(base_dir, "3D_Assets", "8bit_circular_portal")
        for st in ["activating", "active", "deactivating"]:
            st_dir = os.path.join(portal_dir, st)
            for i in range(8):
                p = os.path.join(st_dir, f"{st}_{i}.png")
                if os.path.exists(p):
                    img = pygame.image.load(p).convert_alpha()
                    img = pygame.transform.scale(img, (96, 96))
                    self.animations[st].append(img)
                    
        self.rect = pygame.Rect(0, 0, 70, 45)

    def spawn(self, player_x, player_y, map_obj=None):
        # Spawn near player on clear open walkable ground, avoiding houses, trees, and solids
        best_x, best_y = None, None
        for _ in range(40):
            angle = random.uniform(0, math.pi * 2)
            dist = random.uniform(140, 280)
            cand_x = int(player_x + math.cos(angle) * dist)
            cand_y = int(player_y + math.sin(angle) * dist)
            cand_rect = pygame.Rect(0, 0, 100, 70)
            cand_rect.center = (cand_x, cand_y)

            collision = False
            if map_obj and hasattr(map_obj, 'objects'):
                for obj in map_obj.objects:
                    if obj.get("type") in ["house", "tree", "bush"] and "rect" in obj:
                        if cand_rect.colliderect(obj["rect"].inflate(60, 60)):
                            collision = True
                            break
            if not collision:
                best_x, best_y = cand_x, cand_y
                break

        if best_x is None:
            best_x = int(player_x + random.choice([-150, 150]))
            best_y = int(player_y + random.choice([100, 150]))

        self.x = best_x
        self.y = best_y
        self.rect.center = (self.x, self.y)
        self.state = "activating"
        self.frame_index = 0.0
        self.active_timer = 45.0 # Stays active for 45s

    def update(self, dt, player_x, player_y, map_obj=None):
        if self.state == "inactive":
            self.timer -= dt
            if self.timer <= 0:
                self.spawn(player_x, player_y, map_obj)
                self.timer = random.uniform(60.0, 180.0) # Reset 1-3 minute timer
            return

        frames = self.animations.get(self.state, [])
        if frames:
            self.frame_index += dt * 10.0
            if self.frame_index >= len(frames):
                if self.state == "activating":
                    self.state = "active"
                    self.frame_index = 0.0
                elif self.state == "active":
                    self.frame_index = 0.0
                elif self.state == "deactivating":
                    self.state = "inactive"
                    self.frame_index = 0.0

        if self.state == "active":
            self.active_timer -= dt
            if self.active_timer <= 0:
                self.state = "deactivating"
                self.frame_index = 0.0

    def draw(self, surface, camera):
        if self.state == "inactive":
            return
        frames = self.animations.get(self.state, [])
        if frames:
            idx = min(int(self.frame_index), len(frames) - 1)
            img = frames[idx]
            draw_rect = img.get_rect(center=(self.x, self.y))
            surface.blit(img, camera.apply_rect(draw_rect))

class DungeonInterior:
    def __init__(self, width, height, base_dir):
        self.width = width
        self.height = height
        self.base_dir = base_dir
        
        # Key, Door, & Chest System State
        self.silver_keys_collected = 0
        self.gold_keys_collected = 0
        self.gold_collected = 0
        self.potions_collected = 0
        self.prompt_text = ""
        self.prompt_timer = 0.0 # Text lasts for 2.0 seconds
        self.e_key_released = True

        # Load dungeon.json map data from TAS_saves or project root
        json_path = os.path.join(base_dir, 'TAS_saves', 'dungeon.json')
        if not os.path.exists(json_path):
            json_path = os.path.join(base_dir, 'dungeon.json')

        self.tiles = []
        if os.path.exists(json_path):
            with open(json_path, 'r') as f:
                self.tiles = json.load(f)

        # Image cache for tile loading
        self.tile_cache = {}
        def load_tile_img(tile_name):
            if tile_name in self.tile_cache:
                return self.tile_cache[tile_name]
            
            folders = [
                os.path.join(base_dir, '3D_Assets', '2D Pixel Dungeon Asset Pack', 'character and tileset', 'Dungeon_Tileset_Split'),
                os.path.join(base_dir, '3D_Assets', '2D Pixel Dungeon Asset Pack', 'character and tileset', 'Dungeon_Character_Split'),
                os.path.join(base_dir, 'furnitures', 'nws', 'sierrassets furniture pack', 'furniture', 'individual sprites')
            ]
            for folder in folders:
                p = os.path.join(folder, tile_name)
                if os.path.exists(p):
                    try:
                        img = pygame.image.load(p).convert_alpha()
                        scaled = pygame.transform.scale(img, (48, 48))
                        self.tile_cache[tile_name] = scaled
                        return scaled
                    except Exception:
                        pass
            return None

        # Animated Asset Frames Loader (items and trap_animation)
        anim_dir = os.path.join(base_dir, '3D_Assets', '2D Pixel Dungeon Asset Pack', 'items and trap_animation')
        
        def load_anim_frames(subfolder, prefix, count):
            frames = []
            for i in range(1, count + 1):
                p1 = os.path.join(anim_dir, subfolder, f"{prefix}_{i}.png")
                p2 = os.path.join(anim_dir, subfolder, f"{prefix}_1_{i}.png")
                path = p1 if os.path.exists(p1) else (p2 if os.path.exists(p2) else None)
                if path and os.path.exists(path):
                    try:
                        img = pygame.image.load(path).convert_alpha()
                        frames.append(pygame.transform.scale(img, (48, 48)))
                    except Exception:
                        pass
            return frames

        self.front_torch_frames = load_anim_frames('torch', 'torch', 4)
        self.side_torch_frames = load_anim_frames('torch', 'side_torch', 4)
        self.candle_frames = load_anim_frames('torch', 'candlestick', 4)
        self.key_anim_frames = load_anim_frames('keys', 'keys', 4)
        self.chest_open_anim_frames = load_anim_frames('mini_chest', 'mini_chest_open', 4)
        self.anim_timer = 0.0

        # Open chest graphic (chest_open_4.png is real open chest sprite!)
        open_chest_path = os.path.join(base_dir, '3D_Assets', '2D Pixel Dungeon Asset Pack', 'items and trap_animation', 'chest', 'chest_open_4.png')
        if os.path.exists(open_chest_path):
            try:
                img = pygame.image.load(open_chest_path).convert_alpha()
                self.open_chest_img = pygame.transform.scale(img, (48, 48))
            except Exception:
                self.open_chest_img = None
        else:
            self.open_chest_img = None

        # Build surface and collision rects from dungeon.json
        if self.tiles:
            min_x = min(t['x'] for t in self.tiles)
            max_x = max(t['x'] for t in self.tiles)
            min_y = min(t['y'] for t in self.tiles)
            max_y = max(t['y'] for t in self.tiles)

            self.map_w = (max_x - min_x) + 48
            self.map_h = (max_y - min_y) + 48
            self.dungeon_surf = pygame.Surface((self.map_w, self.map_h), pygame.SRCALPHA)

            sorted_tiles = sorted(self.tiles, key=lambda t: t.get('layer', 1))
            
            self.solid_rects = []
            self.doors = []
            self.keys = []
            self.chests = []
            self.animated_front_torches = []
            self.animated_side_torches = []
            self.animated_candles = []

            wall_patterns = ['tile_002', 'tile_030', 'tile_035', 'tile_078', 'tile_050', 'tile_053', 'tile_015', 'tile_040', 'tile_055', 'tile_074', 'tile_075', 'tile_076', 'tile_085']
            door_patterns = ['tile_066', 'tile_067', 'tile_037']
            chest_patterns = ['tile_080', 'tile_083', 'tile_084', 'tile_088']
            key_patterns = ['tile_082', 'tile_086', 'tile_087', 'tile_099']

            for t in sorted_tiles:
                nx = t['x'] - min_x
                ny = t['y'] - min_y
                name = t['name']

                img = load_tile_img(name)

                # Classify tile type
                is_wall = any(p in name for p in wall_patterns)
                is_door = any(dp in name for dp in door_patterns)
                is_key = any(kp in name for kp in key_patterns)
                is_chest = any(cp in name for cp in chest_patterns)

                # Pre-render 100% of dungeon.json map tiles to dungeon_surf!
                if img:
                    self.dungeon_surf.blit(img, (nx, ny))

                # Register Interactive Systems & Collisions
                if is_wall:
                    self.solid_rects.append(pygame.Rect(nx, ny, 48, 48))
                elif is_door:
                    # Entrance Double Wooden Doors ('066'/'067') require GOLD Key; Inner Silver Door ('037') requires SILVER Key!
                    door_type = "Gold" if ('066' in name or '067' in name) else "Silver"
                    # Remove any wall solid_rect that occupies the same position (door tile overrides underlying wall)
                    self.solid_rects = [s for s in self.solid_rects if s.topleft != (nx, ny)]
                    self.doors.append({"rect": pygame.Rect(nx, ny, 48, 48), "opened": False, "nx": nx, "ny": ny, "name": name, "img": img, "type": door_type})
                elif is_key:
                    # Key pickup item ('099' is Gold Key at entrance, '082' is Silver Key!)
                    key_type = "Gold" if '099' in name else "Silver"
                    self.keys.append({"rect": pygame.Rect(nx + 8, ny + 8, 32, 32), "picked": False, "nx": nx, "ny": ny, "name": name, "img": img, "type": key_type})
                elif is_chest:
                    # Interactive Chest / Crate / Treasure
                    if '080' in name:
                        loot_type = "Nothing"
                        open_img = load_tile_img('dungeon_tile_082_r8_c2.png') or self.open_chest_img
                    elif '083' in name:
                        loot_type = "GoldKey"
                        open_img = self.open_chest_img
                    elif '088' in name:
                        loot_type = "SilverKey"
                        open_img = self.open_chest_img
                    else:
                        loot_type = "SilverKey" if len(self.chests) % 2 == 0 else "Gold"
                        open_img = self.open_chest_img
                    self.chests.append({"rect": pygame.Rect(nx, ny, 48, 48), "opened": False, "nx": nx, "ny": ny, "open_stage": 0, "loot": loot_type, "name": name, "img": img, "open_img": open_img})

            # Post-pass: remove any solid wall rects that share a position with a door tile.
            # This ensures the underlying wall layer doesn't block passage through an opened door.
            door_positions = {(d["nx"], d["ny"]) for d in self.doors}
            self.solid_rects = [s for s in self.solid_rects if s.topleft not in door_positions]

        else:
            self.map_w = 800
            self.map_h = 600
            self.dungeon_surf = pygame.Surface((800, 600))
            self.dungeon_rect = pygame.Rect(0, 0, 800, 600)
            self.solid_rects = []
            self.doors = []
            self.keys = []
            self.chests = []

        # Floor tile clean image for erasing picked-up items / opened doors (Solid purple floor tile!)
        self.clean_floor = load_tile_img('dungeon_tile_079_r7_c9.png') or load_tile_img('dungeon_tile_078_r7_c8.png')
        if not self.clean_floor:
            self.clean_floor = pygame.Surface((48, 48))
            self.clean_floor.fill((61, 37, 59))

        # Open door sprites dictionary
        self.open_door_imgs = {
            'tile_066': load_tile_img('dungeon_tile_064_r6_c4.png'),
            'tile_067': load_tile_img('dungeon_tile_065_r6_c5.png'),
            'tile_090': load_tile_img('dungeon_tile_093_r9_c3.png'),
            'tile_091': load_tile_img('dungeon_tile_093_r9_c3.png'),
            'tile_092': load_tile_img('dungeon_tile_094_r9_c4.png'),
            'tile_037': load_tile_img('dungeon_tile_035_r3_c5.png') or load_tile_img('dungeon_tile_064_r6_c4.png')
        }

        # Dedicated Dungeon Camera (smooth scrolling to follow player inside dungeon.json)
        self.dungeon_camera = RPGCamera(width, height)
        
        # Audio Timers & States
        self.footstep_timer = 0.0
        self.is_in_air = False
        self.jump_y_offset = 0.0
        self.jump_velocity = 0.0

        # Dungeon Conquest State
        self.dungeon_conquered = False
        self.conquest_timer = 0.0  # Delay before teleporting back to village

    def get_terrain_at(self, x, y):
        """Detects surface terrain type at player position (stone, wood, dirt/grass)."""
        p_rect = pygame.Rect(x - 8, y - 8, 16, 16)
        for s in self.solid_rects:
            if p_rect.inflate(8, 8).colliderect(s):
                return "stone"
        for d in self.doors:
            if p_rect.inflate(8, 8).colliderect(d["rect"]):
                return "wood"
        return "dirt"

    def update_player(self, player, dt, keys, game):
        # Update 2.0s floating prompt timer
        if self.prompt_timer > 0:
            self.prompt_timer -= dt
            
        dx, dy = 0, 0
        is_moving = False
        
        if keys[pygame.K_w]:
            dy -= player.speed * dt
            player.facing = "Up"
            is_moving = True
        elif keys[pygame.K_s]:
            dy += player.speed * dt
            player.facing = "Down"
            is_moving = True
            
        if keys[pygame.K_a]:
            dx -= player.speed * dt
            player.facing = "Left"
            is_moving = True
        elif keys[pygame.K_d]:
            dx += player.speed * dt
            player.facing = "Right"
            is_moving = True

        if is_moving:
            player.action = "Walk"
            player.anim_timer += dt
            if player.anim_timer > 0.1:
                player.anim_timer = 0
                player.frame_index += 1
            
            # Play surface footstep sound every 0.32 seconds
            self.footstep_timer += dt
            if self.footstep_timer >= 0.32:
                self.footstep_timer = 0.0
                terrain = self.get_terrain_at(player.rect.centerx, player.rect.centery)
                sound_mgr.play_footstep(terrain)
        else:
            player.action = "Stand"
            self.footstep_timer = 0.30

        # Jump & Land Audio in Top-Down RPG Mode (SPACE Key)
        is_space_pressed = bool(keys[pygame.K_SPACE]) if (hasattr(keys, '__getitem__') or isinstance(keys, dict)) else False
        if is_space_pressed and not self.is_in_air:
            self.is_in_air = True
            self.jump_velocity = -12.0
            terrain = self.get_terrain_at(player.rect.centerx, player.rect.centery)
            sound_mgr.play_jump(terrain)

        if self.is_in_air:
            self.jump_y_offset += self.jump_velocity
            self.jump_velocity += 1.2
            if self.jump_y_offset >= 0:
                self.jump_y_offset = 0
                self.is_in_air = False
                terrain = self.get_terrain_at(player.rect.centerx, player.rect.centery)
                sound_mgr.play_land(terrain)

        # Check [E] Key Press for Key Pickup, Chest Opening, & Door Interaction
        is_interact = keys[pygame.K_e]
        if game and hasattr(game, 'touch_ctrl') and game.touch_ctrl and game.touch_ctrl.enabled:
            if game.touch_ctrl.was_button_tapped("attack"):
                is_interact = True

        if is_interact:
            if self.e_key_released:
                self.e_key_released = False
                player_reach = player.rect.inflate(64, 64)
                
                # 1. Check Key Pickup (select closest key to player center)
                action_done = False
                unpicked_keys = [k for k in self.keys if not k["picked"] and player_reach.colliderect(k["rect"])]
                if unpicked_keys:
                    unpicked_keys.sort(key=lambda k: (k["rect"].centerx - player.rect.centerx)**2 + (k["rect"].centery - player.rect.centery)**2)
                    k = unpicked_keys[0]
                    k["picked"] = True
                    if k.get("type") == "Gold":
                        self.gold_keys_collected += 1
                        self.prompt_text = f"Picked up Gold Key! [Gold Keys: {self.gold_keys_collected}]"
                    else:
                        self.silver_keys_collected += 1
                        self.prompt_text = f"Picked up Silver Key! [Silver Keys: {self.silver_keys_collected}]"
                    self.prompt_timer = 2.0
                    sound_mgr.play('alert')
                    sound_mgr.play('key')
                    action_done = True
                        
                # 2. Check Chest Opening (must be directly touching the chest!)
                if not action_done:
                    unopened_chests = [c for c in self.chests if not c["opened"] and player_reach.colliderect(c["rect"])]
                    if unopened_chests:
                        unopened_chests.sort(key=lambda c: (c["rect"].centerx - player.rect.centerx)**2 + (c["rect"].centery - player.rect.centery)**2)
                        c = unopened_chests[0]
                        c["opened"] = True
                        sound_mgr.play('alert')
                        sound_mgr.play_chest_open()
                        sound_mgr.play('chest')
                        if c["loot"] in ("Nothing", "Empty"):
                            self.prompt_text = "nothing inside?"
                        elif c["loot"] == "Gold":
                            self.gold_collected += 50
                            self.prompt_text = f"Opened Chest! Found 50 Gold! [Gold: {self.gold_collected}]"
                            sound_mgr.play('gold')
                        elif c["loot"] == "GoldKey":
                            self.gold_keys_collected += 1
                            self.prompt_text = f"Opened Treasure Chest! Found a Gold Key! [Gold Keys: {self.gold_keys_collected}]"
                            sound_mgr.play('key')
                        elif c["loot"] == "SilverKey":
                            self.silver_keys_collected += 1
                            self.prompt_text = f"Opened Treasure Chest! Found a Silver Key! [Silver Keys: {self.silver_keys_collected}]"
                            sound_mgr.play('key')
                        else:
                            self.potions_collected += 1
                            self.prompt_text = f"Opened Lockbox! Found a Health Leaf!"
                            sound_mgr.play('potion')
                        self.prompt_timer = 2.0
                        action_done = True

                # 2b. Check Already Opened Chest (Inspecting an already opened or empty chest)
                if not action_done:
                    opened_chests = [c for c in self.chests if c["opened"] and player_reach.colliderect(c["rect"])]
                    if opened_chests:
                        opened_chests.sort(key=lambda c: (c["rect"].centerx - player.rect.centerx)**2 + (c["rect"].centery - player.rect.centery)**2)
                        c = opened_chests[0]
                        self.prompt_text = "nothing inside?"
                        self.prompt_timer = 2.0
                        sound_mgr.play('alert')
                        action_done = True

                # 3. Check Locked Door Interaction (must be directly touching the door!)
                if not action_done:
                    unopened_doors = [d for d in self.doors if not d["opened"] and player_reach.colliderect(d["rect"])]
                    if unopened_doors:
                        unopened_doors.sort(key=lambda d: (d["rect"].centerx - player.rect.centerx)**2 + (d["rect"].centery - player.rect.centery)**2)
                        d = unopened_doors[0]
                        door_type = d.get("type", "Silver")

                        if door_type == "Gold":
                            if self.gold_keys_collected == 0:
                                self.prompt_text = "I see that this door needs a Gold one?"
                                self.prompt_timer = 2.0
                                sound_mgr.play('alert')
                                sound_mgr.play('door_locked')
                            else:
                                d["opened"] = True
                                # Also open adjacent paired entrance double door tile
                                for d_other in self.doors:
                                    if not d_other["opened"] and d_other.get("type") == "Gold":
                                        if abs(d_other["nx"] - d["nx"]) <= 48 and abs(d_other["ny"] - d["ny"]) <= 48:
                                            d_other["opened"] = True
                                self.gold_keys_collected -= 1
                                self.prompt_text = f"You unlocked the double doors with a Gold Key! [Gold Keys: {self.gold_keys_collected}]"
                                self.prompt_timer = 2.0
                                sound_mgr.play('alert')
                                sound_mgr.play_door_open()
                        else:
                            if self.silver_keys_collected == 0:
                                self.prompt_text = "I see that this door needs a Silver one?"
                                self.prompt_timer = 2.0
                                sound_mgr.play('alert')
                                sound_mgr.play('door_locked')
                            else:
                                d["opened"] = True
                                self.silver_keys_collected -= 1
                                self.prompt_text = f"You unlocked the door with a Silver Key! [Silver Keys: {self.silver_keys_collected}]"
                                self.prompt_timer = 2.0
                                sound_mgr.play('alert')
                                sound_mgr.play_door_open()
        else:
            self.e_key_released = True

        # Solid obstacles (includes unopened locked doors and chests)
        active_solids = self.solid_rects.copy()
        for d in self.doors:
            if not d["opened"]:
                active_solids.append(d["rect"])
        for c in self.chests:
            active_solids.append(c["rect"])

        # Horizontal Collision
        new_rect = player.rect.copy()
        new_rect.x += dx
        player_hitbox = pygame.Rect(new_rect.x + 16, new_rect.bottom - 20, 32, 16)
        
        collision = False
        for obs in active_solids:
            if player_hitbox.colliderect(obs):
                collision = True
                break
        if not collision:
            player.rect.x = new_rect.x

        # Vertical Collision
        new_rect = player.rect.copy()
        new_rect.y += dy
        player_hitbox = pygame.Rect(new_rect.x + 16, new_rect.bottom - 20, 32, 16)
        
        collision = False
        for obs in active_solids:
            if player_hitbox.colliderect(obs):
                collision = True
                break
        if not collision:
            player.rect.y = new_rect.y

        # Update Dungeon Camera to follow player smoothly across 100% of dungeon map width and height!
        self.dungeon_camera.update(player.rect, dt, max_w=self.map_w, max_h=self.map_h)

        # Check if player walks through the opened LAST DOUBLE DOOR (tile_066 / tile_067 at ny < 300) - Dungeon Conquered!
        if not self.dungeon_conquered:
            final_double_doors = [d for d in self.doors if ('066' in d.get("name", "") or '067' in d.get("name", "")) and d.get("ny", 0) < 300]
            if final_double_doors:
                if any(d["opened"] for d in final_double_doors):
                    door_zone = pygame.Rect(400, 160, 130, 90)
                    player_center = pygame.Rect(player.rect.centerx - 8, player.rect.centery - 8, 16, 16)
                    if door_zone.colliderect(player_center):
                        self.dungeon_conquered = True
                        self.conquest_timer = 2.5
                        self.prompt_text = "You Conquered The Dungeon And Took The Loots Inside the dungeons!"
                        self.prompt_timer = 2.5
                        sound_mgr.play('alert')
                        sound_mgr.play('conquest')

        # Count down conquest timer -> trigger exit back to village
        if self.dungeon_conquered and self.conquest_timer > 0:
            self.conquest_timer -= dt
            if self.conquest_timer <= 0:
                self.conquest_timer = 0
                if hasattr(game, 'trigger_dungeon_conquered_exit'):
                    game.trigger_dungeon_conquered_exit()

    def draw(self, surface, player, game):
        # Draw background dark vignette
        surface.fill((10, 8, 15))
        
        # Apply camera offset to dungeon map surface (renders 100% of dungeon.json faithfully!)
        cam_map_rect = self.dungeon_camera.apply_rect(pygame.Rect(0, 0, self.map_w, self.map_h))
        surface.blit(self.dungeon_surf, cam_map_rect.topleft)
        pygame.draw.rect(surface, (80, 40, 20), cam_map_rect, 4, border_radius=6)

        # Erase picked up keys
        for k in self.keys:
            if k["picked"]:
                r = self.dungeon_camera.apply_rect(pygame.Rect(k["nx"], k["ny"], 48, 48))
                surface.blit(self.clean_floor, r.topleft)

        # Erase opened doors completely!
        for d in self.doors:
            if d["opened"]:
                r = self.dungeon_camera.apply_rect(pygame.Rect(d["nx"], d["ny"], 48, 48))
                surface.blit(self.clean_floor, r.topleft)

        # Draw open chest graphic when opened (erases closed chest tile & blits real open chest sprite!)
        for c in self.chests:
            if c["opened"]:
                r = self.dungeon_camera.apply_rect(pygame.Rect(c["nx"], c["ny"], 48, 48))
                surface.blit(self.clean_floor, r.topleft)
                open_img = c.get("open_img") or getattr(self, 'open_chest_img', None)
                if open_img:
                    surface.blit(open_img, r.topleft)

        # Draw Player with Dungeon Camera (including top-down jump hop visual!)
        if self.jump_y_offset != 0:
            player.rect.y += int(self.jump_y_offset)
            player.draw(surface, self.dungeon_camera)
            player.rect.y -= int(self.jump_y_offset)
        else:
            player.draw(surface, self.dungeon_camera)

        # Draw UI prompt for dungeon exit
        font = get_rpg_font(12, bold=True)
        # Draw HUD Player Healthbar (Top Left)
        hp_bar_x = 20
        hp_bar_y = 16
        hp_bar_w = 160
        hp_bar_h = 14
        pygame.draw.rect(surface, (0, 0, 0), (hp_bar_x - 3, hp_bar_y - 3, hp_bar_w + 6, hp_bar_h + 6), border_radius=5)
        pygame.draw.rect(surface, (28, 18, 12), (hp_bar_x - 2, hp_bar_y - 2, hp_bar_w + 4, hp_bar_h + 4), border_radius=4)
        pygame.draw.rect(surface, (55, 20, 20), (hp_bar_x, hp_bar_y, hp_bar_w, hp_bar_h), border_radius=3)
        hp_ratio = max(0.0, min(1.0, player.hp / float(player.max_hp)))
        fill_hp_w = int(hp_bar_w * hp_ratio)
        if fill_hp_w > 0:
            bar_c = (46, 204, 113) if hp_ratio > 0.5 else ((243, 156, 18) if hp_ratio > 0.25 else (231, 76, 60))
            top_c = (120, 240, 160) if hp_ratio > 0.5 else ((255, 210, 110) if hp_ratio > 0.25 else (255, 130, 120))
            pygame.draw.rect(surface, bar_c, (hp_bar_x, hp_bar_y, fill_hp_w, hp_bar_h), border_radius=2)
            pygame.draw.rect(surface, top_c, (hp_bar_x, hp_bar_y, fill_hp_w, max(1, hp_bar_h // 3)), border_radius=2)
        pygame.draw.rect(surface, (255, 215, 80), (hp_bar_x - 1, hp_bar_y - 1, hp_bar_w + 2, hp_bar_h + 2), 1, border_radius=3)
        font_hp = get_rpg_font(9, bold=True)
        hp_str = f"HP: {int(player.hp)} / {int(player.max_hp)}"
        hp_txt = font_hp.render(hp_str, True, (255, 255, 255))
        surface.blit(hp_txt, (hp_bar_x + hp_bar_w // 2 - hp_txt.get_width() // 2, hp_bar_y + 1))

        # Draw HUD Keys & Gold Counter (Top Left)
        hud_str = f"Silver Keys : {self.silver_keys_collected} | Gold Keys : {self.gold_keys_collected} | Gold : {self.gold_collected}"
        key_hud = font.render(hud_str, False, (255, 220, 80))
        key_bg = pygame.Rect(14, 38, key_hud.get_width() + 12, key_hud.get_height() + 6)
        pygame.draw.rect(surface, (0, 0, 0, 180), key_bg, border_radius=4)
        pygame.draw.rect(surface, (140, 100, 40), key_bg, 1, border_radius=4)
        surface.blit(key_hud, (20, 41))

        # Draw Floating 2.0s Prompt Text (Top Center Notification)
        if self.prompt_timer > 0 and self.prompt_text:
            font_prompt = get_rpg_font(14, bold=True)
            txt = font_prompt.render(self.prompt_text, False, (255, 230, 90))
            box = txt.get_rect(center=(self.width // 2, 45)).inflate(30, 16)
            
            pygame.draw.rect(surface, (0, 0, 0), box.move(3, 3))
            pygame.draw.rect(surface, (20, 20, 30), box)
            pygame.draw.rect(surface, (255, 255, 255), box, 1)
            surface.blit(txt, txt.get_rect(center=(self.width // 2, 45)))

        # Draw UI control prompt at bottom center
        exit_prompt = font.render("PRESS [ESC] TO EXIT DUNGEON | PRESS [E] TO PICKUP / OPEN CHEST / OPEN DOOR", False, (240, 240, 240))
        ep_rect = exit_prompt.get_rect(center=(self.width // 2, self.height - 20))
        ep_bg = ep_rect.inflate(16, 6)
        pygame.draw.rect(surface, (0, 0, 0, 180), ep_bg, border_radius=4)
        pygame.draw.rect(surface, (100, 80, 50), ep_bg, 1, border_radius=4)
        surface.blit(exit_prompt, ep_rect)

        # Draw DUNGEON CONQUERED full-screen overlay!
        if self.dungeon_conquered:
            overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 140))
            surface.blit(overlay, (0, 0))
            font_big = get_rpg_font(22, bold=True)
            font_sub = get_rpg_font(13, bold=True)
            msg1 = font_big.render("*  DUNGEON CONQUERED!  *", True, (255, 230, 90))
            msg2 = font_sub.render("You Conquered The Dungeon And Took The Loots Inside the dungeons!", True, (255, 255, 200))
            msg3 = font_sub.render("Returning to village...", True, (200, 220, 255))
            cx = self.width // 2
            cy = self.height // 2
            box_w = max(msg1.get_width(), msg2.get_width()) + 60
            box_h = 120
            box = pygame.Rect(cx - box_w // 2, cy - box_h // 2, box_w, box_h)
            pygame.draw.rect(surface, (20, 15, 5), box, border_radius=10)
            pygame.draw.rect(surface, (255, 215, 0), box, 3, border_radius=10)
            surface.blit(msg1, msg1.get_rect(centerx=cx, top=box.top + 14))
            surface.blit(msg2, msg2.get_rect(centerx=cx, top=box.top + 52))
            surface.blit(msg3, msg3.get_rect(centerx=cx, top=box.top + 80))

    @property
    def keys_collected(self):
        return self.silver_keys_collected

    @keys_collected.setter
    def keys_collected(self, val):
        self.silver_keys_collected = val

# --- INTERNATIONAL WORLD SOCIAL STUDIES CURRICULUM DATA ---
GLOBAL_SOCIAL_STUDIES_DATA = {
    "currency": {
        "title": "The Evolution of Currency",
        "category": "World Economic History",
        "era": "c. 600 BCE - Classical Antiquity",
        "icon_file": "14.png",
        "trigger": "Inspect or collect Ancient Gold Coins in your satchel.",
        "curriculum": (
            "Early human societies initially relied on barter and commodity money (salt, grain, livestock). "
            "Around 600 BCE, ancient Lydia, Greece, and China minted the first standardized coins of electrum, "
            "gold, and bronze. This eliminated the 'coincidence of wants' dilemma, establishing universally "
            "accepted currency that powered transcontinental Silk Road and Maritime trade networks."
        ),
        "in_game": (
            "The Ancient Gold Coins in your satchel reflect this milestone. Standardized metallic money "
            "enables international trade between travelers, blacksmiths, and merchants across distant realms."
        )
    },
    "ethnobotany": {
        "title": "Ethnobotany & Natural Healing",
        "category": "Indigenous Science & Medicine",
        "era": "Ancient Civilizations - Pre-Modern Era",
        "icon_file": "25.png",
        "trigger": "Discover, collect, or consume a medicinal Health Leaf.",
        "curriculum": (
            "Before synthetic pharmacology, global civilizations depended on ethnobotany - the traditional "
            "knowledge of medicinal plants. Indigenous cultures in the Americas, Africa, and Asia cataloged "
            "analgesic and antibacterial herbs (such as willow bark, which led to modern aspirin). Indigenous "
            "botanical knowledge remains a primary pillar of global scientific discovery."
        ),
        "in_game": (
            "The Health Leaf is an indigenous forest herb. When consumed, its natural restorative properties "
            "soothe combat fatigue and restore 50 HP."
        )
    },
    "agrarian": {
        "title": "Agrarian Geography & Food Security",
        "category": "Human Geography & Settlement",
        "era": "Neolithic Revolution (c. 10,000 BCE)",
        "icon_file": "22.png",
        "trigger": "Carry, cook, or consume Steak or Fresh River Trout.",
        "curriculum": (
            "The shift from foraging to permanent settlements required stable protein reserves. River "
            "valley civilizations (Nile, Indus, Tigris-Euphrates, Yangtze) flourished because freshwater "
            "fisheries and livestock domestication provided concentrated calories and transport, generating "
            "the economic surplus needed for urban civilization to rise."
        ),
        "in_game": (
            "Fresh River Trout and hearty Steaks serve as vital food rations, replenishing stamina and HP "
            "during long expeditions across unexplored wilderness."
        )
    },
    "architecture": {
        "title": "Vernacular Architecture & Climate",
        "category": "Environmental Adaptation & Shelter",
        "era": "Traditional World Civilizations",
        "icon_file": "house",
        "trigger": "Step inside and inspect the traditional timber Wooden House.",
        "curriculum": (
            "Vernacular architecture demonstrates how human builders adapt to regional climates without "
            "mechanical energy. Traditional timber stilt dwellings (common across tropical Asia, the Pacific, "
            "and Amazonia) use elevated piles to prevent monsoon flood damage and deter wildlife, while slatted "
            "timber walls maximize passive convective airflow in hot, humid climates."
        ),
        "in_game": (
            "The village wooden house is engineered with timber framing, raised floors, and cross-ventilation, "
            "offering safe shelter from torrential storms and nocturnal predators."
        )
    },
    "archaeology": {
        "title": "Archaeology & Fortifications",
        "category": "World History & Security Engineering",
        "era": "Bronze Age - Medieval Civilizations",
        "icon_file": "dungeon",
        "trigger": "Enter the ancient Dungeon ruins or unlock a reinforced door with a key.",
        "curriculum": (
            "As civic wealth concentrated in early cities, societies engineered monumental stone masonry and "
            "mechanical locks. The earliest pin-tumbler locks originated in ancient Egypt and Mesopotamia over "
            "4,000 years ago. Archaeologists study subterranean vaults, fortifications, and key mechanisms to "
            "reconstruct ancient defense tactics and social organization."
        ),
        "in_game": (
            "The ancient Dungeon features subterranean stone vaults, iron-bound chests, and double-keyed security "
            "doors protecting forgotten historical treasures."
        )
    },
    "music": {
        "title": "Classical Music & Equal Temperament",
        "category": "Universal Cultural Heritage",
        "era": "1700 - 1824 CE (Classical Era)",
        "icon_file": "piano",
        "trigger": "Interact with and perform on the Retro Piano.",
        "curriculum": (
            "In 1700, Italian inventor Bartolomeo Cristofori created the pianoforte, enabling dynamic expressive "
            "touch (soft to loud). Combined with the 12-tone equal temperament scale, the piano became a universal "
            "musical standard across all continents. Beethoven's 'Ode to Joy' (1824) stands as a global anthem "
            "of human brotherhood, enshrined in the UNESCO Memory of the World Register."
        ),
        "in_game": (
            "The playable Piano features 61 QWERTY keys, 3 pedals, and guided sheet music for Beethoven's "
            "Ode to Joy to celebrate universal world music."
        )
    },
    "climatology": {
        "title": "Equatorial Climatology & Monsoons",
        "category": "Physical Geography & Earth Systems",
        "era": "Global Atmospheric Dynamics",
        "icon_file": "weather",
        "trigger": "Experience the outdoor day/night cycle or shifting rain and thunderstorm weather.",
        "curriculum": (
            "Equatorial weather is driven by solar radiation and the Intertropical Convergence Zone (ITCZ). "
            "Differential heating between oceans and landmasses causes seasonal monsoon wind reversals, alternating "
            "between dry periods and torrential downpours. Historically, these atmospheric cycles dictated world "
            "maritime trade voyages and agricultural planting seasons."
        ),
        "in_game": (
            "The dynamic weather engine simulates real-time Clear, Cloudy, Rain, and Thunderstorm conditions "
            "alongside Day/Night illumination cycles affecting travel visibility."
        )
    },
    "mineralogy": {
        "title": "Mineralogy & Crystal Lattices",
        "category": "Earth & Physical Science",
        "era": "Geological Formations",
        "icon_file": "diamond_gem.png",
        "trigger": "Mine natural field boulders or subterranean gemstone deposits.",
        "curriculum": (
            "Mineralogy is the branch of geology specializing in the scientific study of chemistry, crystal "
            "structure, and physical properties of minerals. Diamonds exhibit face-centered cubic carbon lattices "
            "resulting in extreme hardness (10 on Mohs scale), while rubies are crystalline corundum (Al2O3) colored "
            "red by chromium ions. Coal is an organic sedimentary rock composed primarily of carbon formed from prehistoric peat."
        ),
        "in_game": (
            "Mining natural field boulders and ore veins yields rocks, coal lumps, raw iron ore, rubies, and diamonds "
            "used in metallurgical crafting."
        )
    },
    "metallurgy": {
        "title": "Metallurgy & Smelting Chemistry",
        "category": "Chemical Science & Thermodynamics",
        "era": "Bronze Age to Modern Metallurgy",
        "icon_file": "iron_ingot.png",
        "trigger": "Commission the village Master Blacksmith to smelt raw ores into ingots.",
        "curriculum": (
            "Metallurgy is the domain of materials science that studies the physical and chemical behavior of "
            "metallic elements and compounds. Smelting uses heat and chemical reducing agents (such as carbon monoxide "
            "from coal combustion) to decompose raw ore: Fe2O3 + 3CO -> 2Fe + 3CO2. This reduces metal oxides into "
            "pure elemental metallic iron ingots suitable for forging tools and weapons."
        ),
        "in_game": (
            "The master blacksmith operates high-temperature furnaces, converting raw iron and gems into forged "
            "ingots and polished jewelry for a fee of 4-12 gold."
        )
    },
    "ecology": {
        "title": "Trophic Levels & Forest Ecology",
        "category": "Life Science & Biology",
        "era": "Ecological Food Webs",
        "icon_file": "raw_meat.png",
        "trigger": "Defeat wild bears in the forest to harvest high-protein raw game meat.",
        "curriculum": (
            "Ecological food webs describe the flow of matter and metabolic energy through ecosystems across discrete "
            "trophic levels: primary producers (plants and trees), primary consumers (herbivores), and apex secondary/tertiary "
            "consumers (wild bears). Only approximately 10% of energy is transferred between trophic levels, making apex predators "
            "vital regulators of ecosystem balance."
        ),
        "in_game": (
            "Bears roam the wilderness as apex predators. Harvesting raw bear meat provides concentrated protein that can "
            "be campfire-cooked with coal to restore 45 HP."
        )
    },
    "cellulose": {
        "title": "Cellulose & Plant Biopolymers",
        "category": "Organic Chemistry & Botany",
        "era": "Plant Structural Evolution",
        "icon_file": "wood_log.png",
        "trigger": "Harvest wood logs by cutting forest trees with your sword.",
        "curriculum": (
            "Cellulose is an organic polysaccharide compound with formula (C6H10O5)n, consisting of a linear chain of "
            "several hundred to many thousands of beta-linked D-glucose units. It is the most abundant organic polymer on Earth, "
            "forming the structural cell walls of green plants. Paired with lignin, cellulose confers extraordinary tensile "
            "strength to tree trunks, enabling vertical forest growth."
        ),
        "in_game": (
            "Cutting trees yields sturdy Wood Logs rich in cellulose fibers, which can be refined on your 3x3 Field Workbench "
            "crafting grid into planks, tool handles, and specialized survival tools."
        )
    }
}

def wrap_codex_text(text, font, max_w):
    lines = []
    for para in text.split("\n"):
        if not para:
            lines.append("")
            continue
        words = para.split(" ")
        cur = []
        for w in words:
            if font.size(" ".join(cur + [w]))[0] <= max_w:
                cur.append(w)
            else:
                if cur:
                    lines.append(" ".join(cur))
                cur = [w]
        if cur:
            lines.append(" ".join(cur))
    return lines

def draw_codex_star(surface, color, center, radius):
    points = []
    for i in range(10):
        angle = i * math.pi / 5 - math.pi / 2
        r = radius if i % 2 == 0 else radius * 0.45
        points.append((center[0] + r * math.cos(angle), center[1] + r * math.sin(angle)))
    pygame.draw.polygon(surface, color, points)

class WorldSocialStudiesCodexUI:
    def __init__(self, width, height, base_dir):
        self.width = width
        self.height = height
        self.base_dir = base_dir
        self.active = False
        self.just_opened = False
        self.selected_key = "currency"
        self.tab_rects = {}
        self.close_btn_rect = None

        self.font_title = get_rpg_font(18, bold=True, name="georgia")
        self.font_sub = get_rpg_font(11, bold=True, name="georgia")
        self.font_tab = get_rpg_font(11, bold=True)
        self.font_body = get_rpg_font(11, bold=False, name="georgia")
        self.font_seal = get_rpg_font(10, bold=True, name="georgia")
        self.font_tag = get_rpg_font(9, bold=True)

    def open(self):
        self.active = True
        self.just_opened = True

    def close(self):
        self.active = False
        self.just_opened = False

    def update(self, dt, events):
        if not self.active:
            return False

        if getattr(self, 'just_opened', False):
            self.just_opened = False
            active_events = [e for e in events if e.type != pygame.KEYDOWN]
        else:
            active_events = events

        bw, bh = 780, 510
        bx = (self.width - bw) // 2
        by = (self.height - bh) // 2
        book_rect = pygame.Rect(bx, by, bw, bh)

        keys_list = list(GLOBAL_SOCIAL_STUDIES_DATA.keys())

        for event in active_events:
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_ESCAPE, pygame.K_j):
                    self.active = False
                    return True
                elif event.key == pygame.K_UP:
                    idx = keys_list.index(self.selected_key) if self.selected_key in keys_list else 0
                    self.selected_key = keys_list[(idx - 1) % len(keys_list)]
                    sound_mgr.play('text_blip')
                    return True
                elif event.key == pygame.K_DOWN:
                    idx = keys_list.index(self.selected_key) if self.selected_key in keys_list else 0
                    self.selected_key = keys_list[(idx + 1) % len(keys_list)]
                    sound_mgr.play('text_blip')
                    return True
                elif pygame.K_1 <= event.key <= pygame.K_7:
                    num = event.key - pygame.K_1
                    if num < len(keys_list):
                        self.selected_key = keys_list[num]
                        sound_mgr.play('text_blip')
                        return True
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mx, my = event.pos
                if self.close_btn_rect and self.close_btn_rect.collidepoint(mx, my):
                    self.active = False
                    return True
                for k, tr in self.tab_rects.items():
                    if tr.collidepoint(mx, my):
                        self.selected_key = k
                        sound_mgr.play('text_blip')
                        return True
                if not book_rect.collidepoint(mx, my):
                    self.active = False
                    return True
        return True

    def draw(self, surface, discoveries):
        if not self.active:
            return

        dim = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        dim.fill((0, 0, 0, 185))
        surface.blit(dim, (0, 0))

        bw = 780
        bh = 510
        bx = (self.width - bw) // 2
        by = (self.height - bh) // 2

        # 1. Outer Leather Binding
        book_rect = pygame.Rect(bx, by, bw, bh)
        pygame.draw.rect(surface, (36, 20, 12), book_rect, border_radius=12)
        pygame.draw.rect(surface, (180, 130, 45), book_rect, 4, border_radius=12)
        pygame.draw.rect(surface, (90, 50, 25), book_rect.inflate(-8, -8), 2, border_radius=10)

        # Center spine & silk ribbon
        spine_w = 24
        spine_x = bx + bw // 2 - spine_w // 2
        pygame.draw.rect(surface, (24, 14, 8), (spine_x, by + 4, spine_w, bh - 8))
        pygame.draw.line(surface, (160, 110, 40), (bx + bw // 2, by + 6), (bx + bw // 2, by + bh - 6), 2)
        
        ribbon_x = bx + bw // 2 - 4
        pygame.draw.rect(surface, (180, 30, 30), (ribbon_x, by, 8, bh + 18))
        pygame.draw.polygon(surface, (180, 30, 30), [(ribbon_x, by + bh + 18), (ribbon_x + 8, by + bh + 18), (ribbon_x + 4, by + bh + 10)])

        # 2. Pages
        page_pad = 14
        pw = (bw - spine_w) // 2 - page_pad * 2
        ph = bh - page_pad * 2

        p1_rect = pygame.Rect(bx + page_pad, by + page_pad, pw, ph)
        p2_rect = pygame.Rect(bx + bw // 2 + spine_w // 2 + page_pad, by + page_pad, pw, ph)

        for pr in (p1_rect, p2_rect):
            pygame.draw.rect(surface, (246, 238, 218), pr, border_radius=6)
            pygame.draw.rect(surface, (200, 185, 155), pr, 2, border_radius=6)

        # Close [X] Button
        self.close_btn_rect = pygame.Rect(p2_rect.right - 28, p2_rect.y + 8, 22, 22)
        pygame.draw.rect(surface, (180, 40, 40), self.close_btn_rect, border_radius=4)
        x_lbl = self.font_tag.render("X", True, (255, 255, 255))
        surface.blit(x_lbl, x_lbl.get_rect(center=self.close_btn_rect.center))

        # --- LEFT PAGE: Index, Progress & Achievement Seal ---
        t_surf = self.font_title.render("WORLD CODEX", True, (45, 25, 15))
        surface.blit(t_surf, (p1_rect.x + 14, p1_rect.y + 12))
        sub_surf = self.font_tag.render("SCIENCE & SOCIAL STUDIES DISCOVERY JOURNAL", True, (140, 90, 40))
        surface.blit(sub_surf, (p1_rect.x + 14, p1_rect.y + 36))

        total = len(GLOBAL_SOCIAL_STUDIES_DATA)
        unlocked_cnt = len([k for k in GLOBAL_SOCIAL_STUDIES_DATA if k in discoveries])
        pct = int((unlocked_cnt / total) * 100)

        prog_txt = self.font_tag.render(f"CURRICULUM DISCOVERY: {unlocked_cnt} / {total} ({pct}%)", True, (60, 35, 20))
        surface.blit(prog_txt, (p1_rect.x + 14, p1_rect.y + 54))

        bar_w = pw - 28
        bar_h = 10
        bar_x = p1_rect.x + 14
        bar_y = p1_rect.y + 70
        pygame.draw.rect(surface, (215, 195, 165), (bar_x, bar_y, bar_w, bar_h), border_radius=5)
        fill_w = max(4, int(bar_w * (unlocked_cnt / total)))
        pygame.draw.rect(surface, (215, 160, 30), (bar_x, bar_y, fill_w, bar_h), border_radius=5)
        pygame.draw.rect(surface, (120, 80, 30), (bar_x, bar_y, bar_w, bar_h), 1, border_radius=5)

        tab_y = bar_y + 14
        tab_keys = list(GLOBAL_SOCIAL_STUDIES_DATA.keys())
        avail_h = (p1_rect.bottom - 64) - tab_y
        tab_spacing = 2
        tab_h = max(22, min(30, (avail_h // len(tab_keys)) - tab_spacing))
        self.tab_rects.clear()

        for idx, key in enumerate(tab_keys):
            data = GLOBAL_SOCIAL_STUDIES_DATA[key]
            is_unlocked = key in discoveries
            is_selected = key == self.selected_key

            tr = pygame.Rect(p1_rect.x + 10, tab_y + idx * (tab_h + tab_spacing), pw - 20, tab_h)
            self.tab_rects[key] = tr

            if is_selected:
                t_bg = (235, 205, 145)
                t_border = (160, 100, 30)
                t_bwidth = 2
            else:
                t_bg = (240, 230, 205) if is_unlocked else (225, 215, 195)
                t_border = (190, 170, 140) if is_unlocked else (175, 160, 140)
                t_bwidth = 1

            pygame.draw.rect(surface, t_bg, tr, border_radius=5)
            pygame.draw.rect(surface, t_border, tr, t_bwidth, border_radius=5)

            badge_h = min(22, tab_h - 4)
            badge_rect = pygame.Rect(tr.x + 4, tr.y + (tab_h - badge_h) // 2, badge_h, badge_h)
            if is_unlocked:
                pygame.draw.rect(surface, (45, 130, 60), badge_rect, border_radius=4)
                chk = self.font_tag.render("OK", True, (255, 255, 255))
                surface.blit(chk, chk.get_rect(center=badge_rect.center))
            else:
                pygame.draw.rect(surface, (110, 100, 90), badge_rect, border_radius=4)
                lck = self.font_tag.render("?", True, (230, 220, 210))
                surface.blit(lck, lck.get_rect(center=badge_rect.center))

            title_color = (40, 25, 15) if is_unlocked else (120, 110, 100)
            title_str = f"{idx+1}. {data['title']}" if is_unlocked else f"{idx+1}. [Locked Topic]"
            tab_font = self.font_tab
            if tab_font.size(title_str)[0] > tr.width - 38:
                tab_font = get_rpg_font(10, bold=True)
            t_render = tab_font.render(title_str, True, title_color)
            surface.blit(t_render, (tr.x + badge_h + 8, tr.y + 2))

            cat_str = data["category"] if is_unlocked else "Explore the world to discover"
            c_render = self.font_tag.render(cat_str, True, (130, 90, 40) if is_unlocked else (140, 130, 120))
            surface.blit(c_render, (tr.x + badge_h + 8, tr.y + tab_h - 13))

        # GRAND ACHIEVEMENT SEAL (Rendered at bottom of left page if 7/7 complete!)
        if unlocked_cnt == total:
            seal_rect = pygame.Rect(p1_rect.x + 12, p1_rect.bottom - 58, pw - 24, 48)
            pygame.draw.rect(surface, (28, 20, 10), seal_rect, border_radius=7)
            pygame.draw.rect(surface, (255, 215, 60), seal_rect, 2, border_radius=7)
            
            draw_codex_star(surface, (255, 225, 90), (seal_rect.x + 20, seal_rect.centery), 8)
            draw_codex_star(surface, (255, 225, 90), (seal_rect.right - 20, seal_rect.centery), 8)

            star_lbl = self.font_title.render("CERTIFIED GLOBAL SCHOLAR", True, (255, 225, 90))
            sub_lbl = self.font_seal.render("100% World Social Studies Curriculum Mastered", True, (240, 230, 200))
            surface.blit(star_lbl, star_lbl.get_rect(center=(seal_rect.centerx, seal_rect.y + 15)))
            surface.blit(sub_lbl, sub_lbl.get_rect(center=(seal_rect.centerx, seal_rect.y + 34)))

        # --- RIGHT PAGE: In-Depth Curriculum & Lore Content ---
        curr_key = self.selected_key
        curr_data = GLOBAL_SOCIAL_STUDIES_DATA[curr_key]
        is_curr_unlocked = curr_key in discoveries

        if is_curr_unlocked:
            cat_txt = self.font_tag.render(f"CURRICULUM STRAND: {curr_data['category'].upper()}", True, (160, 90, 30))
            surface.blit(cat_txt, (p2_rect.x + 16, p2_rect.y + 14))

            # Dynamic font sizing to ensure title never exceeds page width or touches [X] button
            t_font = self.font_title
            max_title_w = pw - 52
            if t_font.size(curr_data["title"])[0] > max_title_w:
                t_font = get_rpg_font(15, bold=True, name="georgia")
            if t_font.size(curr_data["title"])[0] > max_title_w:
                t_font = get_rpg_font(13, bold=True, name="georgia")

            t2_txt = t_font.render(curr_data["title"], True, (35, 20, 10))
            surface.blit(t2_txt, (p2_rect.x + 16, p2_rect.y + 28))

            era_txt = self.font_tag.render(f"Historical Era: {curr_data['era']}", True, (120, 80, 40))
            surface.blit(era_txt, (p2_rect.x + 16, p2_rect.y + 54))

            pygame.draw.line(surface, (190, 160, 120), (p2_rect.x + 16, p2_rect.y + 70), (p2_rect.right - 16, p2_rect.y + 70), 2)

            sec1_hdr = get_rpg_font(10, bold=True, name="georgia").render("GLOBAL HISTORICAL & GEOGRAPHICAL SIGNIFICANCE:", True, (130, 60, 20))
            surface.blit(sec1_hdr, (p2_rect.x + 16, p2_rect.y + 78))

            curr_lines = wrap_codex_text(curr_data["curriculum"], self.font_body, pw - 36)
            y_off = p2_rect.y + 98
            for l in curr_lines:
                lr = self.font_body.render(l, True, (40, 28, 18))
                surface.blit(lr, (p2_rect.x + 16, y_off))
                y_off += 16

            y_off += 8
            pygame.draw.line(surface, (215, 195, 165), (p2_rect.x + 16, y_off), (p2_rect.right - 16, y_off), 1)
            y_off += 6

            sec2_hdr = get_rpg_font(10, bold=True, name="georgia").render("EXPLORATION REFLECTION IN-GAME:", True, (50, 110, 40))
            surface.blit(sec2_hdr, (p2_rect.x + 16, y_off))
            y_off += 18

            game_lines = wrap_codex_text(curr_data["in_game"], self.font_body, pw - 36)
            for l in game_lines:
                lr = self.font_body.render(l, True, (35, 25, 18))
                surface.blit(lr, (p2_rect.x + 16, y_off))
                y_off += 16

        else:
            lock_box = pygame.Rect(p2_rect.x + 20, p2_rect.y + 40, pw - 40, 120)
            pygame.draw.rect(surface, (235, 220, 195), lock_box, border_radius=8)
            pygame.draw.rect(surface, (160, 140, 110), lock_box, 2, border_radius=8)

            l_txt = self.font_title.render("DISCOVERY RECORD LOCKED", True, (90, 70, 50))
            surface.blit(l_txt, l_txt.get_rect(center=(lock_box.centerx, lock_box.y + 35)))
            l_sub = self.font_sub.render("This historical topic has not yet been uncovered.", True, (130, 110, 85))
            surface.blit(l_sub, l_sub.get_rect(center=(lock_box.centerx, lock_box.y + 70)))

            clue_box = pygame.Rect(p2_rect.x + 20, lock_box.bottom + 20, pw - 40, 150)
            pygame.draw.rect(surface, (240, 230, 210), clue_box, border_radius=8)
            pygame.draw.rect(surface, (190, 150, 80), clue_box, 2, border_radius=8)

            c_hdr = self.font_sub.render("RESEARCH INQUIRY CLUE:", True, (160, 90, 30))
            surface.blit(c_hdr, (clue_box.x + 16, clue_box.y + 16))

            clue_lines = wrap_codex_text(f"To unlock this record:\n{curr_data['trigger']}", self.font_body, clue_box.width - 32)
            cy_off = clue_box.y + 42
            for cl in clue_lines:
                clr = self.font_body.render(cl, True, (45, 30, 15))
                surface.blit(clr, (clue_box.x + 16, cy_off))
                cy_off += 20

        close_txt = self.font_tag.render("[ESC] / [J] Close Codex   *   Click left index to select topic", True, (210, 190, 150))
        surface.blit(close_txt, close_txt.get_rect(center=(bx + bw // 2, by + bh + 14)))

# --- RPG INVENTORY & FIELD CRAFTING WORKBENCH UI ---
class RPGInventoryUI:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.active = False
        self.panel_w = 720
        self.panel_h = 490
        self.font_title = get_rpg_font(15, bold=True)
        self.font_sub = get_rpg_font(11, bold=True)
        self.font_qty = get_rpg_font(11, bold=True)
        self.font_desc = get_rpg_font(11, bold=True)
        self.font_btn = get_rpg_font(10, bold=True)

        self.items = [
            self.load_item("1.png", 1, "Book", "An ancient bound book filled with regional history, science, and lore.", heal=0),
            self.load_item("19.png", 3, "Fresh River Trout", "Freshly caught river fish. Restores 25 HP when consumed.", heal=25),
            self.load_item("22.png", 6, "Steak", "Hearty cooked steak on the bone. Restores 40 HP when consumed.", heal=40),
            self.load_item("25.png", 1, "Health Leaf", "Medicinal green leaf. Heals 50 HP when consumed.", heal=50),
            self.load_item("14.png", 42, "Ancient Gold Coins", "Kingdom currency accepted in all shops.", heal=0),
            # Starter materials for crafting
            self.load_science_item("wood_log.png", 4, "Wood Log", "Dense timber harvested from forest trees. Rich in natural cellulose; crafts into wood planks."),
            self.load_science_item("rock_item.png", 8, "Rock", "Chunky geological stone broken from field boulders. Essential material for crafting and masonry.")
        ]

        # 3x3 Field Workbench Crafting Grid: [slot 0 ... slot 8]
        # (0,0) (1,0) (2,0)
        # (0,1) (1,1) (2,1)
        # (0,2) (1,2) (2,2)
        self.crafting_grid = [None] * 9
        self.result_item = None
        self.selected_inv_idx = None

        self.recipes = [
            {'name': 'Stone Pickaxe', 'qty': 1, 'desc': 'Handcrafted stone pickaxe. Yields 2x mining damage to rocks and ores.', 'heal': 0, 'img_file': 'stone_pickaxe.png', 'req': {'Rock': 3, 'Stick': 1}, 'label': 'Pickaxe (3 Rocks+Stick)', 'req_str': '3 Rocks + 1 Stick'},
            {'name': 'Stone Axe', 'qty': 1, 'desc': 'Handcrafted stone axe. Yields 2x chopping damage to trees.', 'heal': 0, 'img_file': 'stone_axe.png', 'req': {'Rock': 3, 'Stick': 1}, 'label': 'Axe (3 Rocks+Stick)', 'req_str': '3 Rocks + 1 Stick'},
            {'name': 'Stone Shovel', 'qty': 1, 'desc': 'Handcrafted stone shovel for rapid excavation.', 'heal': 0, 'img_file': 'stone_shovel.png', 'req': {'Rock': 1, 'Stick': 1}, 'label': 'Shovel (1 Rock+Stick)', 'req_str': '1 Rock + 1 Stick'},
            {'name': 'Stone Sword', 'qty': 1, 'desc': 'Handcrafted stone blade. Deals 2x combat damage to predators and bears.', 'heal': 0, 'img_file': 'stone_sword.png', 'req': {'Rock': 2, 'Stick': 1}, 'label': 'Sword (2 Rocks+Stick)', 'req_str': '2 Rocks + 1 Stick'},
            {'name': 'Stone Hoe', 'qty': 1, 'desc': 'Handcrafted stone agrarian hoe for tilling and plant cultivation.', 'heal': 0, 'img_file': 'stone_hoe.png', 'req': {'Rock': 2, 'Stick': 1}, 'label': 'Hoe (2 Rocks+Stick)', 'req_str': '2 Rocks + 1 Stick'},
            {'name': 'Wood Plank', 'qty': 4, 'desc': 'Refined wooden lumber. Used for basic carpentry and tool handles.', 'heal': 0, 'img_file': 'wood_plank.png', 'req': {'Wood Log': 1}, 'label': 'Planks x4 (1 Log)', 'req_str': '1 Wood Log'},
            {'name': 'Stick', 'qty': 4, 'desc': 'Carved wooden stick. Essential component for tool handles and torches.', 'heal': 0, 'img_file': 'stick.png', 'req': {'Wood Plank': 2}, 'label': 'Sticks x4 (2 Planks)', 'req_str': '2 Wood Planks'},
            {'name': 'Campfire', 'qty': 1, 'desc': 'Warm crackling stone campfire. Illuminates campsite and provides warmth.', 'heal': 0, 'img_file': 'rock_item.png', 'req': {'Rock': 4}, 'label': 'Campfire (4 Rocks)', 'req_str': '4 Rocks'},
            {'name': 'Torch', 'qty': 4, 'desc': 'Wooden stick topped with burning coal pitch. Illuminates wilderness.', 'heal': 0, 'img_file': 'stick.png', 'req': {'Coal Lump': 1, 'Stick': 1}, 'label': 'Torches x4 (Coal+Stick)', 'req_str': '1 Coal + 1 Stick'},
            {'name': 'Cooked Steak', 'qty': 1, 'desc': 'Hearty campfire-cooked steak. Restores 45 HP when consumed.', 'heal': 45, 'img_file': 'cooked_steak.png', 'req': {'Raw Bear Meat': 1, 'Coal Lump': 1}, 'label': 'Steak (Meat+Coal)', 'req_str': '1 Raw Meat + 1 Coal'},
            {'name': 'Iron Sword', 'qty': 1, 'desc': 'Forged iron longsword. Masterwork weapon with 2x combat damage.', 'heal': 0, 'img_file': 'iron_sword.png', 'req': {'Iron Ingot': 2, 'Stick': 1}, 'label': 'Iron Sword (2 Iron+Stick)', 'req_str': '2 Iron + 1 Stick'},
            {'name': 'Iron Pickaxe', 'qty': 1, 'desc': 'Forged metallurgical iron pickaxe with peak rock & ore destruction power.', 'heal': 0, 'img_file': 'iron_pickaxe.png', 'req': {'Iron Ingot': 3, 'Stick': 1}, 'label': 'Iron Pick (3 Iron+Stick)', 'req_str': '3 Iron + 1 Stick'},
        ]

    def load_item(self, filename, qty, name, desc, heal=0):
        paths = [
            os.path.join(BASE_DIR, "game_ui", "Humble Gift - Paper UI System v1.1", "Sprites", "Content", "1 Items", filename),
            os.path.join(BASE_DIR, "UI", "Humble Gift - Paper UI System v1.1", "Sprites", "Content", "1 Items", filename),
        ]
        if getattr(sys, 'frozen', False):
            meipass = getattr(sys, '_MEIPASS', BASE_DIR)
            paths.insert(0, os.path.join(meipass, "game_ui", "Humble Gift - Paper UI System v1.1", "Sprites", "Content", "1 Items", filename))
            paths.insert(1, os.path.join(meipass, "UI", "Humble Gift - Paper UI System v1.1", "Sprites", "Content", "1 Items", filename))

        for p in paths:
            if os.path.exists(p):
                try:
                    img = pygame.image.load(p).convert_alpha()
                    return {"img": img, "qty": qty, "name": name, "desc": desc, "heal": heal, "hover": False, "img_file": filename}
                except Exception:
                    pass
        s = pygame.Surface((48, 48), pygame.SRCALPHA)
        pygame.draw.rect(s, (180, 140, 80), (4, 4, 40, 40), border_radius=4)
        return {"img": s, "qty": qty, "name": name, "desc": desc, "heal": heal, "hover": False, "img_file": filename}

    def load_science_item(self, filename, qty, name, desc, heal=0):
        paths = [
            os.path.join(BASE_DIR, "3D_Assets", "ScienceRPG", filename),
        ]
        if getattr(sys, 'frozen', False):
            meipass = getattr(sys, '_MEIPASS', BASE_DIR)
            paths.insert(0, os.path.join(meipass, "3D_Assets", "ScienceRPG", filename))
        for p in paths:
            if os.path.exists(p):
                try:
                    img = pygame.image.load(p).convert_alpha()
                    return {"img": img, "qty": qty, "name": name, "desc": desc, "heal": heal, "hover": False, "img_file": filename}
                except Exception:
                    pass
        s = pygame.Surface((48, 48), pygame.SRCALPHA)
        pygame.draw.circle(s, (180, 140, 60), (24, 24), 20)
        return {"img": s, "qty": qty, "name": name, "desc": desc, "heal": heal, "hover": False, "img_file": filename}

    def add_item(self, name, qty, desc, img_file, heal=0):
        for it in self.items:
            if it["name"] == name:
                it["qty"] += qty
                return
        new_it = self.load_science_item(img_file, qty, name, desc, heal)
        self.items.append(new_it)

    def evaluate_crafting_grid(self):
        counts = {}
        for it in self.crafting_grid:
            if it:
                counts[it["name"]] = counts.get(it["name"], 0) + 1
        for r in self.recipes:
            if r["req"] == counts:
                res_item = self.load_science_item(r["img_file"], r["qty"], r["name"], r["desc"], r["heal"])
                self.result_item = res_item
                return
        self.result_item = None

    def return_grid_items_to_inventory(self):
        for idx in range(len(self.crafting_grid)):
            it = self.crafting_grid[idx]
            if it:
                self.add_item(it["name"], 1, it["desc"], it.get("img_file", "rock_item.png"), it.get("heal", 0))
                self.crafting_grid[idx] = None
        self.result_item = None
        self.selected_inv_idx = None

    def craft_result_item(self, game=None):
        if not self.result_item:
            return False
        r_name = self.result_item["name"]
        r_qty = self.result_item["qty"]
        r_desc = self.result_item["desc"]
        r_img = self.result_item.get("img_file", "rock_item.png")
        r_heal = self.result_item.get("heal", 0)
        self.add_item(r_name, r_qty, r_desc, r_img, r_heal)

        for idx in range(len(self.crafting_grid)):
            self.crafting_grid[idx] = None

        self.evaluate_crafting_grid()
        if game and hasattr(game, 'sound_mgr'):
            game.sound_mgr.play('craft_success')
        if game:
            game.prompt_text = f"Crafted {r_name} x{r_qty}!"
            game.prompt_timer = 2.5
            if "Plank" in r_name or "Stick" in r_name:
                game.discover_social_studies("cellulose")
            elif "Pickaxe" in r_name or "Campfire" in r_name:
                game.discover_social_studies("mineralogy")
        return True

    def quick_craft(self, recipe, game=None):
        for req_name, req_qty in recipe["req"].items():
            found_qty = 0
            for it in self.items:
                if it["name"] == req_name:
                    found_qty += it["qty"]
            if found_qty < req_qty:
                if game and hasattr(game, 'sound_mgr'):
                    game.sound_mgr.play('door_locked')
                if game:
                    game.prompt_text = f"Need materials: {recipe['req_str']}!"
                    game.prompt_timer = 2.5
                return False

        for req_name, req_qty in recipe["req"].items():
            rem = req_qty
            for it in self.items[:]:
                if it["name"] == req_name:
                    take = min(rem, it["qty"])
                    it["qty"] -= take
                    rem -= take
                    if it["qty"] <= 0:
                        self.items.remove(it)
                    if rem <= 0:
                        break

        self.add_item(recipe["name"], recipe["qty"], recipe["desc"], recipe["img_file"], recipe["heal"])
        if game and hasattr(game, 'sound_mgr'):
            game.sound_mgr.play('craft_success')
        if game:
            game.prompt_text = f"Crafted {recipe['name']} x{recipe['qty']}!"
            game.prompt_timer = 2.5
            if "Plank" in recipe["name"] or "Stick" in recipe["name"]:
                game.discover_social_studies("cellulose")
            elif "Pickaxe" in recipe["name"] or "Campfire" in recipe["name"]:
                game.discover_social_studies("mineralogy")
            elif "Steak" in recipe["name"]:
                game.discover_social_studies("agrarian")
        return True

    def update(self, dt, events, game=None):
        panel_x = (self.width - self.panel_w) // 2
        panel_y = 65
        panel_rect = pygame.Rect(panel_x - 10, panel_y - 45, self.panel_w + 20, self.panel_h + 55)

        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_ESCAPE, pygame.K_e):
                    self.return_grid_items_to_inventory()
                    self.active = False
                    return True
                elif event.key == pygame.K_j:
                    self.return_grid_items_to_inventory()
                    self.active = False
                    if game and hasattr(game, 'codex_ui'):
                        game.codex_ui.open()
                        if hasattr(game, 'sound_mgr'):
                            game.sound_mgr.play('key')
                    return True

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mx, my = event.pos
                if not panel_rect.collidepoint(mx, my):
                    self.return_grid_items_to_inventory()
                    self.active = False
                    return True

                # 1. Check Result Slot Click
                result_rect = pygame.Rect(panel_x + 344 + 245, panel_y + 34 + 50, 64, 64)
                if result_rect.collidepoint(mx, my):
                    if self.result_item:
                        self.craft_result_item(game)
                        return True

                # 2. Check 3x3 Crafting Grid Clicks
                craft_coords = []
                for r in range(3):
                    for c in range(3):
                        craft_coords.append((panel_x + 344 + 20 + c * 42, panel_y + 34 + 24 + r * 42))

                for g_idx, (gx, gy) in enumerate(craft_coords):
                    g_rect = pygame.Rect(gx, gy, 38, 38)
                    if g_rect.collidepoint(mx, my):
                        # If slot is occupied, return item to inventory
                        if self.crafting_grid[g_idx]:
                            it = self.crafting_grid[g_idx]
                            self.add_item(it["name"], 1, it["desc"], it.get("img_file", "rock_item.png"), it.get("heal", 0))
                            self.crafting_grid[g_idx] = None
                            self.evaluate_crafting_grid()
                            if game and hasattr(game, 'sound_mgr'):
                                game.sound_mgr.play('item_pickup')
                            return True
                        # If slot is empty and an inventory item is selected, place 1 into slot
                        elif self.selected_inv_idx is not None and self.selected_inv_idx < len(self.items):
                            inv_item = self.items[self.selected_inv_idx]
                            if inv_item["qty"] > 0:
                                inv_item["qty"] -= 1
                                self.crafting_grid[g_idx] = {
                                    "name": inv_item["name"],
                                    "desc": inv_item["desc"],
                                    "img": inv_item["img"],
                                    "heal": inv_item.get("heal", 0),
                                    "img_file": inv_item.get("img_file", "rock_item.png")
                                }
                                if inv_item["qty"] <= 0:
                                    self.items.remove(inv_item)
                                    self.selected_inv_idx = None
                                self.evaluate_crafting_grid()
                                if game and hasattr(game, 'sound_mgr'):
                                    game.sound_mgr.play('mine_hit')
                                return True

                # 3. Check Quick Recipe Buttons Clicks
                for r_idx, rec in enumerate(self.recipes):
                    row = r_idx // 2
                    col = r_idx % 2
                    bx = panel_x + 344 + 8 + 6 + col * 170
                    by = panel_y + 34 + 158 + 20 + row * 19
                    btn_rect = pygame.Rect(bx, by, 164, 17)
                    if btn_rect.collidepoint(mx, my):
                        self.quick_craft(rec, game)
                        return True

                # 4. Check 4x4 Inventory Slot Clicks
                for idx, item in enumerate(self.items[:]):
                    row = idx // 4
                    col = idx % 4
                    slot_x = panel_x + 28 + col * 72
                    slot_y = panel_y + 50 + row * 72
                    slot_rect = pygame.Rect(slot_x, slot_y, 64, 64)
                    if slot_rect.collidepoint(mx, my):
                        heal = item.get("heal", 0)
                        # If consumable food and not holding a craft selection
                        if heal > 0 and item["qty"] > 0 and self.selected_inv_idx != idx:
                            item["qty"] -= 1
                            if game and hasattr(game, 'player') and hasattr(game.player, 'hp'):
                                game.player.hp = min(game.player.max_hp, game.player.hp + heal)
                            if game and hasattr(game, 'sound_mgr'):
                                game.sound_mgr.play('potion')
                            if game:
                                game.prompt_text = f"Consumed {item['name']}! Restored {heal} HP! [HP: {getattr(game.player, 'hp', 100)}/100]"
                                game.prompt_timer = 2.5
                                if "Leaf" in item["name"]:
                                    game.discover_social_studies("ethnobotany")
                                elif "Steak" in item["name"] or "Trout" in item["name"]:
                                    game.discover_social_studies("agrarian")
                            if item["qty"] <= 0:
                                self.items.remove(item)
                                self.selected_inv_idx = None
                            return True
                        elif "Book" in item["name"]:
                            self.return_grid_items_to_inventory()
                            self.active = False
                            if game and hasattr(game, 'codex_ui'):
                                game.codex_ui.open()
                            if game and hasattr(game, 'sound_mgr'):
                                game.sound_mgr.play('key')
                            return True
                        elif "Gold" in item["name"]:
                            if game and hasattr(game, 'sound_mgr'):
                                game.sound_mgr.play('gold')
                            if game:
                                game.prompt_text = f"Ancient Coins: {item['qty']} gold coins in your pouch."
                                game.prompt_timer = 2.5
                                game.discover_social_studies("currency")
                            return True
                        else:
                            # Toggle selection for placing into crafting grid!
                            if self.selected_inv_idx == idx:
                                self.selected_inv_idx = None
                            else:
                                self.selected_inv_idx = idx
                                if game and hasattr(game, 'sound_mgr'):
                                    game.sound_mgr.play('item_pickup')
                            return True
        return False

    def draw(self, surface):
        if not self.active:
            return

        dim = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        dim.fill((0, 0, 0, 160))
        surface.blit(dim, (0, 0))

        panel_x = (self.width - self.panel_w) // 2
        panel_y = 65

        # 1. Main Outer Window Frame
        outer_rect = pygame.Rect(panel_x, panel_y, self.panel_w, self.panel_h)
        pygame.draw.rect(surface, (22, 16, 12), outer_rect, border_radius=10)
        pygame.draw.rect(surface, (180, 125, 50), outer_rect, width=4, border_radius=10)
        pygame.draw.rect(surface, (110, 75, 30), outer_rect.inflate(-6, -6), width=2, border_radius=8)

        # 2. Header Banner
        header_rect = pygame.Rect(panel_x, panel_y - 42, self.panel_w, 38)
        pygame.draw.rect(surface, (28, 20, 14), header_rect, border_radius=8)
        pygame.draw.rect(surface, (210, 160, 60), header_rect, width=3, border_radius=8)

        t_surf = self.font_title.render("ADVENTURER'S SATCHEL & FIELD WORKBENCH", True, (255, 225, 90))
        surface.blit(t_surf, t_surf.get_rect(center=(panel_x + self.panel_w // 2, panel_y - 23)))

        # Subtitle controls hint
        sub_txt = self.font_sub.render("[E]/[ESC] Close  *  [J] World Codex  *  Click items to craft or place in 3x3 workbench", True, (210, 195, 160))
        surface.blit(sub_txt, (panel_x + 18, panel_y + 12))

        # 3. Left Section: 4x4 Inventory Grid Box
        inv_box = pygame.Rect(panel_x + 16, panel_y + 34, 316, 308)
        pygame.draw.rect(surface, (16, 12, 10), inv_box, border_radius=8)
        pygame.draw.rect(surface, (140, 95, 45), inv_box, width=2, border_radius=8)

        sec1_title = self.font_btn.render("INVENTORY (4x4 SATCHEL)", True, (230, 185, 80))
        surface.blit(sec1_title, (inv_box.x + 10, inv_box.y + 6))

        mx, my = pygame.mouse.get_pos()
        hovered_item = None

        for idx in range(16):
            row = idx // 4
            col = idx % 4
            slot_x = inv_box.x + 10 + col * 74
            slot_y = inv_box.y + 24 + row * 69
            slot_rect = pygame.Rect(slot_x, slot_y, 66, 62)

            # Slot wooden recess background
            pygame.draw.rect(surface, (34, 24, 18), slot_rect, border_radius=6)
            pygame.draw.rect(surface, (70, 48, 28), slot_rect, width=2, border_radius=6)

            if idx < len(self.items):
                item = self.items[idx]
                is_hover = slot_rect.collidepoint(mx, my)
                item["hover"] = is_hover
                if is_hover:
                    hovered_item = item
                    glow = pygame.Surface((66, 62), pygame.SRCALPHA)
                    glow.fill((255, 220, 100, 50))
                    pygame.draw.rect(glow, (255, 215, 60), (0, 0, 66, 62), width=2, border_radius=6)
                    surface.blit(glow, slot_rect)

                if self.selected_inv_idx == idx:
                    pygame.draw.rect(surface, (80, 220, 120), slot_rect, width=3, border_radius=6)

                icon_size = 46 if is_hover else 42
                icon_img = pygame.transform.scale(item["img"], (icon_size, icon_size))
                surface.blit(icon_img, icon_img.get_rect(center=slot_rect.center))

                # Quantity badge
                q_str = str(item["qty"])
                q_txt = self.font_qty.render(q_str, True, (255, 255, 240))
                q_shd = self.font_qty.render(q_str, True, (0, 0, 0))
                bw = max(16, q_txt.get_width() + 6)
                bh = q_txt.get_height() + 2
                br = pygame.Rect(slot_rect.right - bw - 2, slot_rect.bottom - bh - 2, bw, bh)
                b_surf = pygame.Surface((bw, bh), pygame.SRCALPHA)
                b_surf.fill((12, 10, 8, 220))
                pygame.draw.rect(b_surf, (180, 140, 60), (0, 0, bw, bh), width=1, border_radius=3)
                b_surf.blit(q_shd, (4, 1))
                b_surf.blit(q_txt, (3, 0))
                surface.blit(b_surf, br)

        # 4. Right Section: 3x3 Field Workbench Crafting Box
        craft_box = pygame.Rect(panel_x + 344, panel_y + 34, 360, 308)
        pygame.draw.rect(surface, (16, 12, 10), craft_box, border_radius=8)
        pygame.draw.rect(surface, (140, 95, 45), craft_box, width=2, border_radius=8)

        sec2_title = self.font_btn.render("3x3 FIELD WORKBENCH", True, (230, 185, 80))
        surface.blit(sec2_title, (craft_box.x + 10, craft_box.y + 6))

        craft_coords = []
        for r in range(3):
            for c in range(3):
                craft_coords.append((craft_box.x + 20 + c * 42, craft_box.y + 24 + r * 42))

        for g_idx, (gx, gy) in enumerate(craft_coords):
            g_rect = pygame.Rect(gx, gy, 38, 38)
            is_hover = g_rect.collidepoint(mx, my)
            pygame.draw.rect(surface, (34, 24, 18), g_rect, border_radius=5)
            pygame.draw.rect(surface, (190, 140, 60) if is_hover else (70, 48, 28), g_rect, width=2, border_radius=5)

            it = self.crafting_grid[g_idx]
            if it:
                if is_hover:
                    hovered_item = it
                img = it.get("img")
                if img:
                    icon = pygame.transform.scale(img, (30, 30))
                    surface.blit(icon, icon.get_rect(center=g_rect.center))
            else:
                lbl = self.font_btn.render(str(g_idx + 1), True, (70, 55, 40))
                surface.blit(lbl, lbl.get_rect(center=g_rect.center))

        # Big Crafting Arrow ==>
        arrow_x = craft_box.x + 168
        arrow_y = craft_box.y + 66
        arrow_surf = get_rpg_font(26, bold=True).render("-->", True, (255, 215, 60))
        surface.blit(arrow_surf, (arrow_x, arrow_y))

        # Result Slot
        res_rect = pygame.Rect(craft_box.x + 245, craft_box.y + 50, 64, 64)
        res_hover = res_rect.collidepoint(mx, my)
        pygame.draw.rect(surface, (28, 20, 14), res_rect, border_radius=8)
        res_border_col = (255, 225, 90) if self.result_item else (100, 75, 40)
        pygame.draw.rect(surface, res_border_col, res_rect, width=3, border_radius=8)
        res_lbl = self.font_btn.render("RESULT", True, (220, 175, 80) if self.result_item else (90, 70, 50))
        surface.blit(res_lbl, res_lbl.get_rect(center=(res_rect.centerx, res_rect.top - 8)))

        if self.result_item:
            if res_hover:
                hovered_item = self.result_item
                res_glow = pygame.Surface((64, 64), pygame.SRCALPHA)
                res_glow.fill((255, 225, 90, 50))
                surface.blit(res_glow, res_rect)

            res_img = self.result_item.get("img")
            if res_img:
                res_icon = pygame.transform.scale(res_img, (44, 44))
                surface.blit(res_icon, res_icon.get_rect(center=res_rect.center))

            rq_str = str(self.result_item["qty"])
            rq_txt = self.font_qty.render(rq_str, True, (255, 255, 255))
            rq_shd = self.font_qty.render(rq_str, True, (0, 0, 0))
            rbw = max(16, rq_txt.get_width() + 6)
            rbh = rq_txt.get_height() + 2
            rbr = pygame.Rect(res_rect.right - rbw - 2, res_rect.bottom - rbh - 2, rbw, rbh)
            rb_surf = pygame.Surface((rbw, rbh), pygame.SRCALPHA)
            rb_surf.fill((12, 10, 8, 220))
            pygame.draw.rect(rb_surf, (255, 215, 60), (0, 0, rbw, rbh), width=1, border_radius=3)
            rb_surf.blit(rq_shd, (4, 1))
            rb_surf.blit(rq_txt, (3, 0))
            surface.blit(rb_surf, rbr)

        # Recipe Book Bar (Quick-Craft Buttons)
        rbook_box = pygame.Rect(craft_box.x + 8, craft_box.y + 158, craft_box.width - 16, 142)
        pygame.draw.rect(surface, (20, 14, 10), rbook_box, border_radius=6)
        pygame.draw.rect(surface, (100, 70, 35), rbook_box, width=1, border_radius=6)

        rb_title = self.font_btn.render("RECIPE BOOK (CLICK TO CRAFT)", True, (215, 175, 75))
        surface.blit(rb_title, (rbook_box.x + 8, rbook_box.y + 3))

        for r_idx, rec in enumerate(self.recipes):
            row = r_idx // 2
            col = r_idx % 2
            bx = rbook_box.x + 6 + col * 170
            by = rbook_box.y + 18 + row * 20
            btn_rect = pygame.Rect(bx, by, 164, 18)

            # Check if player has ingredients
            can_craft = True
            for req_name, req_qty in rec["req"].items():
                cnt = sum(it["qty"] for it in self.items if it["name"] == req_name)
                if cnt < req_qty:
                    can_craft = False
                    break

            b_hover = btn_rect.collidepoint(mx, my)
            if b_hover:
                hovered_item = {
                    "name": rec["name"],
                    "qty": rec["qty"],
                    "desc": f"Crafts {rec['name']} x{rec['qty']}. Requirements: {rec['req_str']}. {rec['desc']}",
                    "img": self.load_science_item(rec["img_file"], rec["qty"], rec["name"], rec["desc"])["img"],
                    "heal": rec["heal"]
                }

            b_bg = (55, 40, 24) if b_hover else (32, 22, 14)
            b_border = (255, 215, 60) if b_hover else ((150, 110, 50) if can_craft else (80, 60, 40))
            pygame.draw.rect(surface, b_bg, btn_rect, border_radius=3)
            pygame.draw.rect(surface, b_border, btn_rect, width=1, border_radius=3)

            text_col = (255, 235, 140) if can_craft else (130, 115, 95)
            btn_lbl = self.font_btn.render(rec["label"], True, text_col)
            surface.blit(btn_lbl, (btn_rect.x + 4, btn_rect.y + 2))

        # 5. Bottom Inspection / Tooltip / Guide Lore Box
        tip_rect = pygame.Rect(panel_x + 16, panel_y + 352, self.panel_w - 32, 124)
        pygame.draw.rect(surface, (20, 15, 12), tip_rect, border_radius=8)
        pygame.draw.rect(surface, (170, 120, 45), tip_rect, width=2, border_radius=8)

        if hovered_item:
            tip_icon = pygame.transform.scale(hovered_item["img"], (48, 48))
            surface.blit(tip_icon, (tip_rect.x + 14, tip_rect.y + 14))

            h_val = hovered_item.get("heal", 0)
            heal_str = f"  *  [Restores {h_val} HP]" if h_val > 0 else ""
            n_surf = self.font_title.render(f"{hovered_item['name']}  (x{hovered_item.get('qty', 1)}){heal_str}", True, (255, 215, 80))
            surface.blit(n_surf, (tip_rect.x + 72, tip_rect.y + 10))

            max_desc_w = tip_rect.width - 86
            desc_lines = wrap_codex_text(hovered_item.get("desc", ""), self.font_desc, max_desc_w)
            for d_idx, d_line in enumerate(desc_lines[:3]):
                d_surf = self.font_desc.render(d_line, True, (235, 225, 205))
                surface.blit(d_surf, (tip_rect.x + 72, tip_rect.y + 36 + d_idx * 18))
        else:
            p1 = self.font_title.render("FIELD WORKBENCH CRAFTING GUIDE", True, (240, 200, 80))
            p2 = self.font_desc.render("1. Select an item from your Satchel, then click any 3x3 workbench slot to place it.", True, (220, 210, 190))
            p3 = self.font_desc.render("2. When ingredients form a recipe, click the RESULT slot to craft!", True, (220, 210, 190))
            p4 = self.font_desc.render("3. Or click any button in the RECIPE BOOK to quick-craft instantly with materials in bag!", True, (220, 210, 190))
            surface.blit(p1, (tip_rect.x + 18, tip_rect.y + 10))
            surface.blit(p2, (tip_rect.x + 18, tip_rect.y + 36))
            surface.blit(p3, (tip_rect.x + 18, tip_rect.y + 58))
            surface.blit(p4, (tip_rect.x + 18, tip_rect.y + 80))

class SimulatedKeyDict:
    """Virtual Pygame key container allowing simulated bot inputs alongside physical inputs."""
    def __init__(self, base_keys=None):
        self._keys = set()
        if base_keys is not None:
            for k in [pygame.K_ESCAPE, pygame.K_F4, pygame.K_F1, pygame.K_F2]:
                try:
                    if base_keys[k]:
                        self._keys.add(k)
                except Exception:
                    pass

    def __getitem__(self, item):
        return item in self._keys

    def get(self, item, default=False):
        return item in self._keys

    def set(self, item, val=True):
        if val:
            self._keys.add(item)
        else:
            self._keys.discard(item)

class RPGBotController:
    """
    Autonomous AI Companion for RPG Mode.
    Automates tree woodcutting, mineral mining, bear hunting, blacksmith smelting/cooking,
    dungeon infiltration & conquest, village house visiting, bed resting, and grand piano
    performance of Yiruma's 'River Flows in You' with accurate BPM and prior achievement unlock.
    """
    def __init__(self, game):
        self.game = game
        self.enabled = False
        self.goal_text = "Idle"
        self.current_goal = "IDLE"
        self.target_pos = None
        self.target_entity = None
        self.stuck_timer = 0.0
        self.last_pos = (0, 0)
        self.action_cooldown = 0.0
        self.dialogue_timer = 0.0
        self.portal_spawn_timer = 45.0
        self.house_visit_timer = 60.0
        self.piano_played = False
        self.house_action = "bed" # "bed" or "piano"
        self.dungeon_step = 0
        self.cycle_state = "GATHER" # "GATHER", "BLACKSMITH", "DUNGEON", "HOUSE"
        self.gather_subgoal = "tree" # "tree", "ore", "bear"
        self.btn_bot_rect = pygame.Rect(game.width - 665, 14, 145, 34)

    def toggle(self):
        self.enabled = not self.enabled
        if self.enabled:
            self.current_goal = "IDLE"
            self.goal_text = "AI Companion Active - Scanning Realm..."
            if hasattr(self.game, 'sound_mgr'):
                self.game.sound_mgr.play('alert')
        else:
            self.goal_text = "AI Companion Inactive"
            if hasattr(self.game, 'sound_mgr'):
                self.game.sound_mgr.play('door_locked')

    def move_towards(self, tx, ty, sim_keys, stop_dist=24.0):
        px = self.game.player.rect.centerx
        py = self.game.player.rect.centery
        dx = tx - px
        dy = ty - py
        dist = math.hypot(dx, dy)
        if dist <= stop_dist:
            return True

        # Track position to detect and overcome obstacles
        if math.hypot(px - self.last_pos[0], py - self.last_pos[1]) < 1.0:
            self.stuck_timer += 0.016
        else:
            self.stuck_timer = 0.0
        self.last_pos = (px, py)

        if self.stuck_timer > 0.6:
            # Jitter or jump over obstacles
            if random.random() < 0.3:
                sim_keys.set(pygame.K_SPACE, True)
            if abs(dx) > abs(dy):
                sim_keys.set(pygame.K_s if random.random() < 0.5 else pygame.K_w, True)
            else:
                sim_keys.set(pygame.K_d if random.random() < 0.5 else pygame.K_a, True)
            if self.stuck_timer > 2.2:
                self.stuck_timer = 0.0
                self.target_pos = None
                self.target_entity = None
            return False

        if abs(dx) > 10:
            if dx > 0: sim_keys.set(pygame.K_d, True)
            else: sim_keys.set(pygame.K_a, True)
        if abs(dy) > 10:
            if dy > 0: sim_keys.set(pygame.K_s, True)
            else: sim_keys.set(pygame.K_w, True)
        return False

    def get_simulated_keys(self, base_keys, dt):
        if not self.enabled:
            return None

        sim_keys = SimulatedKeyDict(base_keys)
        self.action_cooldown = max(0.0, self.action_cooldown - dt)
        self.dialogue_timer = max(0.0, self.dialogue_timer - dt)
        self.portal_spawn_timer = max(0.0, self.portal_spawn_timer - dt)
        self.house_visit_timer = max(0.0, self.house_visit_timer - dt)

        # -------------------------------------------------------------
        # 1. GROUND ITEM COLLECTION (Top Priority: Pick up dropped loot)
        # -------------------------------------------------------------
        if self.game.transition_state == "none" and hasattr(self.game.map, 'ground_items') and self.game.map.ground_items:
            px = self.game.player.rect.centerx
            py = self.game.player.rect.centery
            closest_item = min(self.game.map.ground_items, key=lambda it: (it.x - px)**2 + (it.y - py)**2)
            self.goal_text = f"Collecting {closest_item.item_name} (x{closest_item.qty})..."
            self.move_towards(closest_item.x, closest_item.y, sim_keys, stop_dist=12.0)
            return sim_keys

        # -------------------------------------------------------------
        # 2. DUNGEON INTERIOR AUTOMATION (Keys -> Doors -> Chests -> Conquest)
        # -------------------------------------------------------------
        if self.game.transition_state == "inside_dungeon":
            dungeon = self.game.dungeon
            px = self.game.player.rect.centerx
            py = self.game.player.rect.centery

            if dungeon.dungeon_conquered:
                self.goal_text = "Ancient Dungeon Conquered! Teleporting to village..."
                return sim_keys

            # 2a. Pick up unpicked keys on floor
            unpicked_keys = [k for k in dungeon.keys if not k["picked"]]
            if unpicked_keys:
                closest_k = min(unpicked_keys, key=lambda k: (k["rect"].centerx - px)**2 + (k["rect"].centery - py)**2)
                self.goal_text = f"Retrieving {closest_k.get('type', 'Silver')} Dungeon Key..."
                reached = self.move_towards(closest_k["rect"].centerx, closest_k["rect"].centery, sim_keys, stop_dist=24.0)
                if reached or math.hypot(closest_k["rect"].centerx - px, closest_k["rect"].centery - py) < 36.0:
                    sim_keys.set(pygame.K_e, True)
                return sim_keys

            # 2b. Open unopened chests
            unopened_chests = [c for c in dungeon.chests if not c["opened"]]
            if unopened_chests:
                closest_c = min(unopened_chests, key=lambda c: (c["rect"].centerx - px)**2 + (c["rect"].centery - py)**2)
                self.goal_text = "Opening Ancient Dungeon Treasure Chest..."
                reached = self.move_towards(closest_c["rect"].centerx, closest_c["rect"].centery, sim_keys, stop_dist=28.0)
                if reached or math.hypot(closest_c["rect"].centerx - px, closest_c["rect"].centery - py) < 38.0:
                    sim_keys.set(pygame.K_e, True)
                return sim_keys

            # 2c. Unlock locked doors
            unopened_doors = [d for d in dungeon.doors if not d["opened"]]
            if unopened_doors:
                target_door = None
                for d in unopened_doors:
                    if d.get("type") == "Gold" and dungeon.gold_keys_collected > 0:
                        target_door = d
                        break
                    elif d.get("type") == "Silver" and dungeon.silver_keys_collected > 0:
                        target_door = d
                        break
                if target_door:
                    self.goal_text = f"Unlocking {target_door.get('type', '')} Reinforced Door..."
                    reached = self.move_towards(target_door["rect"].centerx, target_door["rect"].centery, sim_keys, stop_dist=30.0)
                    if reached or math.hypot(target_door["rect"].centerx - px, target_door["rect"].centery - py) < 42.0:
                        sim_keys.set(pygame.K_e, True)
                    return sim_keys

            # 2d. Walk into final double door / conquest zone
            self.goal_text = "Conquering Dungeon Vaults!"
            self.move_towards(450, 190, sim_keys, stop_dist=12.0)
            return sim_keys

        # -------------------------------------------------------------
        # 3. HOUSE INTERIOR AUTOMATION (Resting in Bed or Grand Piano Performance)
        # -------------------------------------------------------------
        if self.game.transition_state == "inside":
            interior = self.game.interior
            px = self.game.player.rect.centerx
            py = self.game.player.rect.centery

            # Always unlock architecture achievement upon stepping inside
            self.game.discover_social_studies("architecture")

            # 3a. If Piano UI is currently active
            if self.game.piano_ui.active:
                if not self.game.piano_ui.is_playing_river_flows and not self.piano_played:
                    # User requirement: "oh yeah before playing the river flows in you just do the achievement first. then plays the river flows in you after."
                    self.game.discover_social_studies("music")
                    self.game.piano_ui.play_river_flows_in_you()
                    self.piano_played = True
                if self.game.piano_ui.is_playing_river_flows:
                    self.goal_text = "Performing Yiruma - 'River Flows in You' (74 BPM Acoustic Grand Piano)..."
                else:
                    self.goal_text = "Piano Performance Complete. Exiting House..."
                    self.game.piano_ui.close()
                    self.house_action = "done"
                return sim_keys

            # 3b. If Sleeping ZZZ animation is currently running
            if self.game.sleep_state != "none":
                self.goal_text = "Resting in Bed (Recovering Stamina & Energy)..."
                return sim_keys

            # 3c. Choose house action: Bed vs Piano
            if self.house_action == "bed":
                if not self.game.has_slept_today and interior.bed_item:
                    bed_rect = interior.bed_item["rect"]
                    self.goal_text = "Navigating to Bed to Rest..."
                    reached = self.move_towards(bed_rect.centerx, bed_rect.bottom + 12, sim_keys, stop_dist=24.0)
                    if reached or self.game.near_bed:
                        sim_keys.set(pygame.K_e, True)
                        self.house_action = "piano"
                    return sim_keys
                else:
                    self.house_action = "piano"

            if self.house_action == "piano":
                if interior.piano_item:
                    piano_rect = interior.piano_item["rect"]
                    self.goal_text = "Approaching Grand Piano to Play 'River Flows in You'..."
                    reached = self.move_towards(piano_rect.centerx, piano_rect.bottom + 15, sim_keys, stop_dist=24.0)
                    if reached or self.game.near_piano:
                        # Unlock music achievement first before starting song!
                        self.game.discover_social_studies("music")
                        self.game.piano_ui.open()
                        self.game.piano_ui.play_river_flows_in_you()
                        self.piano_played = True
                    return sim_keys

            # 3d. Finished house tasks -> Exit house through doorway
            self.goal_text = "Leaving House to Wilderness..."
            reached = self.move_towards(interior.room_rect.centerx, interior.room_rect.bottom - 6, sim_keys, stop_dist=15.0)
            if reached or py >= interior.room_rect.bottom - 22:
                sim_keys.set(pygame.K_s, True)
            return sim_keys

        # -------------------------------------------------------------
        # 4. OUTSIDE WORLD AUTOMATION
        # -------------------------------------------------------------
        if self.game.transition_state != "none":
            return sim_keys

        px = self.game.player.rect.centerx
        py = self.game.player.rect.centery

        # 4a. If Dungeon Portal is active on the map, venture into the portal!
        if self.game.dungeon_portal.state == "active":
            self.goal_text = "Entering Ancient Dungeon Portal..."
            portal_rect = self.game.dungeon_portal.rect
            self.move_towards(portal_rect.centerx, portal_rect.centery, sim_keys, stop_dist=16.0)
            return sim_keys

        # 4b. Dialogue handling with Master Blacksmith
        if self.game.dialogue_ui.active:
            self.goal_text = "Commissioning Master Blacksmith at the Forge..."
            if self.dialogue_timer <= 0:
                self.dialogue_timer = 0.28
                sim_keys.set(pygame.K_SPACE, True)
                sim_keys.set(pygame.K_e, True)
            return sim_keys

        # 4c. If Master Blacksmith is currently smelting/cooking
        bs = getattr(self.game.map, 'blacksmith_npc', None)
        if bs and bs.state == "SMELTING":
            rem = int(math.ceil(bs.smelt_timer))
            self.goal_text = f"Master Blacksmith is Smelting/Cooking in the Forge ({rem}s)..."
            self.move_towards(bs.stand_pos[0], bs.stand_pos[1] + 30, sim_keys, stop_dist=20.0)
            return sim_keys

        # 4d. Check inventory for raw ores or raw bear meat to bring to Blacksmith
        has_smeltable_ore = False
        has_bear_meat = False
        gold_qty = 0
        for item in self.game.inventory_ui.items:
            name = item.get("name", "")
            qty = item.get("qty", 0)
            if "Gold" in name:
                gold_qty += qty
            if name in ["Iron Ore", "Ruby Ore", "Diamond Ore", "Coal Lump"] and qty > 0:
                has_smeltable_ore = True
            if name in ["Raw Bear Meat", "Raw Meat"] and qty > 0:
                has_bear_meat = True

        if (has_smeltable_ore or has_bear_meat) and gold_qty >= 4 and bs and bs.state == "IDLE":
            self.goal_text = "Delivering Raw Minerals & Game Meat to Master Blacksmith..."
            reached = self.move_towards(bs.rect.centerx, bs.rect.bottom + 18, sim_keys, stop_dist=42.0)
            if reached or math.hypot(bs.rect.centerx - px, bs.rect.centery - py) < 55.0:
                self.game.player.facing = "Up"
                sim_keys.set(pygame.K_e, True)
                if self.action_cooldown <= 0:
                    bs.interact(self.game)
                    self.action_cooldown = 1.0
            return sim_keys

        # 4e. Periodic House Visit (every 60-90s) to sleep or play piano
        if self.house_visit_timer <= 0:
            self.house_visit_timer = 90.0
            self.piano_played = False
            self.house_action = "bed" if not self.game.has_slept_today else "piano"
            self.current_goal = "VISIT_HOUSE"

        if self.current_goal == "VISIT_HOUSE":
            self.goal_text = "Visiting Traditional Timber House..."
            reached = self.move_towards(110, 245, sim_keys, stop_dist=18.0)
            if reached or math.hypot(110 - px, 245 - py) < 32.0:
                sim_keys.set(pygame.K_w, True)
            return sim_keys

        # 4f. Periodic Portal Spawning
        if self.portal_spawn_timer <= 0 and self.game.dungeon_portal.state == "inactive":
            self.portal_spawn_timer = 120.0
            self.game.dungeon_portal.spawn(px + 70, py)
            self.goal_text = "Summoning Ancient Circular Dungeon Portal..."
            return sim_keys

        # 4g. Check achievements progress to prioritize missing achievements
        discoveries = self.game.social_studies_discoveries
        need_cellulose = "cellulose" not in discoveries
        need_mineralogy = "mineralogy" not in discoveries
        need_ecology = "ecology" not in discoveries
        need_metallurgy = "metallurgy" not in discoveries

        # 4h. BEAR HUNTING (Apex Forest Predator)
        active_bears = [o for o in self.game.map.objects if o.get("type") == "bear" and hasattr(o.get("bear_obj"), "hp") and o["bear_obj"].hp > 0]
        if active_bears and (need_ecology or not has_bear_meat):
            closest_bear = min(active_bears, key=lambda o: (o["rect"].centerx - px)**2 + (o["rect"].centery - py)**2)
            bx, by = closest_bear["rect"].centerx, closest_bear["rect"].centery
            dist_to_bear = math.hypot(bx - px, by - py)
            self.goal_text = f"Hunting Wild Forest Bear (HP: {closest_bear['bear_obj'].hp}/3)..."

            for s_idx, it in enumerate(self.game.inventory_ui.items[:9]):
                if "Sword" in it["name"] or "Blade" in it["name"]:
                    self.game.selected_hotbar_slot = s_idx
                    break

            if dist_to_bear > 45.0:
                self.move_towards(bx, by, sim_keys, stop_dist=40.0)
            else:
                if abs(bx - px) > abs(by - py):
                    self.game.player.facing = "Right" if bx > px else "Left"
                else:
                    self.game.player.facing = "Down" if by > py else "Up"
                if not self.game.player.is_attacking and self.action_cooldown <= 0:
                    self.game.player.is_attacking = True
                    self.game.player.action = "Slash"
                    self.game.player.frame_index = 0
                    self.game.player.has_dealt_damage = False
                    self.action_cooldown = 0.35
                    if hasattr(self.game, 'sound_mgr'):
                        self.game.sound_mgr.play('slash')
            return sim_keys

        # 4i. TREE WOODCUTTING (Harvesting timber & cellulose)
        active_trees = [o for o in self.game.map.objects if o.get("type") == "tree" and "hitbox" in o]
        if active_trees and (need_cellulose or (random.random() < 0.5 and not need_mineralogy)):
            closest_tree = min(active_trees, key=lambda o: (o["hitbox"].centerx - px)**2 + (o["hitbox"].centery - py)**2)
            tx = closest_tree["hitbox"].centerx
            ty = closest_tree["hitbox"].bottom + 14
            dist_to_tree = math.hypot(tx - px, ty - py)
            self.goal_text = f"Chopping Tree for Cellulose & Timber (Hits: {closest_tree.get('hits', 0)}/4)..."

            for s_idx, it in enumerate(self.game.inventory_ui.items[:9]):
                if "Axe" in it["name"]:
                    self.game.selected_hotbar_slot = s_idx
                    break

            if dist_to_tree > 35.0:
                self.move_towards(tx, ty, sim_keys, stop_dist=30.0)
            else:
                self.game.player.facing = "Up" if py > closest_tree["hitbox"].centery else "Down"
                if not self.game.player.is_attacking and self.action_cooldown <= 0:
                    self.game.player.is_attacking = True
                    self.game.player.action = "Slash"
                    self.game.player.frame_index = 0
                    self.game.player.has_dealt_damage = False
                    self.action_cooldown = 0.35
                    if hasattr(self.game, 'sound_mgr'):
                        self.game.sound_mgr.play('slash')
            return sim_keys

        # 4j. ORE & MINERAL MINING (Harvesting rocks, iron, rubies, diamonds, coal)
        active_rocks = [o for o in self.game.map.objects if o.get("type") == "mineable_rock" and "hitbox" in o]
        if active_rocks:
            closest_rock = min(active_rocks, key=lambda o: (o["hitbox"].centerx - px)**2 + (o["hitbox"].centery - py)**2)
            rx = closest_rock["hitbox"].centerx
            ry = closest_rock["hitbox"].bottom + 14
            dist_to_rock = math.hypot(rx - px, ry - py)
            r_name = closest_rock["mineable_obj"].name
            self.goal_text = f"Mining {r_name} for Minerals..."

            for s_idx, it in enumerate(self.game.inventory_ui.items[:9]):
                if "Pickaxe" in it["name"]:
                    self.game.selected_hotbar_slot = s_idx
                    break

            if dist_to_rock > 32.0:
                self.move_towards(rx, ry, sim_keys, stop_dist=28.0)
            else:
                self.game.player.facing = "Up" if py > closest_rock["hitbox"].centery else "Down"
                if not self.game.player.is_attacking and self.action_cooldown <= 0:
                    self.game.player.is_attacking = True
                    self.game.player.action = "Slash"
                    self.game.player.frame_index = 0
                    self.game.player.has_dealt_damage = False
                    self.action_cooldown = 0.35
                    if hasattr(self.game, 'sound_mgr'):
                        self.game.sound_mgr.play('slash')
            return sim_keys

        # Default: scout realm
        self.goal_text = "Patrolling Realm & Scouting Resources..."
        self.move_towards(384, 384, sim_keys, stop_dist=30.0)
        return sim_keys

    def draw_hud(self, surface, font):
        is_hover = self.btn_bot_rect.collidepoint(pygame.mouse.get_pos())
        if self.enabled:
            bg_color = (25, 90, 80) if is_hover else (15, 65, 55)
            border_col = (100, 255, 220) if is_hover else (70, 210, 180)
            text_str = "[🤖 BOT: ON]"
            text_col = (200, 255, 240)
        else:
            bg_color = (80, 55, 30) if is_hover else (55, 35, 20)
            border_col = (200, 160, 70) if is_hover else (140, 100, 45)
            text_str = "[🤖 BOT: OFF]"
            text_col = (230, 210, 170)

        pygame.draw.rect(surface, (0, 0, 0), self.btn_bot_rect.move(3, 3))
        pygame.draw.rect(surface, (0, 0, 0), self.btn_bot_rect.inflate(4, 4))
        pygame.draw.rect(surface, bg_color, self.btn_bot_rect)
        pygame.draw.rect(surface, border_col, self.btn_bot_rect, 2)
        txt = font.render(text_str, False, text_col)
        surface.blit(txt, (self.btn_bot_rect.centerx - txt.get_width() // 2, self.btn_bot_rect.centery - txt.get_height() // 2))

        if self.enabled:
            status_str = f"🤖 AI COMPANION: {self.goal_text}"
            stat_font = get_rpg_font(11, bold=True)
            txt_surf = stat_font.render(status_str, False, (255, 245, 180))
            box_w = txt_surf.get_width() + 24
            box_h = 24
            box_x = surface.get_width() // 2 - box_w // 2
            box_y = 56
            pill_rect = pygame.Rect(box_x, box_y, box_w, box_h)

            pulse = (math.sin(pygame.time.get_ticks() * 0.006) + 1.0) * 0.5
            p_border = (int(80 + 175 * pulse), int(210 + 45 * pulse), int(180 + 75 * pulse))

            bg_surf = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
            bg_surf.fill((15, 20, 28, 230))
            surface.blit(bg_surf, pill_rect)
            pygame.draw.rect(surface, p_border, pill_rect, width=2, border_radius=6)
            surface.blit(txt_surf, (pill_rect.centerx - txt_surf.get_width() // 2, pill_rect.centery - txt_surf.get_height() // 2))

class RPGGame:
    def __init__(self, width, height, base_dir):
        self.width = width
        self.height = height
        self.camera = RPGCamera(width, height)
        self.player = RPGPlayer(0, 0, base_dir)
        self.map = RPGMap(base_dir)
        self.sound_mgr = RetroSoundManager()
        self.interior = HouseInterior(width, height, base_dir)
        self.dungeon = DungeonInterior(width, height, base_dir)
        self.piano_ui = PianoUI(width, height)
        self.dialogue_ui = RetroDialogueUI(width, height)
        self.inventory_ui = RPGInventoryUI(width, height)
        self.touch_ctrl = VirtualTouchController(width, height, enabled=False)
        self.dialogue_cooldown = 0.0
        self.dungeon_portal = CircularPortalWorldObject(base_dir)
        self.weather = WeatherSystem(width, height)
        self.selected_hotbar_slot = 0 # 0 to 8 (Keys 1 to 9)
        self.hotbar_rects = []
        self.language = "IDN"
        try:
            _cfg = load_settings()
            self.language = _cfg.get("lang", "IDN")
        except Exception:
            self.language = "IDN"
        
        # Transition state
        self.transition_alpha = 0
        self.transition_state = "none" # none, inside, inside_dungeon, entering_fade_out, entering_dungeon_fade_out, exiting_fade_out, exiting_dungeon_fade_out
        
        # Day / Night and Sleeping state
        self.time_of_day = "DAY" # "DAY" or "NIGHT"
        self.phase_duration = 600.0 # 10 minutes per phase (600 seconds)
        self.phase_timer = 0.0
        self.has_slept_today = False
        self.sleep_state = "none" # "none", "fade_out", "animating_zzz", "wake_up_hold", "fade_in"
        self.sleep_alpha = 0.0
        self.sleep_hold_timer = 0.0
        self.near_bed = False
        self.near_piano = False
        self.bed_message = ""
        self.bed_message_timer = 0.0

        # Animated ZZZ sleeping frames
        self.zzz_frames = ["Z.", "Z..", "Z...", "ZZ.", "ZZ..", "ZZ...", "ZZz.", "ZZz..", "ZZz..."]
        self.zzz_frame = 0
        self.zzz_loop_count = 0
        self.zzz_timer = 0.0

        # On-screen HUD Buttons
        self.spawn_btn_rect = pygame.Rect(width - 165, 14, 150, 34)
        self.btn_bag_rect = pygame.Rect(width - 320, 14, 145, 34)
        self.btn_codex_rect = pygame.Rect(width - 505, 14, 175, 34)
        self.btn_bot_rect = pygame.Rect(width - 665, 14, 145, 34)
        self.btn_main_menu_rect = pygame.Rect(20, 94, 140, 30)
        self.bot_controller = RPGBotController(self)

        # World Social Studies Curriculum Tracking & Discoveries
        self.codex_ui = WorldSocialStudiesCodexUI(width, height, base_dir)
        self.social_studies_discoveries = set()
        self.discovery_popup_text = ""
        self.discovery_popup_timer = 0.0
        self.achievement_unlocked = False
        self.achievement_banner_timer = 0.0

        # Initial discoveries from satchel starter items
        self.discover_social_studies("currency")
        self.discover_social_studies("ethnobotany")
        self.discover_social_studies("agrarian")

    def resize(self, width, height):
        self.width = width
        self.height = height
        if hasattr(self, 'camera') and self.camera:
            self.camera.width = width
            self.camera.height = height
            if hasattr(self.camera, 'camera'):
                self.camera.camera.width = width
                self.camera.camera.height = height
        self.spawn_btn_rect = pygame.Rect(width - 165, 14, 150, 34)
        self.btn_bag_rect = pygame.Rect(width - 320, 14, 145, 34)
        self.btn_codex_rect = pygame.Rect(width - 505, 14, 175, 34)
        self.btn_bot_rect = pygame.Rect(width - 665, 14, 145, 34)
        if hasattr(self, 'bot_controller'):
            self.bot_controller.btn_bot_rect = self.btn_bot_rect
        if hasattr(self, 'weather') and self.weather:
            self.weather.width = width
            self.weather.height = height
        if hasattr(self, 'touch_ctrl') and self.touch_ctrl:
            self.touch_ctrl.rebuild_layout(width, height)
        if hasattr(self, 'inventory_ui') and self.inventory_ui:
            self.inventory_ui.width = width
            self.inventory_ui.height = height
        if hasattr(self, 'dialogue_ui') and self.dialogue_ui:
            self.dialogue_ui.width = width
            self.dialogue_ui.height = height
        if hasattr(self, 'codex_ui') and self.codex_ui:
            self.codex_ui.width = width
            self.codex_ui.height = height

    def discover_social_studies(self, key):
        if key in GLOBAL_SOCIAL_STUDIES_DATA and key not in self.social_studies_discoveries:
            self.social_studies_discoveries.add(key)
            self.sound_mgr.play('key')
            title = GLOBAL_SOCIAL_STUDIES_DATA[key]["title"]
            self.discovery_popup_text = f"NEW WORLD SOCIAL STUDIES ENTRY: {title}!"
            self.discovery_popup_timer = 3.5
            if len(self.social_studies_discoveries) == len(GLOBAL_SOCIAL_STUDIES_DATA):
                self.achievement_unlocked = True
                self.achievement_banner_timer = 6.0
                self.sound_mgr.play('chest')

    def start_sleep(self):
        self.sleep_state = "fade_out"
        self.sleep_alpha = 0.0
        self.transition_alpha = 0.0 # Clear door transition alpha so screen never gets stuck black!
        self.discover_social_studies("climatology")

    def get_equipped_item(self):
        if hasattr(self, 'inventory_ui') and self.inventory_ui and hasattr(self.inventory_ui, 'items'):
            if 0 <= self.selected_hotbar_slot < len(self.inventory_ui.items):
                return self.inventory_ui.items[self.selected_hotbar_slot]
        return None

    def consume_equipped_item(self):
        it = self.get_equipped_item()
        if not it:
            return
        heal = it.get("heal", 0)
        is_food = (heal > 0) or ("Meat" in it["name"]) or ("Steak" in it["name"]) or ("Trout" in it["name"]) or ("Leaf" in it["name"])
        if is_food and it["qty"] > 0:
            heal_amt = heal if heal > 0 else 20
            self.player.hp = min(self.player.max_hp, self.player.hp + heal_amt)
            it["qty"] -= 1
            if it["qty"] <= 0:
                self.inventory_ui.items.remove(it)
            if hasattr(self, 'sound_mgr'):
                self.sound_mgr.play('potion')
            self.prompt_text = f"Consumed {it['name']}! Restored {heal_amt} HP ({self.player.hp}/{self.player.max_hp})"
            self.prompt_timer = 2.5
            if "Leaf" in it["name"]:
                self.discover_social_studies("ethnobotany")
            elif "Steak" in it["name"] or "Trout" in it["name"] or "Meat" in it["name"]:
                self.discover_social_studies("agrarian")

    def update(self, dt, events=None):
        keys = pygame.key.get_pressed()
        
        # Check mouse clicks for HUD buttons
        mx, my = pygame.mouse.get_pos()
        if events:
            for event in events:
                if self.touch_ctrl and not self.piano_ui.active:
                    self.touch_ctrl.handle_event(event)

                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if hasattr(self, 'btn_main_menu_rect') and self.btn_main_menu_rect.collidepoint(mx, my):
                        self.request_main_menu = True
                    elif hasattr(self, 'btn_bag_rect') and self.btn_bag_rect.collidepoint(mx, my):
                        self.inventory_ui.active = not self.inventory_ui.active
                    elif hasattr(self, 'btn_codex_rect') and self.btn_codex_rect.collidepoint(mx, my):
                        self.codex_ui.active = not self.codex_ui.active
                        if self.codex_ui.active:
                            self.codex_ui.open()
                            self.sound_mgr.play('key')
                            self.inventory_ui.active = False
                            return
                    elif hasattr(self, 'spawn_btn_rect') and self.spawn_btn_rect.collidepoint(mx, my):
                        if self.dungeon_portal.state == "inactive" and self.transition_state == "none":
                            self.dungeon_portal.spawn(self.player.rect.centerx, self.player.rect.centery)
                    elif hasattr(self, 'btn_bot_rect') and self.btn_bot_rect.collidepoint(mx, my):
                        if hasattr(self, 'bot_controller'):
                            self.bot_controller.toggle()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_F4:
                        if hasattr(self, 'bot_controller'):
                            self.bot_controller.toggle()
                    elif event.key == pygame.K_j:
                        self.codex_ui.active = not self.codex_ui.active
                        if self.codex_ui.active:
                            self.codex_ui.open()
                            self.sound_mgr.play('key')
                            self.inventory_ui.active = False
                            return
                    elif event.key == pygame.K_ESCAPE:
                        if self.codex_ui.active:
                            self.codex_ui.active = False
                        elif self.inventory_ui.active:
                            self.inventory_ui.active = False
                        elif self.transition_state == "inside":
                            self.transition_state = "exiting_fade_out"
                        elif self.transition_state == "inside_dungeon":
                            self.transition_state = "exiting_dungeon_fade_out"
                        elif self.piano_ui.active:
                            self.piano_ui.active = False
                        elif self.dialogue_ui.active:
                            self.dialogue_ui.active = False
                        else:
                            self.request_main_menu = True

                # 9-Slot Hotbar Input Handling
                if not self.inventory_ui.active and not self.codex_ui.active and not self.dialogue_ui.active and not self.piano_ui.active:
                    if event.type == pygame.KEYDOWN:
                        if event.key in (pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4, pygame.K_5, pygame.K_6, pygame.K_7, pygame.K_8, pygame.K_9):
                            self.selected_hotbar_slot = event.key - pygame.K_1
                            it = self.get_equipped_item()
                            if it:
                                self.prompt_text = f"Equipped: {it['name']}"
                                self.prompt_timer = 2.0
                        elif event.key == pygame.K_f:
                            self.consume_equipped_item()
                    elif event.type == pygame.MOUSEWHEEL:
                        self.selected_hotbar_slot = (self.selected_hotbar_slot - event.y) % 9
                        it = self.get_equipped_item()
                        if it:
                            self.prompt_text = f"Equipped: {it['name']}"
                            self.prompt_timer = 1.5
                    elif event.type == pygame.MOUSEBUTTONDOWN:
                        if event.button == 1:
                            if hasattr(self, 'hotbar_rects'):
                                for s_idx, s_rect in enumerate(self.hotbar_rects):
                                    if s_rect.collidepoint(event.pos):
                                        self.selected_hotbar_slot = s_idx
                                        it = self.get_equipped_item()
                                        if it:
                                            self.prompt_text = f"Equipped: {it['name']}"
                                            self.prompt_timer = 2.0
                                        break
                        elif event.button == 3:
                            self.consume_equipped_item()

        # Touch Controls Button Actions (Phones, Tablets & Mobile Web)
        if self.touch_ctrl and self.touch_ctrl.enabled:
            if self.touch_ctrl.was_button_tapped("inventory"):
                self.inventory_ui.active = not self.inventory_ui.active
            if self.touch_ctrl.was_button_tapped("menu"):
                if self.codex_ui.active:
                    self.codex_ui.active = False
                elif self.inventory_ui.active:
                    self.inventory_ui.active = False
                elif self.piano_ui.active:
                    self.piano_ui.active = False
                elif self.dialogue_ui.active:
                    self.dialogue_ui.active = False
                else:
                    self.request_main_menu = True

        # AI Companion Simulated Key Controls
        if hasattr(self, 'bot_controller') and self.bot_controller.enabled:
            bot_keys = self.bot_controller.get_simulated_keys(keys, dt)
            if bot_keys is not None:
                keys = bot_keys

        # Key 'P' or button click to immediately spawn portal near player!
        if keys[pygame.K_p] and self.dungeon_portal.state == "inactive" and self.transition_state == "none":
            self.dungeon_portal.spawn(self.player.rect.centerx, self.player.rect.centery)
        
        # If Inventory modal is active, update Inventory and suspend world movement
        if self.inventory_ui.active:
            self.inventory_ui.update(dt, events or [], self)
            return

        # If World Codex modal is active, update Codex and suspend world movement
        if self.codex_ui.active:
            self.codex_ui.update(dt, events or [])
            return

        # Update Timers
        if self.discovery_popup_timer > 0:
            self.discovery_popup_timer -= dt
        if self.achievement_banner_timer > 0:
            self.achievement_banner_timer -= dt

        # Discovery Triggers
        if self.piano_ui.active:
            self.discover_social_studies("music")
        if self.transition_state == "inside":
            self.discover_social_studies("architecture")
        elif self.transition_state == "inside_dungeon":
            self.discover_social_studies("archaeology")
        if self.weather.current_weather in ("RAIN", "THUNDERSTORM"):
            self.discover_social_studies("climatology")

        # If Piano UI minigame is active, update Piano UI and suspend world movement
        if self.piano_ui.active:
            self.piano_ui.update(dt, events, keys)
            return

        # Update Retro Dialogue UI
        if self.dialogue_cooldown > 0:
            self.dialogue_cooldown -= dt

        if self.dialogue_ui.active:
            self.dialogue_ui.update(dt, events or [], self.sound_mgr, game=self)
            if not self.dialogue_ui.active:
                self.dialogue_cooldown = 0.5 # 0.5s cooldown after closing dialogue!
            return

        # Check [E] key interaction with nearby Village NPCs or toggle Satchel Inventory
        if keys[pygame.K_e] and self.dialogue_cooldown <= 0 and self.transition_state == "none" and not self.dialogue_ui.active:
            near_npc = None
            for npc in self.map.all_npcs:
                if self.player.rect.inflate(40, 40).colliderect(npc.rect):
                    near_npc = npc
                    break
            if near_npc:
                if isinstance(near_npc, RPGBlacksmithNPC):
                    near_npc.interact(self)
                else:
                    self.dialogue_ui.start_dialogue(near_npc, self.sound_mgr)
            elif not self.piano_ui.active:
                self.inventory_ui.active = not self.inventory_ui.active
                self.dialogue_cooldown = 0.28
        
        # Bed prompt message timer
        if self.bed_message_timer > 0:
            self.bed_message_timer -= dt
            if self.bed_message_timer <= 0:
                self.bed_message = ""

        # Automatic 10-minute Day / Night cycle progression
        self.phase_timer += dt
        if self.phase_timer >= self.phase_duration:
            self.phase_timer = 0.0
            if self.time_of_day == "DAY":
                self.time_of_day = "NIGHT"
            else:
                self.time_of_day = "DAY"
            self.has_slept_today = False # Reset 1-sleep-per-phase restriction for new phase

        # Handle Sleeping Animation Transition
        if self.sleep_state == "fade_out":
            self.sleep_alpha += 255 * dt * 2.0
            if self.sleep_alpha >= 255:
                self.sleep_alpha = 255
                self.sleep_state = "animating_zzz"
                self.zzz_frame = 0
                self.zzz_loop_count = 0
                self.zzz_timer = 0.0
                # Toggle Day / Night
                if self.time_of_day == "DAY":
                    self.time_of_day = "NIGHT"
                else:
                    self.time_of_day = "DAY"
                self.phase_timer = 0.0 # Reset 10-minute timer for the new phase!
                self.has_slept_today = True
                # Randomize weather when sleeping!
                self.weather.set_weather(random.choice(["CLEAR", "CLOUDY", "RAIN", "THUNDERSTORM"]))
            return

        elif self.sleep_state == "animating_zzz":
            self.zzz_timer += dt
            if self.zzz_timer >= 0.15: # ~0.15s per frame
                self.zzz_timer = 0.0
                self.zzz_frame += 1
                if self.zzz_frame >= len(self.zzz_frames):
                    self.zzz_frame = 0
                    self.zzz_loop_count += 1
                    if self.zzz_loop_count >= 3: # 3 full loops complete!
                        self.sleep_state = "wake_up_hold"
                        self.sleep_hold_timer = 1.8
            return
            
        elif self.sleep_state == "wake_up_hold":
            self.sleep_hold_timer -= dt
            if self.sleep_hold_timer <= 0:
                self.sleep_state = "fade_in"
            return
            
        elif self.sleep_state == "fade_in":
            self.sleep_alpha -= 255 * dt * 2.0
            if self.sleep_alpha <= 0:
                self.sleep_alpha = 0.0
                self.sleep_state = "none"
            return
        
        # Handle House Transition States
        if self.transition_state == "entering_fade_out":
            self.transition_alpha += 255 * dt * 2.5
            if self.transition_alpha >= 255:
                self.transition_alpha = 255
                self.transition_state = "entering_fade_in"
                # Save outside door position so exiting returns player right outside the house door
                self.outside_door_pos = (self.player.rect.x, self.player.rect.y + 35)
                # Position player at doorway inside house
                self.player.rect.x = self.interior.room_rect.centerx - self.player.rect.width // 2
                self.player.rect.y = self.interior.room_rect.bottom - self.player.rect.height - 25
            return
            
        elif self.transition_state == "entering_fade_in":
            self.transition_alpha -= 255 * dt * 2.5
            if self.transition_alpha <= 0:
                self.transition_alpha = 0
                self.transition_state = "inside"
            self.interior.update_player(self.player, dt, keys, self)
            return

        elif self.transition_state == "inside":
            # Update interior player movement and collision
            self.interior.update_player(self.player, dt, keys, self)
            
            # Check for exit doorway or ESC key
            at_door = (self.player.rect.bottom >= self.interior.room_rect.bottom - 20) and keys[pygame.K_s]
            if keys[pygame.K_ESCAPE] or at_door:
                self.transition_state = "exiting_fade_out"
            return
            
        elif self.transition_state == "exiting_fade_out":
            self.transition_alpha += 255 * dt * 2.5
            if self.transition_alpha >= 255:
                self.transition_alpha = 255
                self.transition_state = "exiting_fade_in"
                # Restore player to exact position right outside the house door
                if hasattr(self, 'outside_door_pos') and self.outside_door_pos:
                    self.player.rect.x, self.player.rect.y = self.outside_door_pos
                else:
                    self.player.rect.y += 25
            return

        elif self.transition_state == "exiting_fade_in":
            self.transition_alpha -= 255 * dt * 2.5
            if self.transition_alpha <= 0:
                self.transition_alpha = 0
                self.transition_state = "none"
            self.player.update(dt, keys, self.map, touch_ctrl=self.touch_ctrl)
            self.camera.update(self.player.rect, dt)
            return

        # Handle Dungeon Transition States
        elif self.transition_state == "entering_dungeon_fade_out":
            self.transition_alpha += 255 * dt * 2.5
            if self.transition_alpha >= 255:
                self.transition_alpha = 255
                self.transition_state = "entering_dungeon_fade_in"
                # Position player on the floor tile directly in front of the entrance door
                self.player.rect.x = 650
                self.player.rect.y = 816
                self.player.facing = "Down"
                self.dungeon.dungeon_camera.float_x = 650.0
                self.dungeon.dungeon_camera.float_y = 816.0
                self.dungeon.dungeon_camera.update(self.player.rect, 0.01)
            return

        elif self.transition_state == "entering_dungeon_fade_in":
            self.transition_alpha -= 255 * dt * 2.5
            if self.transition_alpha <= 0:
                self.transition_alpha = 0
                self.transition_state = "inside_dungeon"
            self.dungeon.update_player(self.player, dt, keys, self)
            return

        elif self.transition_state == "inside_dungeon":
            self.dungeon.update_player(self.player, dt, keys, self)
            if keys[pygame.K_ESCAPE]:
                self.transition_state = "exiting_dungeon_fade_out"
            return

        elif self.transition_state == "exiting_dungeon_fade_out":
            self.transition_alpha += 255 * dt * 2.5
            if self.transition_alpha >= 255:
                self.transition_alpha = 255
                self.transition_state = "exiting_dungeon_fade_in"
                if hasattr(self, 'outside_portal_pos') and self.outside_portal_pos:
                    self.player.rect.x, self.player.rect.y = self.outside_portal_pos
            return

        elif self.transition_state == "exiting_dungeon_fade_in":
            self.transition_alpha -= 255 * dt * 2.5
            if self.transition_alpha <= 0:
                self.transition_alpha = 0
                self.transition_state = "none"
            self.player.update(dt, keys, self.map, touch_ctrl=self.touch_ctrl, game=self)
            self.camera.update(self.player.rect, dt)
            return

        # Normal gameplay update (Outside World)
        self.player.update(dt, keys, self.map, touch_ctrl=self.touch_ctrl, game=self)
        self.camera.update(self.player.rect, dt)
        self.map.update(dt, self.player, game=self)
        
        # Update Weather System
        self.weather.update(dt, is_outside=(self.transition_state == "none"), sound_mgr=self.sound_mgr)
        
        # Update World Portal Spawner
        self.dungeon_portal.update(dt, self.player.rect.centerx, self.player.rect.centery, self.map)
        
        # Check if player touches active dungeon portal
        if self.dungeon_portal.state == "active" and self.transition_state == "none":
            player_hitbox = pygame.Rect(self.player.rect.x + 16, self.player.rect.bottom - 20, 32, 16)
            if player_hitbox.colliderect(self.dungeon_portal.rect):
                self.transition_state = "entering_dungeon_fade_out"
        
        # Update bears across the map
        for obj in self.map.objects:
            if obj.get("type") == "bear":
                b = obj["bear_obj"]
                b.update(dt, self.player, self.map)
                obj["rect"] = b.rect
                obj["hitbox"] = b.hitbox
                tz = obj["trans_zone"]
                tz.x = b.rect.x + 8
                tz.y = b.rect.y
        
        # Trigger door transition
        if self.player.door_interaction and self.transition_state == "none":
            self.transition_state = "entering_fade_out"
            self.player.door_interaction = False
        
        # On-screen HUD Buttons
        self.spawn_btn_rect = pygame.Rect(self.width - 170, 14, 150, 34)
        self.btn_bag_rect = pygame.Rect(self.width - 325, 14, 145, 34)
        self.btn_codex_rect = pygame.Rect(self.width - 510, 14, 175, 34)
        self.btn_main_menu_rect = pygame.Rect(20, 94, 140, 30)

    def draw(self, surface):
        surface.fill((0, 0, 0))
        
        if self.transition_state in ["inside", "entering_fade_in", "exiting_fade_out"]:
            self.interior.draw(surface, self.player, self)
        elif self.transition_state in ["inside_dungeon", "entering_dungeon_fade_in", "exiting_dungeon_fade_out"]:
            self.dungeon.draw(surface, self.player, self)
        else:
            # Draw Weather Cloud Shadows on terrain
            self.weather.draw_cloud_shadows(surface, self.camera)

            # Draw Map
            self.map.draw(surface, self.camera, self.player)
            
            # Draw Circular Portal on World Map
            self.dungeon_portal.draw(surface, self.camera)
            
            # Calculate remaining phase time
            rem_sec = max(0, int(self.phase_duration - self.phase_timer))
            mins = rem_sec // 60
            secs = rem_sec % 60
            time_str = f"{mins}:{secs:02d}"

            # Weather Icon Mapping for HUD
            weather_labels = {
                "CLEAR": "CLEAR",
                "CLOUDY": "CLOUDY",
                "RAIN": "RAIN",
                "THUNDERSTORM": "THUNDERSTORM"
            }
            w_label = weather_labels.get(self.weather.current_weather, "CLEAR")

            # Apply Night Tint overlay when outside at Night (Pixel Comic Sans font)
            font = get_rpg_font(13, bold=True)
            if self.time_of_day == "NIGHT":
                night_overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
                night_overlay.fill((10, 20, 65, 140)) # Moonlit night tint
                surface.blit(night_overlay, (0, 0))

                # Draw night HUD text
                txt = font.render(f"NIGHT TIME ({time_str})  |  {w_label}", False, (180, 200, 255))
                surface.blit(txt, (20, 20))
            else:
                # Draw day HUD text
                txt = font.render(f"DAY TIME ({time_str})  |  {w_label}", False, (255, 255, 255))
                surface.blit(txt, (20, 20))

            # Draw Weather Overlay (Atmospheric Tint, Rain Streaks, Splashes, Lightning Flash)
            self.weather.draw(surface)

            # Draw Player RPG Healthbar (Top Left HUD)
            hp_bar_x = 20
            hp_bar_y = 40
            hp_bar_w = 180
            hp_bar_h = 16

            # Outer dark frame with drop shadow
            pygame.draw.rect(surface, (0, 0, 0), (hp_bar_x - 3, hp_bar_y - 3, hp_bar_w + 6, hp_bar_h + 6), border_radius=5)
            pygame.draw.rect(surface, (28, 18, 12), (hp_bar_x - 2, hp_bar_y - 2, hp_bar_w + 4, hp_bar_h + 4), border_radius=4)
            pygame.draw.rect(surface, (55, 20, 20), (hp_bar_x, hp_bar_y, hp_bar_w, hp_bar_h), border_radius=3)

            hp_ratio = max(0.0, min(1.0, self.player.hp / float(self.player.max_hp)))
            fill_hp_w = int(hp_bar_w * hp_ratio)
            if fill_hp_w > 0:
                if hp_ratio > 0.5:
                    bar_c = (46, 204, 113)
                    top_c = (120, 240, 160)
                elif hp_ratio > 0.25:
                    bar_c = (243, 156, 18)
                    top_c = (255, 210, 110)
                else:
                    bar_c = (231, 76, 60)
                    top_c = (255, 130, 120)

                pygame.draw.rect(surface, bar_c, (hp_bar_x, hp_bar_y, fill_hp_w, hp_bar_h), border_radius=2)
                pygame.draw.rect(surface, top_c, (hp_bar_x, hp_bar_y, fill_hp_w, max(1, hp_bar_h // 3)), border_radius=2)

            pygame.draw.rect(surface, (255, 215, 80), (hp_bar_x - 1, hp_bar_y - 1, hp_bar_w + 2, hp_bar_h + 2), 1, border_radius=3)

            font_hp = get_rpg_font(10, bold=True)
            hp_str = f"HP: {int(self.player.hp)} / {int(self.player.max_hp)}"
            hp_txt = font_hp.render(hp_str, True, (255, 255, 255))
            hp_shd = font_hp.render(hp_str, True, (0, 0, 0))
            surface.blit(hp_shd, (hp_bar_x + hp_bar_w // 2 - hp_txt.get_width() // 2 + 1, hp_bar_y + 2))
            surface.blit(hp_txt, (hp_bar_x + hp_bar_w // 2 - hp_txt.get_width() // 2, hp_bar_y + 1))

            # Draw Silver Key HUD Icon & Counter (RPG Dungeon Progress)
            key_x = 20
            key_y = 66
            key_txt = font.render(f"DUNGEON KEYS: {self.player.silver_keys_collected} / 4", False, (255, 230, 90))
            surface.blit(key_txt, (key_x, key_y))

            # Draw On-Screen 16-Bit MAIN MENU [ESC] GUI Button
            btn_font = get_rpg_font(11, bold=True)
            mx, my = pygame.mouse.get_pos()
            is_mm_hover = self.btn_main_menu_rect.collidepoint(mx, my)
            mm_bg = (100, 60, 25) if is_mm_hover else (75, 40, 15)
            mm_border = (255, 215, 80) if is_mm_hover else (160, 120, 50)
            pygame.draw.rect(surface, (0, 0, 0), self.btn_main_menu_rect.move(3, 3))
            pygame.draw.rect(surface, (0, 0, 0), self.btn_main_menu_rect.inflate(4, 4))
            pygame.draw.rect(surface, mm_bg, self.btn_main_menu_rect)
            pygame.draw.rect(surface, mm_border, self.btn_main_menu_rect, 2)
            mm_txt = btn_font.render(t("hud_menu", self.language), False, (255, 240, 180) if is_mm_hover else (220, 210, 190))
            surface.blit(mm_txt, (self.btn_main_menu_rect.centerx - mm_txt.get_width() // 2, self.btn_main_menu_rect.centery - mm_txt.get_height() // 2))

            # Draw On-Screen 16-Bit SATCHEL [E] GUI Button
            is_bag_hover = self.btn_bag_rect.collidepoint(mx, my)
            bag_bg = (120, 70, 30) if is_bag_hover else (90, 50, 20)
            bag_border = (255, 215, 80) if is_bag_hover else (180, 140, 60)
            pygame.draw.rect(surface, (0, 0, 0), self.btn_bag_rect.move(3, 3))
            pygame.draw.rect(surface, (0, 0, 0), self.btn_bag_rect.inflate(4, 4))
            pygame.draw.rect(surface, bag_bg, self.btn_bag_rect)
            pygame.draw.rect(surface, bag_border, self.btn_bag_rect, 2)
            bag_txt = btn_font.render(t("hud_bag", self.language), False, (255, 235, 150) if is_bag_hover else (230, 210, 170))
            surface.blit(bag_txt, (self.btn_bag_rect.centerx - bag_txt.get_width() // 2, self.btn_bag_rect.centery - bag_txt.get_height() // 2))

            # Draw On-Screen 16-Bit WORLD CODEX [J] GUI Button
            is_codex_hover = self.btn_codex_rect.collidepoint(mx, my)
            unlocked_cnt = len(self.social_studies_discoveries)
            codex_bg = (130, 85, 30) if is_codex_hover else (95, 55, 18)
            codex_border = (255, 220, 90) if is_codex_hover else (190, 150, 60)
            pygame.draw.rect(surface, (0, 0, 0), self.btn_codex_rect.move(3, 3))
            pygame.draw.rect(surface, (0, 0, 0), self.btn_codex_rect.inflate(4, 4))
            pygame.draw.rect(surface, codex_bg, self.btn_codex_rect)
            total_codex = len(GLOBAL_SOCIAL_STUDIES_DATA)
            codex_lbl = f"{t('hud_codex', self.language)} ({unlocked_cnt}/{total_codex})"
            codex_txt = btn_font.render(codex_lbl, False, (255, 240, 160) if is_codex_hover else (230, 210, 170))
            surface.blit(codex_txt, (self.btn_codex_rect.centerx - codex_txt.get_width() // 2, self.btn_codex_rect.centery - codex_txt.get_height() // 2))

            # Draw On-Screen 16-Bit SPAWN PORTAL GUI Button
            is_hover = self.spawn_btn_rect.collidepoint(mx, my)
            
            bg_color = (130, 75, 35) if is_hover else (110, 60, 25)
            border_gold = (255, 220, 90) if is_hover else (200, 160, 60)
            
            pygame.draw.rect(surface, (0, 0, 0), self.spawn_btn_rect.move(3, 3)) # Drop shadow
            pygame.draw.rect(surface, (0, 0, 0), self.spawn_btn_rect.inflate(4, 4)) # Black outline
            pygame.draw.rect(surface, bg_color, self.spawn_btn_rect) # Base
            pygame.draw.rect(surface, border_gold, self.spawn_btn_rect, 2) # Gold border
            
            btn_txt_str = t("hud_portal_active", self.language) if self.dungeon_portal.state != "inactive" else t("hud_spawn_portal", self.language)
            btn_color = (100, 255, 220) if self.dungeon_portal.state != "inactive" else ((255, 240, 160) if is_hover else (230, 210, 170))
            
            btn_txt = btn_font.render(btn_txt_str, False, btn_color)
            surface.blit(btn_txt, (self.spawn_btn_rect.centerx - btn_txt.get_width() // 2, self.spawn_btn_rect.centery - btn_txt.get_height() // 2))

            # Draw On-Screen 16-Bit [🤖 BOT: ON / OFF] GUI Button and Status Pill
            if hasattr(self, 'bot_controller'):
                self.bot_controller.draw_hud(surface, btn_font)
        
        # Draw transition overlay
        if self.transition_alpha > 0:
            overlay = pygame.Surface((self.width, self.height))
            overlay.fill((0, 0, 0))
            overlay.set_alpha(int(self.transition_alpha))
            surface.blit(overlay, (0, 0))

        # Draw Sleeping overlay (Pixel Comic Sans font)
        if self.sleep_alpha > 0:
            sleep_overlay = pygame.Surface((self.width, self.height))
            sleep_overlay.fill((0, 0, 0))
            sleep_overlay.set_alpha(int(self.sleep_alpha))
            surface.blit(sleep_overlay, (0, 0))

            if self.sleep_state in ["animating_zzz", "wake_up_hold"]:
                font_big = get_rpg_font(32, bold=True)
                font_mid = get_rpg_font(16, bold=True)
                
                # ZZZ Animated Frame
                zzz_text = self.zzz_frames[self.zzz_frame] if self.sleep_state == "animating_zzz" else "ZZz..."
                txt_zzz = font_big.render(zzz_text, False, (255, 235, 120))
                surface.blit(txt_zzz, (self.width // 2 - txt_zzz.get_width() // 2, self.height // 2 - 50))
                
                # Sleeping... subtitle
                txt_sleep = font_mid.render("Sleeping...", False, (200, 200, 220))
                surface.blit(txt_sleep, (self.width // 2 - txt_sleep.get_width() // 2, self.height // 2 - 10))

                # Wake up message (appears below ZZZ after 3 loops complete)
                if self.sleep_state == "wake_up_hold":
                    wake_str = f"You wake up, Outside it is {self.time_of_day}!"
                    color = (180, 220, 255) if self.time_of_day == "NIGHT" else (255, 230, 140)
                    txt_wake = font_mid.render(wake_str, False, color)
                    surface.blit(txt_wake, (self.width // 2 - txt_wake.get_width() // 2, self.height // 2 + 35))

        # Draw bed prompt message (Pixel Comic Sans font)
        if self.bed_message:
            font = get_rpg_font(12, bold=True)
            msg_surf = font.render(self.bed_message, False, (255, 220, 100))
            bg_rect = msg_surf.get_rect(center=(self.width // 2, self.height - 40)).inflate(20, 10)
            pygame.draw.rect(surface, (20, 20, 30), bg_rect)
            pygame.draw.rect(surface, (255, 200, 80), bg_rect, 2)
            surface.blit(msg_surf, msg_surf.get_rect(center=(self.width // 2, self.height - 40)))

        # Draw 9-Slot Hotbar HUD at bottom center
        if not self.inventory_ui.active and not self.codex_ui.active and not self.piano_ui.active:
            hb_slot_w = 48
            hb_slot_h = 48
            hb_gap = 4
            total_hb_w = 9 * hb_slot_w + 8 * hb_gap + 12
            hb_x = (self.width - total_hb_w) // 2
            hb_y = self.height - 62
            hb_box = pygame.Rect(hb_x, hb_y, total_hb_w, hb_slot_h + 8)

            pygame.draw.rect(surface, (14, 10, 8), hb_box, border_radius=8)
            pygame.draw.rect(surface, (120, 85, 45), hb_box, width=2, border_radius=8)

            font_hb = get_rpg_font(10, bold=True)
            font_hb_sm = get_rpg_font(9, bold=True)

            self.hotbar_rects = []
            for s_idx in range(9):
                sx = hb_x + 6 + s_idx * (hb_slot_w + hb_gap)
                sy = hb_y + 4
                s_rect = pygame.Rect(sx, sy, hb_slot_w, hb_slot_h)
                self.hotbar_rects.append(s_rect)

                is_selected = (s_idx == self.selected_hotbar_slot)
                bg_col = (50, 36, 22) if is_selected else (24, 18, 14)
                border_col = (255, 225, 90) if is_selected else (75, 55, 35)
                border_w = 3 if is_selected else 1

                pygame.draw.rect(surface, bg_col, s_rect, border_radius=6)
                pygame.draw.rect(surface, border_col, s_rect, width=border_w, border_radius=6)

                # Hotkey number tag at top left
                num_surf = font_hb_sm.render(str(s_idx + 1), True, (255, 220, 100) if is_selected else (130, 110, 85))
                surface.blit(num_surf, (sx + 4, sy + 2))

                # Item in slot (from inventory items 0-8)
                if s_idx < len(self.inventory_ui.items):
                    it = self.inventory_ui.items[s_idx]
                    img = it.get("img")
                    if img:
                        scaled_img = pygame.transform.scale(img, (36, 36))
                        surface.blit(scaled_img, scaled_img.get_rect(center=s_rect.center))
                    
                    # Quantity badge if > 1
                    if it.get("qty", 1) > 1:
                        q_str = str(it["qty"])
                        q_txt = font_hb.render(q_str, True, (255, 255, 255))
                        q_shd = font_hb.render(q_str, True, (0, 0, 0))
                        surface.blit(q_shd, (s_rect.right - q_txt.get_width() - 3, s_rect.bottom - q_txt.get_height() - 1))
                        surface.blit(q_txt, (s_rect.right - q_txt.get_width() - 4, s_rect.bottom - q_txt.get_height() - 2))

            # Floating equipped item tooltip above hotbar
            equipped_item = self.get_equipped_item()
            if equipped_item:
                eq_name = equipped_item["name"]
                eq_surf = font_hb.render(f"[Slot {self.selected_hotbar_slot + 1}] {eq_name}", True, (255, 235, 140))
                eq_bg = pygame.Rect(self.width // 2 - eq_surf.get_width() // 2 - 8, hb_y - 20, eq_surf.get_width() + 16, 18)
                pygame.draw.rect(surface, (14, 10, 8), eq_bg, border_radius=4)
                pygame.draw.rect(surface, (180, 140, 60), eq_bg, width=1, border_radius=4)
                surface.blit(eq_surf, (eq_bg.x + 8, eq_bg.y + 1))

        # Draw Playable Piano Minigame Overlay
        self.piano_ui.draw(surface)

        # Draw Retro Dialogue Textbox Overlay
        self.dialogue_ui.draw(surface)

        # Draw Inventory Overlay Modal (rendered on top)
        self.inventory_ui.draw(surface)

        # Draw Discovery Notification Popup (Top Center)
        if not self.codex_ui.active and self.discovery_popup_timer > 0 and self.discovery_popup_text:
            font_popup = get_rpg_font(13, bold=True)
            p_txt = font_popup.render(self.discovery_popup_text, True, (255, 230, 90))
            sub_hint = get_rpg_font(10, bold=True).render("Press [J] to open World Codex & read curriculum lore", True, (230, 210, 160))
            bw = max(p_txt.get_width(), sub_hint.get_width()) + 36
            bh = 48
            bx = (self.width - bw) // 2
            by = 62
            pop_rect = pygame.Rect(bx, by, bw, bh)
            pygame.draw.rect(surface, (20, 14, 8), pop_rect, border_radius=8)
            pygame.draw.rect(surface, (220, 165, 40), pop_rect, 2, border_radius=8)
            surface.blit(p_txt, p_txt.get_rect(centerx=pop_rect.centerx, top=pop_rect.top + 7))
            surface.blit(sub_hint, sub_hint.get_rect(centerx=pop_rect.centerx, top=pop_rect.top + 27))

        # Draw Grand Achievement Unlocked Banner (Celebratory Milestone)
        if not self.codex_ui.active and self.achievement_banner_timer > 0:
            ach_w = min(720, self.width - 40)
            ach_h = 76
            ach_x = (self.width - ach_w) // 2
            ach_y = 70
            ach_rect = pygame.Rect(ach_x, ach_y, ach_w, ach_h)
            
            # Gold celebratory background
            pygame.draw.rect(surface, (0, 0, 0), ach_rect.move(4, 4), border_radius=10)
            pygame.draw.rect(surface, (30, 18, 10), ach_rect, border_radius=10)
            pygame.draw.rect(surface, (255, 215, 60), ach_rect, 3, border_radius=10)
            pygame.draw.rect(surface, (180, 120, 30), ach_rect.inflate(-6, -6), 1, border_radius=8)

            draw_codex_star(surface, (255, 225, 90), (ach_rect.x + 28, ach_rect.centery), 12)
            draw_codex_star(surface, (255, 225, 90), (ach_rect.right - 28, ach_rect.centery), 12)

            font_ach_title = get_rpg_font(16, bold=True)
            font_ach_sub = get_rpg_font(11, bold=True)
            a_txt = font_ach_title.render("GRAND ACHIEVEMENT: WORLD SOCIAL STUDIES SCHOLAR!", True, (255, 225, 90))
            a_sub = font_ach_sub.render("100% International Curriculum Mastered! Certified Global Scholar Seal stamped in Book [J]", True, (255, 245, 210))
            surface.blit(a_txt, a_txt.get_rect(centerx=ach_rect.centerx, top=ach_rect.top + 14))
            surface.blit(a_sub, a_sub.get_rect(centerx=ach_rect.centerx, top=ach_rect.top + 42))

        # Draw World Social Studies Codex Overlay (The Book Journal)
        self.codex_ui.draw(surface, self.social_studies_discoveries)

        # Draw Mobile Virtual Touch Controller (rendered on top of gameplay)
        if self.touch_ctrl and not self.dialogue_ui.active and not self.piano_ui.active:
            self.touch_ctrl.draw(surface)
            self.touch_ctrl.post_update()
