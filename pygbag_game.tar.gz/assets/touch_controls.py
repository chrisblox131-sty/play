import pygame
import math

class TouchButton:
    def __init__(self, key_id, label, icon, center_x, center_y, radius, color=(60, 120, 220), border_color=(180, 220, 255)):
        self.key_id = key_id
        self.label = label
        self.icon = icon
        self.center_x = center_x
        self.center_y = center_y
        self.radius = radius
        self.color = color
        self.border_color = border_color
        self.is_pressed = False
        self.active_finger_id = None
        self.just_pressed = False

    def contains(self, px, py):
        dx = px - self.center_x
        dy = py - self.center_y
        return (dx * dx + dy * dy) <= (self.radius * self.radius)

    def draw(self, surface, font_sm, font_lg):
        alpha = 190 if self.is_pressed else 125
        scale_r = int(self.radius * (0.92 if self.is_pressed else 1.0))
        
        btn_surf = pygame.Surface((self.radius * 2 + 8, self.radius * 2 + 8), pygame.SRCALPHA)
        center = (self.radius + 4, self.radius + 4)
        
        fill_col = (*self.color[:3], alpha)
        pygame.draw.circle(btn_surf, fill_col, center, scale_r)
        
        border_col = (*self.border_color[:3], min(255, alpha + 60))
        pygame.draw.circle(btn_surf, border_col, center, scale_r, width=2 if not self.is_pressed else 3)
        
        icon_surf = font_lg.render(self.icon, True, (255, 255, 255)) if font_lg else font_sm.render(self.label, True, (255, 255, 255))
        btn_surf.blit(icon_surf, icon_surf.get_rect(center=(center[0], center[1] - 5)))
        
        lbl_surf = font_sm.render(self.label, True, (240, 240, 255))
        btn_surf.blit(lbl_surf, lbl_surf.get_rect(center=(center[0], center[1] + 12)))
        
        surface.blit(btn_surf, (self.center_x - center[0], self.center_y - center[1]))


class VirtualJoystick:
    def __init__(self, base_x, base_y, base_radius=58, knob_radius=26):
        self.base_x = base_x
        self.base_y = base_y
        self.base_radius = base_radius
        self.knob_radius = knob_radius
        self.knob_x = base_x
        self.knob_y = base_y
        self.is_active = False
        self.active_finger_id = None
        self.dir_x = 0.0
        self.dir_y = 0.0

    def contains(self, px, py):
        dx = px - self.base_x
        dy = py - self.base_y
        return (dx * dx + dy * dy) <= ((self.base_radius + 20) * (self.base_radius + 20))

    def update_position(self, px, py):
        dx = px - self.base_x
        dy = py - self.base_y
        dist = math.hypot(dx, dy)
        max_dist = self.base_radius - (self.knob_radius // 2)

        if dist > 0:
            nx = dx / dist
            ny = dy / dist
            clamped_dist = min(dist, max_dist)
            self.knob_x = self.base_x + nx * clamped_dist
            self.knob_y = self.base_y + ny * clamped_dist
            self.dir_x = nx * (clamped_dist / max_dist)
            self.dir_y = ny * (clamped_dist / max_dist)
        else:
            self.reset()

    def reset(self):
        self.knob_x = self.base_x
        self.knob_y = self.base_y
        self.dir_x = 0.0
        self.dir_y = 0.0
        self.is_active = False
        self.active_finger_id = None

    def draw(self, surface, font_sm):
        base_surf = pygame.Surface((self.base_radius * 2 + 10, self.base_radius * 2 + 10), pygame.SRCALPHA)
        center = (self.base_radius + 5, self.base_radius + 5)
        
        pygame.draw.circle(base_surf, (20, 25, 45, 110), center, self.base_radius)
        pygame.draw.circle(base_surf, (100, 160, 255, 160), center, self.base_radius, width=2)
        
        for angle in (0, 90, 180, 270):
            rad = math.radians(angle)
            p1 = (center[0] + math.cos(rad) * (self.base_radius - 10), center[1] + math.sin(rad) * (self.base_radius - 10))
            p2 = (center[0] + math.cos(rad) * self.base_radius, center[1] + math.sin(rad) * self.base_radius)
            pygame.draw.line(base_surf, (140, 200, 255, 140), p1, p2, width=2)
            
        surface.blit(base_surf, (self.base_x - center[0], self.base_y - center[1]))

        knob_surf = pygame.Surface((self.knob_radius * 2 + 6, self.knob_radius * 2 + 6), pygame.SRCALPHA)
        knob_center = (self.knob_radius + 3, self.knob_radius + 3)
        knob_color = (60, 140, 250, 210) if self.is_active else (50, 90, 160, 160)
        pygame.draw.circle(knob_surf, knob_color, knob_center, self.knob_radius)
        pygame.draw.circle(knob_surf, (200, 235, 255, 230), knob_center, self.knob_radius, width=2)
        surface.blit(knob_surf, (self.knob_x - knob_center[0], self.knob_y - knob_center[1]))


class VirtualTouchController:
    def __init__(self, screen_width=960, screen_height=640, enabled=False):
        import sys
        import os
        is_mobile_env = (
            sys.platform in ('emscripten', 'wasi', 'android') or
            os.environ.get('MOBILE_MODE') == '1' or
            'ANDROID_ARGUMENT' in os.environ or
            'KIVY_BUILD' in os.environ
        )
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.enabled = enabled or is_mobile_env
        self.font_sm = None
        self.font_lg = None
        self.joystick = None
        self.buttons = {}
        self._init_fonts()
        self.rebuild_layout(screen_width, screen_height)

    def _init_fonts(self):
        try:
            self.font_sm = pygame.font.SysFont("comicsansms", 10, bold=True)
            self.font_lg = pygame.font.SysFont("segoeuiemoji", 18)
        except Exception:
            self.font_sm = pygame.font.Font(None, 14)
            self.font_lg = pygame.font.Font(None, 24)

    def rebuild_layout(self, width, height):
        self.screen_width = width
        self.screen_height = height

        joy_x = 95
        joy_y = height - 95
        self.joystick = VirtualJoystick(joy_x, joy_y, base_radius=58, knob_radius=26)

        self.buttons = {}
        self.buttons["attack"] = TouchButton(
            "attack", "ATK", "⚔️",
            width - 80, height - 85, 34,
            color=(180, 45, 45), border_color=(255, 140, 140)
        )
        self.buttons["jump"] = TouchButton(
            "jump", "JUMP", "⏫",
            width - 80, height - 165, 28,
            color=(45, 150, 75), border_color=(140, 255, 170)
        )
        self.buttons["skill"] = TouchButton(
            "skill", "SKILL", "❄️",
            width - 155, height - 85, 28,
            color=(35, 110, 190), border_color=(140, 220, 255)
        )
        self.buttons["shield"] = TouchButton(
            "shield", "GUARD", "🛡️",
            width - 155, height - 165, 28,
            color=(170, 110, 25), border_color=(255, 210, 120)
        )
        self.buttons["inventory"] = TouchButton(
            "inventory", "BAG", "🎒",
            width - 120, height - 235, 24,
            color=(115, 65, 145), border_color=(220, 160, 255)
        )
        self.buttons["menu"] = TouchButton(
            "menu", "MENU", "⚙️",
            width - 45, 32, 22,
            color=(40, 45, 60), border_color=(180, 190, 210)
        )

    def handle_event(self, event):
        # Auto-enable if actual touchscreen finger touch is detected on phone/tablet
        if event.type == pygame.FINGERDOWN:
            self.enabled = True
            px = event.x * self.screen_width
            py = event.y * self.screen_height
            self._process_touch_down(px, py, event.finger_id)
            return

        # If disabled (standard PC mouse & keyboard), do nothing!
        if not self.enabled:
            return

        if event.type == pygame.FINGERMOTION:
            px = event.x * self.screen_width
            py = event.y * self.screen_height
            self._process_touch_move(px, py, event.finger_id)

        elif event.type == pygame.FINGERUP:
            self._process_touch_up(event.finger_id)

        # Mouse simulation ONLY active when touch overlay is explicitly enabled
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self._process_touch_down(event.pos[0], event.pos[1], -1)

        elif event.type == pygame.MOUSEMOTION and event.buttons[0]:
            self._process_touch_move(event.pos[0], event.pos[1], -1)

        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self._process_touch_up(-1)

    def _process_touch_down(self, px, py, finger_id):
        for btn in self.buttons.values():
            if btn.contains(px, py):
                btn.is_pressed = True
                btn.just_pressed = True
                btn.active_finger_id = finger_id
                return

        if self.joystick.contains(px, py) or px < self.screen_width * 0.35:
            self.joystick.is_active = True
            self.joystick.active_finger_id = finger_id
            self.joystick.update_position(px, py)

    def _process_touch_move(self, px, py, finger_id):
        if self.joystick.is_active and self.joystick.active_finger_id == finger_id:
            self.joystick.update_position(px, py)

        for btn in self.buttons.values():
            if btn.active_finger_id == finger_id and not btn.contains(px, py):
                btn.is_pressed = False

    def _process_touch_up(self, finger_id):
        if self.joystick.active_finger_id == finger_id:
            self.joystick.reset()

        for btn in self.buttons.values():
            if btn.active_finger_id == finger_id:
                btn.is_pressed = False
                btn.active_finger_id = None

    def post_update(self):
        for btn in self.buttons.values():
            btn.just_pressed = False

    def is_button_pressed(self, name):
        btn = self.buttons.get(name)
        return btn.is_pressed if btn else False

    def was_button_tapped(self, name):
        btn = self.buttons.get(name)
        return btn.just_pressed if btn else False

    def get_movement_vector(self):
        if not self.enabled or not self.joystick.is_active:
            return (0.0, 0.0)
        return (self.joystick.dir_x, self.joystick.dir_y)

    def draw(self, surface):
        if not self.enabled:
            return
        self.joystick.draw(surface, self.font_sm)
        for btn in self.buttons.values():
            btn.draw(surface, self.font_sm, self.font_lg)
