"""
The Awaiting Stars - International Multilingual Translation System
WICE 2026 Malaysia Competition Release
Supported Languages: IDN (Indonesian), ENG (English), KOR (Korean), MXC (Mexican Spanish), MYS (Malaysian Malay)
"""

import os
import json
import sys

SUPPORTED_LANGUAGES = ["IDN", "ENG", "KOR", "MXC", "MYS"]

LANGUAGE_LABELS = {
    "IDN": "IDN",
    "ENG": "ENG",
    "KOR": "KOR",
    "MXC": "MXC",
    "MYS": "MYS"
}

LANGUAGE_NAMES = {
    "IDN": "Bahasa Indonesia",
    "ENG": "English",
    "KOR": "한국어",
    "MXC": "Español (MX)",
    "MYS": "Bahasa Melayu"
}

LANGUAGE_FLAGS = {
    "IDN": "🇮🇩",
    "ENG": "🇬🇧",
    "KOR": "🇰🇷",
    "MXC": "🇲🇽",
    "MYS": "🇲🇾"
}

DEFAULT_LANGUAGE = "ENG"

TRANSLATIONS = {
    "ENG": {
        "menu_play_rpg": "PLAY RPG",
        "menu_word_typist": "WORD TYPIST",
        "menu_sandbox": "SANDBOX MODE",
        "menu_settings": "SETTINGS",
        "menu_credits": "CREDITS",
        "menu_quit": "QUIT GAME",
        "settings_title": "SETTINGS",
        "settings_language": "SELECT LANGUAGE",
        "settings_master_vol": "MASTER VOLUME",
        "settings_music_vol": "MUSIC VOLUME",
        "settings_sfx_vol": "SFX VOLUME",
        "settings_touch": "TOUCH OVERLAY",
        "settings_touch_on": "ENABLED (ON)",
        "settings_touch_off": "DISABLED (OFF)",
        "settings_controls_title": "--- CONTROLS OVERVIEW ---",
        "ctrl_move_k": "WASD / VIRTUAL JOYSTICK",
        "ctrl_move_d": "Move Character / 360-Deg Navigation",
        "ctrl_atk_k": "M1 CLICK / [ATK] BUTTON",
        "ctrl_atk_d": "Basic Sword Strike",
        "ctrl_skill_k": "KEY [F] / [SKILL] BUTTON",
        "ctrl_skill_d": "Glacial Strike Icy Missile",
        "ctrl_bag_k": "KEY [E] / [BAG] BUTTON",
        "ctrl_bag_d": "Open / Close Satchel Inventory",
        "ctrl_guard_k": "SHIFT / [GUARD] BUTTON",
        "ctrl_guard_d": "Shield Defend / Block",
        "ctrl_menu_k": "KEY [ESC] / [MENU] BUTTON",
        "ctrl_menu_d": "Pause / Return to Main Menu",
        "btn_back": "BACK",
        "loading_title": "THE AWAITING STARS",
        "loading_sub": "Two Worlds, One Destiny — WICE 2026",
        "hud_spawn_portal": "SPAWN PORTAL [P]",
        "hud_portal_active": "PORTAL ACTIVE!",
        "hud_bag": "BAG [E]",
        "hud_codex": "CODEX [J]",
        "hud_menu": "MENU [ESC]",
        "victory_title": "* TUTORIAL COMPLETED! *",
        "victory_line1": "Congratulations, Brave Adventurer!",
        "victory_line2": "You have mastered the sword, glacial skills, and movement.",
        "victory_line3": "You are now ready to step into the infinite RPG world!",
        "victory_prompt": "Press [SPACE], [E], or Click to Return to Main Menu",
        "stage_rpg_0": "Constructing Dual-Perspective Cartography & Biomes...",
        "stage_rpg_1": "Generating Mineral Lattices, Ores & Smelting Physics...",
        "stage_rpg_2": "Populating Village Hubs, Domestic Animals & NPCs...",
        "stage_rpg_3": "World Synchronized! Entering Realm...",
        "tip_bag": "TIP: Press [E] or tap the on-screen BAG button to open inventory.",
        "tip_animals": "TIP: Respect village livestock! Slain animals alert guards.",
        "tip_codex": "TIP: Explore to discover ancient ruins and unlock the Codex [J].",
        "tip_mining": "TIP: Harder mineral nodes require refined pickaxes.",
    },
    "IDN": {
        "menu_play_rpg": "MAIN RPG",
        "menu_word_typist": "PENGETIK KATA",
        "menu_sandbox": "MODE SANDBOX",
        "menu_settings": "PENGATURAN",
        "menu_credits": "KREDIT",
        "menu_quit": "KELUAR GAME",
        "settings_title": "PENGATURAN",
        "settings_language": "PILIH BAHASA",
        "settings_master_vol": "VOLUME UTAMA",
        "settings_music_vol": "VOLUME MUSIK",
        "settings_sfx_vol": "VOLUME EFEK SUARA",
        "settings_touch": "KONTROL SENTUH",
        "settings_touch_on": "AKTIF (NYALA)",
        "settings_touch_off": "NONAKTIF (MATI)",
        "settings_controls_title": "--- PANDUAN KONTROL ---",
        "ctrl_move_k": "WASD / JOYSTICK VIRTUAL",
        "ctrl_move_d": "Gerak Karakter / Navigasi 360 Derajat",
        "ctrl_atk_k": "KLIK KIRI / TOMBOL [ATK]",
        "ctrl_atk_d": "Serangan Tebasan Pedang",
        "ctrl_skill_k": "TOMBOL [F] / TOMBOL [SKILL]",
        "ctrl_skill_d": "Serangan Es Glacial Strike",
        "ctrl_bag_k": "TOMBOL [E] / TOMBOL [BAG]",
        "ctrl_bag_d": "Buka / Tutup Tas Inventaris",
        "ctrl_guard_k": "SHIFT / TOMBOL [GUARD]",
        "ctrl_guard_d": "Pertahanan / Tangkisan Perisai",
        "ctrl_menu_k": "TOMBOL [ESC] / TOMBOL [MENU]",
        "ctrl_menu_d": "Jeda / Kembali ke Menu Utama",
        "btn_back": "KEMBALI",
        "loading_title": "THE AWAITING STARS",
        "loading_sub": "Dua Dunia, Satu Takdir — WICE 2026",
        "hud_spawn_portal": "BUKA PORTAL [P]",
        "hud_portal_active": "PORTAL AKTIF!",
        "hud_bag": "TAS [E]",
        "hud_codex": "KODEKS [J]",
        "hud_menu": "MENU [ESC]",
        "victory_title": "* TUTORIAL SELESAI! *",
        "victory_line1": "Selamat, Petualang Pemberani!",
        "victory_line2": "Kamu telah menguasai pedang, sihir es, dan pergerakan.",
        "victory_line3": "Sekarang kamu siap melangkah ke dunia RPG tanpa batas!",
        "victory_prompt": "Tekan [SPASI], [E], atau Klik untuk Kembali ke Menu",
        "stage_rpg_0": "Membangun Kartografi Dua Perspektif & Ekosistem...",
        "stage_rpg_1": "Membuat Tambang Mineral, Bijih & Peleburan Logam...",
        "stage_rpg_2": "Menyusun Desa Warga, Hewan Ternak & Karakter...",
        "stage_rpg_3": "Dunia Tersinkronisasi! Memasuki Alam...",
        "tip_bag": "TIPS: Tekan [E] atau sentuh tombol TAS untuk membuka inventaris.",
        "tip_animals": "TIPS: Jangan sakiti ternak desa! Membunuh ternak memicu penjaga.",
        "tip_codex": "TIPS: Jelajahi dunia untuk menemukan reruntuhan & buka Kodeks [J].",
        "tip_mining": "TIPS: Bongkahan mineral keras butuh beliung tempaan pandai besi.",
    },
    "KOR": {
        "menu_play_rpg": "RPG 플레이",
        "menu_word_typist": "워드 타이피스트",
        "menu_sandbox": "샌드박스 모드",
        "menu_settings": "설정",
        "menu_credits": "크레딧",
        "menu_quit": "게임 종료",
        "settings_title": "설정",
        "settings_language": "언어 선택",
        "settings_master_vol": "마스터 볼륨",
        "settings_music_vol": "배경음 볼륨",
        "settings_sfx_vol": "효과음 볼륨",
        "settings_touch": "터치 컨트롤",
        "settings_touch_on": "활성화 (켜짐)",
        "settings_touch_off": "비활성화 (꺼짐)",
        "settings_controls_title": "--- 조작 가이드 ---",
        "ctrl_move_k": "WASD / 가상 조이스틱",
        "ctrl_move_d": "캐릭터 이동 / 360도 내비게이션",
        "ctrl_atk_k": "좌클릭 / [공격] 버튼",
        "ctrl_atk_d": "기본 검 공격",
        "ctrl_skill_k": "[F] 키 / [스킬] 버튼",
        "ctrl_skill_d": "빙하 일격 얼음 미사일",
        "ctrl_bag_k": "[E] 키 / [가방] 버튼",
        "ctrl_bag_d": "가방 인벤토리 열기 / 닫기",
        "ctrl_guard_k": "SHIFT / [방어] 버튼",
        "ctrl_guard_d": "에너지 방패 방어 / 막기",
        "ctrl_menu_k": "[ESC] 키 / [메뉴] 버튼",
        "ctrl_menu_d": "일시 정지 / 메인 메뉴로 복귀",
        "btn_back": "돌아가기",
        "loading_title": "THE AWAITING STARS",
        "loading_sub": "두 개의 세계, 하나의 운명 — WICE 2026",
        "hud_spawn_portal": "포털 생성 [P]",
        "hud_portal_active": "포털 활성화!",
        "hud_bag": "가방 [E]",
        "hud_codex": "도감 [J]",
        "hud_menu": "메뉴 [ESC]",
        "victory_title": "* 튜토리얼 완료! *",
        "victory_line1": "축하합니다, 용감한 모험가여!",
        "victory_line2": "검술과 빙하 스킬, 기동 기술을 모두 완벽히 익혔습니다.",
        "victory_line3": "이제 끝없는 RPG 세계로 나아갈 준비가 되었습니다!",
        "victory_prompt": "[스페이스], [E] 키 또는 클릭하여 메인 메뉴로 이동",
        "stage_rpg_0": "듀얼 관점 지도 제작 및 생물 군계 구성 중...",
        "stage_rpg_1": "광물 격자, 원석 및 제련 물리 엔진 생성 중...",
        "stage_rpg_2": "마을 중심지, 가축 및 NPC 배치 중...",
        "stage_rpg_3": "세계 동기화 완료! 영역으로 진입합니다...",
        "tip_bag": "팁: [E] 키나 가방 버튼을 눌러 인벤토리를 열고 도구를 만드세요.",
        "tip_animals": "팁: 마을 가축을 보호하세요! 가축을 공격하면 경비병이 출동합니다.",
        "tip_codex": "팁: 탐험을 통해 고대 유적을 찾고 도감 [J]을 잠금 해제하세요.",
        "tip_mining": "팁: 단단한 광석은 대장장이에게서 정제된 곡괭이를 얻어야 합니다.",
    },
    "MXC": {
        "menu_play_rpg": "JUGAR RPG",
        "menu_word_typist": "TECLADO VELOZ",
        "menu_sandbox": "MODO SANDBOX",
        "menu_settings": "AJUSTES",
        "menu_credits": "CRÉDITOS",
        "menu_quit": "SALIR DEL JUEGO",
        "settings_title": "AJUSTES",
        "settings_language": "SELECCIONAR IDIOMA",
        "settings_master_vol": "VOLUMEN GENERAL",
        "settings_music_vol": "VOLUMEN DE MÚSICA",
        "settings_sfx_vol": "VOLUMEN DE EFECTOS",
        "settings_touch": "CONTROLES TÁCTILES",
        "settings_touch_on": "ACTIVADO (ON)",
        "settings_touch_off": "DESACTIVADO (OFF)",
        "settings_controls_title": "--- GUÍA DE CONTROLES ---",
        "ctrl_move_k": "WASD / PALANCA VIRTUAL",
        "ctrl_move_d": "Mover Personaje / Navegación 360°",
        "ctrl_atk_k": "CLIC IZQ / BOTÓN [ATK]",
        "ctrl_atk_d": "Ataque con Espada",
        "ctrl_skill_k": "TECLA [F] / BOTÓN [SKILL]",
        "ctrl_skill_d": "Misil de Hielo Glacial Strike",
        "ctrl_bag_k": "TECLA [E] / BOTÓN [BAG]",
        "ctrl_bag_d": "Abrir / Cerrar Mochila",
        "ctrl_guard_k": "SHIFT / BOTÓN [GUARD]",
        "ctrl_guard_d": "Defensa con Escudo",
        "ctrl_menu_k": "TECLA [ESC] / BOTÓN [MENU]",
        "ctrl_menu_d": "Pausa / Volver al Menú Principal",
        "btn_back": "VOLVER",
        "loading_title": "THE AWAITING STARS",
        "loading_sub": "Dos Mundos, Un Destino — WICE 2026",
        "hud_spawn_portal": "ABRIR PORTAL [P]",
        "hud_portal_active": "¡PORTAL ACTIVO!",
        "hud_bag": "MOCHILA [E]",
        "hud_codex": "CÓDICE [J]",
        "hud_menu": "MENÚ [ESC]",
        "victory_title": "* ¡TUTORIAL COMPLETADO! *",
        "victory_line1": "¡Felicidades, Valiente Aventurero!",
        "victory_line2": "Has dominado la espada, las habilidades de hielo y el movimiento.",
        "victory_line3": "¡Ahora estás listo para explorar el mundo RPG infinito!",
        "victory_prompt": "Presiona [ESPACIO], [E] o Clic para Volver al Menú",
        "stage_rpg_0": "Generando Cartografía de Doble Perspectiva & Biomas...",
        "stage_rpg_1": "Generando Minerales, Vetas & Física de Fundición...",
        "stage_rpg_2": "Poblando Aldeas, Animales Domésticos & Personajes...",
        "stage_rpg_3": "¡Mundo Sincronizado! Entrando al Reino...",
        "tip_bag": "CONSEJO: Pulsa [E] o el botón MOCHILA para abrir el inventario.",
        "tip_animals": "CONSEJO: ¡Respeta el ganado de la aldea! Atacarlos alerta a la guardia.",
        "tip_codex": "CONSEJO: Explora para hallar ruinas y desbloquear el Códice [J].",
        "tip_mining": "CONSEJO: Los minerales densos requieren picos forjados en la herrería.",
    },
    "MYS": {
        "menu_play_rpg": "MAIN RPG",
        "menu_word_typist": "JURUTAIP PERKATAAN",
        "menu_sandbox": "MOD KOTAK PASIR",
        "menu_settings": "TETAPAN",
        "menu_credits": "KREDIT",
        "menu_quit": "KELUAR PERMAINAN",
        "settings_title": "TETAPAN",
        "settings_language": "PILIH BAHASA",
        "settings_master_vol": "VOLUM UTAMA",
        "settings_music_vol": "VOLUM MUZIK",
        "settings_sfx_vol": "VOLUM KESAN BUNYI",
        "settings_touch": "KAWALAN SENTUH",
        "settings_touch_on": "DIAKTIFKAN (HIDUP)",
        "settings_touch_off": "DINAHAKTIFKAN (MATI)",
        "settings_controls_title": "--- PANDUAN KAWALAN ---",
        "ctrl_move_k": "WASD / KAYU KAWALAN VIRTUAL",
        "ctrl_move_d": "Gerak Watak / Navigasi 360 Darjah",
        "ctrl_atk_k": "KLIK KIRI / BUTANG [ATK]",
        "ctrl_atk_d": "Serangan Tetakan Pedang",
        "ctrl_skill_k": "KEKUNCI [F] / [SKILL]",
        "ctrl_skill_d": "Serangan Ais Glacial Strike",
        "ctrl_bag_k": "KEKUNCI [E] / [BAG]",
        "ctrl_bag_d": "Buka / Tutup Beg Inventori",
        "ctrl_guard_k": "SHIFT / BUTANG [GUARD]",
        "ctrl_guard_d": "Pertahanan / Tangkisan Perisai",
        "ctrl_menu_k": "KEKUNCI [ESC] / [MENU]",
        "ctrl_menu_d": "Jeda / Kembali ke Menu Utama",
        "btn_back": "KEMBALI",
        "loading_title": "THE AWAITING STARS",
        "loading_sub": "Dua Dunia, Satu Destinasi — WICE 2026",
        "hud_spawn_portal": "BUKA PORTAL [P]",
        "hud_portal_active": "PORTAL AKTIF!",
        "hud_bag": "BEG [E]",
        "hud_codex": "KODEKS [J]",
        "hud_menu": "MENU [ESC]",
        "victory_title": "* TUTORIAL SELESAI! *",
        "victory_line1": "Tahniah, Pengembara Berani!",
        "victory_line2": "Anda telah menguasai pedang, kemahiran ais, dan pergerakan.",
        "victory_line3": "Kini anda bersedia melangkah ke dunia RPG tanpa batas!",
        "victory_prompt": "Tekan [SPACE], [E], atau Klik untuk Kembali ke Menu",
        "stage_rpg_0": "Membina Kartografi Dua Perspektif & Bioma...",
        "stage_rpg_1": "Menjana Kekisi Mineral, Bijih & Fizik Peleburan...",
        "stage_rpg_2": "Menempatkan Kampung Warga, Haiwan Ternakan & NPC...",
        "stage_rpg_3": "Dunia Diselaraskan! Memasuki Alam...",
        "tip_bag": "PETUA: Tekan [E] atau sentuh butang BEG untuk membuka inventori.",
        "tip_animals": "PETUA: Hormati ternakan kampung! Mencederakan ternakan menarik pengawal.",
        "tip_codex": "PETUA: Terokai dunia untuk temui runtuhan purba & buka Kodeks [J].",
        "tip_mining": "PETUA: Nod mineral keras memerlukan beliung tempaan tukang besi.",
    }
}

def t(key, lang="ENG", default=None):
    """Get localized translation string for key and language."""
    pack = TRANSLATIONS.get(lang, TRANSLATIONS["ENG"])
    if key in pack:
        return pack[key]
    # Fallback to English
    eng_pack = TRANSLATIONS.get("ENG", {})
    if key in eng_pack:
        return eng_pack[key]
    return default if default is not None else key

def get_save_path():
    """Get path to settings save file."""
    base = os.path.dirname(os.path.abspath(__file__))
    save_dir = os.path.join(base, "TAS_saves")
    os.makedirs(save_dir, exist_ok=True)
    return os.path.join(save_dir, "settings.json")

def load_settings():
    """Load settings from JSON if present."""
    p = get_save_path()
    if os.path.exists(p):
        try:
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"lang": DEFAULT_LANGUAGE}

def save_settings(settings):
    """Save settings to JSON."""
    p = get_save_path()
    try:
        with open(p, "w", encoding="utf-8") as f:
            json.dump(settings, f, ensure_ascii=False, indent=2)
    except Exception:
        pass
